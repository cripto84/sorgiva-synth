# File aggiornati alpha13

- `src/performance/adaptive-performance.js` (nuovo)
- `src/audio/audio-context.js` (policy governatore, inizializzazione profiler, diagnostica release)
- `src/ui/controls.js` (separazione controlli Adaptive dai parametri della patch)
- `src/main.js` (inizializzazione)
- `index.html` e `styles/main.css` (UI Adaptive Performance)
- `src/core/identity.js`, `src/presets/presets.js`, `src/sequencer/step-sequencer.js`, `src/midi/midi-learn.js` (metadati/export)
- `README.txt`, `VERSION*`, documentazione, test e report QA.
- `src/presets/factory-presets.js`: **invariato**.
