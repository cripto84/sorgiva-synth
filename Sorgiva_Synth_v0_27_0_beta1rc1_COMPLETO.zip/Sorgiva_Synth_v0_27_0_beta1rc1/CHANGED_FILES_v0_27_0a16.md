# File modificati alpha16

- `tests/regression_r3.py`: modalità runtime/factory/offline indipendenti con checkpoint e pagine isolate.
- `tests/phase16_stability.py`, `tests/phase16_factory_coverage.py`: nuova copertura ripetuta e aggregazione dei risultati.
- `tests/smoke_static.py`: controlli versione/export alpha16.
- `index.html`, `src/core/identity.js`, `src/main.js`: versione e indicazioni UI.
- `src/midi/midi-learn.js`, `src/presets/presets.js`, `src/sequencer/step-sequencer.js`: suffissi alpha16 nei nomi dei file esportati, formato invariato.
- `src/performance/adaptive-performance.js`: solo intestazione versione.
- `README.txt`, `CHANGELOG.txt`, `VERSION*`, release notes e documentazione.

**Immutati:** tutti i file `src/audio/*.js`, `src/presets/factory-presets.js`, i 135 preset, i coefficienti e l'algoritmo del Governor.
