# Release notes — Sorgiva Synth v0.27.0-alpha9

**Base:** v0.27.0-alpha8, verificata direttamente dagli ZIP completo ed essenziale caricati.

## Motore

- `src/audio/audio-context.js`: uscita anticipata per patch senza sorgenti sonore (`osc1–3` disattivati o livello zero, Noise disattivato). Non si creano più filtri, inviluppi o LFO che avrebbero soltanto dovuto essere arrestati immediatamente. Resta la protezione originaria dopo la creazione, come fallback per futuri algoritmi.
- Nessuna modifica intenzionale ai percorsi di generazione del suono quando almeno una sorgente è attiva.

## Verifica e prestazioni

- `tests/phase9_performance.py`: misure riproducibili del costo sul thread JS di creazione delle voci, dei nodi WebAudio istanziati e della pulizia al Panic. **Non equivale a un benchmark della CPU audio.**
- `tests/phase9_factory_audio.py`: rendering offline breve del suono di ogni factory preset in un AudioContext isolato, con checkpoint periodici. Valuta campioni finiti e release ricevuta; non certifica il carattere musicale né la durata delle code.
- `tests/consolidamento_browser.py`: aggiorna la regressione del caso senza sorgenti per riconoscere come corretto anche l'azzeramento preventivo di tutte le allocazioni.
- Metadati dei nuovi export aggiornati ad Alpha 9. Schemi e identificatori di compatibilità preservati.

## Compatibilità

Factory preset e parametri di sintesi preesistenti invariati. I file legacy privi di `fm-quality` e `oscN-pulse-quality` restano Classic. L'archivio alpha8 non è alterato.

## Stato

**Alpha sperimentale.** Risultati delle prove completate e limiti sono dichiarati nel rapporto QA; non esiste ancora una certificazione del consumo CPU audio su hardware fisico.
