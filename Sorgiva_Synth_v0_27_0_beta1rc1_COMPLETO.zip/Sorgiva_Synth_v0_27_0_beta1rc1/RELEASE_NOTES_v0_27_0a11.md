# Sorgiva Synth v0.27.0-alpha11 — Note di rilascio

**Base**: v0.27.0-alpha10.

- Ottimizzato il monitor `Dynamics Safety`: l'interfaccia evita aggiornamenti di testo, stile e classi identici ai valori già visualizzati. Il percorso WebAudio di protezione (limiter, clipper e Gain Guard) non è stato modificato.
- Aggiunto `tests/phase11_sustained_profile.py`: accordi leggeri, otto note con Unison ×8/effetti e rapid retrigger, con verifica cleanup e timing JS.
- Introdotta una prova automatizzata contro aggiornamenti DOM inutili degli indicatori a riposo.
- Identificativi della release e suffissi di esportazione aggiornati alla alpha11; schema dei preset conservato.

**Limite:** questi benchmark misurano il thread JS, le mutazioni DOM e la pulizia dei grafi, non l'utilizzo della CPU nel thread audio, la latenza reale né eventuali dropout/xrun sull'hardware dell'utente.
