# Sorgiva Synth — v0.26.9 Consolidamento

**Stato:** build candidata per verifiche, non ancora certificata come release stabile.
Basata su `v0.26.8rc1` senza modifica dei dati factory.

## Fix implementati

1. **Transazione Morph/Topologia.** `src/audio/audio-context.js` espone `beginParameterBatch`/`endParameterBatch`; `rebuildActiveVoices` accumula la necessità di ricostruire durante il batch e interviene al termine. `src/presets/preset-morph.js` usa try/finally per concludere sempre la transazione. Il batch non cancella la possibilità di ricostruire una voce, ma evita una ricostruzione per ogni controllo incompatibile.
2. **Pulizia LFO senza sorgenti.** In `createVoice`, se nessun generatore audio viene creato, gli LFO predisposti sui filtri vengono arrestati e disconnessi prima del return `null`.
3. **Note per sorgente.** La gestione della singola altezza ora mantiene un set di proprietari per nota di input. La tastiera virtuale, quella alfanumerica e il MIDI passano una sorgente esplicita: il Note Off di uno non termina la nota di un altro.
4. **Protezione input testo.** I keydown musicali sono ignorati nei campi di input, select, textarea e contenuti modificabili, oltre che con scorciatoie Ctrl/Alt/Meta. Il keyup di un tasto musicale già abbassato continua a liberarlo.
5. **Versioni e metadati.** Aggiornati codice identità, intestazioni runtime, denominazioni e versioni di export correnti; sono mantenuti gli alias SynthX di compatibilità.

## Vincoli rispettati

- Stessi 135 factory preset, identici byte del file `src/presets/factory-presets.js`.
- Nessun cambiamento deliberato agli algoritmi di sintesi o al signal chain.
- Nessun nuovo framework o requisito di compilazione.
- Nessun reset delle chiavi di salvataggio `localStorage` o dei formati import/export.

## Miglioramenti non compresi in questa release

Non sono stati completati il nuovo Voice Allocator, lo scheduler audio look-ahead, il pooling generale dei nodi audio, l'oversampling selettivo, AudioWorklet, un nuovo Morph dual-engine o il caching elaborato del riverbero. Tali interventi richiedono benchmark e test audio specifici. Il sistema di sorgenti evita collisioni tra MIDI e tastiere ma non sostituisce ancora un voice allocator capace di distinguere voci multiple della stessa altezza: il retrigger continua a usare la politica esistente.
