# QA — Sorgiva Synth v0.27.0-alpha1

**Base verificata:** ZIP v0.26.9 fornito dall'utente integro e byte-identico all'archivio della consegna precedente. I sei gruppi principali di test della base sono passati.

| Suite sulla nuova alpha | Esito | Copertura |
|---|---|---|
| `python tests/smoke_static.py` | PASS | 26 file JS, versioni, JSON, riferimenti, 135 factory preset, 229 target MIDI |
| `node tests/refinement.cjs .` | PASS | voice stealing, Morph (1485 interpolazioni), smoothing, Hold e Sustain |
| `python tests/smoke_browser.py` | PASS | audio WebAudio in Chromium, inizializzazione, voce e note off |
| `python tests/consolidamento_browser.py` | PASS | 4 regressioni della versione 0.26.9 |
| `python tests/phase2_browser.py` | PASS | ownership Seq/Arp, Note Off sicuro, priorità allocator, timer a fase stabile, stop pattern |
| `python tests/tempo_regression.py` | PASS | MIDI Clock e sync, Delay, LFO, sequencer note input |
| `python tests/matrix_routes_regression.py` | PASS | 200 combinazioni della modulation matrix |
| `python tests/regression_r3.py` | INCOMPLETO | Test iniziali del motore superati, sweep factory arrivato a 90/135 prima del limite di esecuzione; non tutti i controlli finali verificati |
| `python tests/factory_audio.py` | NON ESEGUITO | 135 rendering audio integrali offline |
| Controller MIDI fisico e ascolto critico | NON ESEGUITI | Da verificare prima di una release stabile |

## Misura riproducibile del timer

In un test deterministico di 100 passi con periodo di 125 ms e sovraccarico ipotetico di 7 ms per callback:

- timer precedente relativo al callback: **13.200 ms** alla centesima iterazione;
- timer nuovo con scadenze assolute: **12.500 ms**;
- deriva cumulata evitata nello scenario simulato: **700 ms**.

Non è un benchmark di latenza reale e non garantisce precisione audio di campione. In browser reale restano jitter del thread JS, clamp dei timer e modifiche dinamiche del MIDI Clock.

## Compatibilità

- Factory preset `src/presets/factory-presets.js` byte-identico alla 0.26.9, 135 suoni.
- Formati e chiavi di memoria invariati. Il nome dei file esportati viene aggiornato alla build.
- Il numero di file JS aumenta da 24 a 26 per la separazione modulare.

## Limitazioni residue

Il refactoring del Voice Manager è parziale e il nuovo scheduling non è ancora AudioContext look-ahead. La suite completa si è rallentata durante il ciclo dei preset e non può essere dichiarata PASS. Necessari ascolto musicale, monitoraggio CPU e controller reali prima di dichiarare questa versione stabile.
