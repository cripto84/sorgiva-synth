# Alpha8 — Modifiche principali

- `src/audio/fm-spectral-guard.js` — nuovo stimatore FM Guarded.
- `src/audio/osc-sync-spectrum.js` — nuovo calcolo FFT dei coefficienti.
- `src/audio/audio-context.js` — integrazione DSP, modifica in tempo reale, fallback.
- `src/audio/audio-config.js` — parametro FM quality.
- `index.html` — controllo FM e inclusione dei due script.
- `src/ui/controls.js` e `src/presets/presets.js` — default e compatibilità salvataggi.
- `src/core/identity.js`, `src/main.js`, `src/midi/midi-learn.js`, `src/sequencer/step-sequencer.js` — versione e nomi export.
- `tests/phase8_fm_sync.py` — nuove regressioni FFT/FM.
- `tests/smoke_static.py`, `tests/smoke_browser.py` — baseline alpha8.
- Metadati di release e manifest hash.
