# Sorgiva Synth v0.27.0-alpha7 — QA report

Data: 26 ottobre 2026. Base: gli ZIP alpha6 COMPLETO ed ESSENZIALE caricati dall’utente.
Gli archivi di partenza superano il controllo ZIP CRC. Questa fase implementa il Pulse/PWM HQ opzionale.

## Esiti verificati

| Verifica | Risultato | Metodo |
|---|---|---|
| Integrità ZIP alpha6 caricati | PASS | `ZipFile.testzip()` su completo (926 elementi) ed essenziale (45) |
| Test statici: sintassi JS, risorse HTML, 135 preset, 229 target MIDI Learn | PASS | `tests/smoke_static.py` |
| Logica patch, voice note, Preset Morph (1.485 confronti) | PASS | `tests/refinement.cjs` |
| Avvio WebAudio, note e release, UI | PASS | `tests/smoke_browser.py` |
| Correzioni 0.26.9 / ownership note e Morph | PASS | `tests/consolidamento_browser.py` |
| Voice allocator / Voice lifecycle | PASS | `tests/phase2_browser.py` / `tests/phase3_browser.py` |
| Trasporto e reverb | PASS | `tests/phase4_browser.py` |
| One-shot e Arpeggiatore / Strum | PASS | `tests/phase5_browser.py` / `tests/phase6_browser.py` |
| MIDI Clock simulato e Delay/LFO sync | PASS | `tests/tempo_regression.py` con Chromium esplicito |
| Mod Matrix, 200 combinazioni | PASS | `tests/matrix_routes_regression.py` con Chromium esplicito |
| Cache DSP curve/osc sync | PASS | `tests/dsp_cache_regression.py` |
| Pulse HQ: statico, PWM LFO, Unison ×4, fallback, cleanup | PASS | `tests/pulse_bandlimited_regression.py` |
| Preset legacy dopo l’uso HQ: ritorno a Classic | PASS | `tests/pulse_bandlimited_regression.py` |
| Confronto audio Classic con alpha6 | PASS entro tolleranza 1e-4 | `tests/classic_audio_regression.py` |
| ZIP essenziale estratto: script/runtime, note e release | PASS con limitazione | 30 script originali caricati in pagina HTML di test Chromium; una voce HQ creata e liberata, nessun errore JS. Avvio diretto `file://` e `localhost` bloccato dalle policy amministrative del sandbox, non testato lì. |
| Caricamento/rendering dinamico di 135 preset | INCOMPLETO | verifica statica completa, rendering integrale non attestato |
| Ascolto comparativo e MIDI hardware | NON ESEGUITI | richiesti strumenti fisici |

## Analisi aliasing statica — banco di prova circoscritto

OfflineAudioContext 48 kHz, 1 secondo, confronto fra threshold Waveshaper 2× Classic e
sottrazione band-limited di una saw nativa e relativa copia ritardata; frequenza/width
costanti. FFT Hann, segmento centrale di 42.000 campioni; componente alias più forte
fra i foldover delle armoniche fuori Nyquist, relativa alla fondamentale.

| Frequenza | Duty | Alias Classic | Alias Band-limited |
|---|---:|---:|---:|
| 2.100 Hz | 25% | −24,2 dB | −126,4 dB |
| 5.300 Hz | 25% | −16,1 dB | −136,4 dB |
| 5.300 Hz | 50% | −23,5 dB | −133,5 dB |

I valori dipendono dalla metrica e dal contesto test. **Non sono una
certificazione del contenuto spettrale reale delle patch**, e la PWM dinamica
può creare sideband; queste prove riguardano esclusivamente Pulse statica.

## Conservazione dell’audio Classic

Cinque render di durata 0,9 s, a 24 kHz. Sine, saw e triangle: differenza massima
**0,0** su 21.600 campioni ciascuno. Pulse a duty 25% e 70%: differenza massima
nell’ordine di `1,6e-5`–`1,9e-5` nei run eseguiti; entrambi entro la tolleranza
stabilita `1e-4`. Nessun confronto rende una garanzia universale per tutti i preset.

## Limitazioni e priorità successive

- La nuova qualità è opzionale, può produrre livello e carattere diversi e aggiunge nodi WebAudio.
- La PWM fuori dal range sicuro ritorna a Classic; FM/Sync e modulazioni estreme
  non hanno una garanzia anti-aliasing generale.
- Test CPU con Unison alto e misura del jitter fisico non eseguiti.
- La suite lunga dei 135 preset in un’unica sessione WebAudio non è terminata
  nelle alpha precedenti; resta requisito aperto.
- Validare la versione con MIDI reale e ascolto musicale prima di una release stabile.

**Stato: alpha sperimentale, verificata nei percorsi descritti.**
