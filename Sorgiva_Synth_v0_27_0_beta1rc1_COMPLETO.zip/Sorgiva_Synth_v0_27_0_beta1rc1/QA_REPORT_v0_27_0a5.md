# Sorgiva Synth v0.27.0-alpha5 — Rapporto QA

Data: 24 ottobre 2026. Base: v0.27.0-alpha4 completa caricata dall'utente.

## Ambito

Test locali Python 3, Node.js e Playwright/Chromium headless. Il sintetizzatore è un'applicazione WebAudio; questi test non certificano latenza end-to-end, timbro o compatibilità hardware MIDI.

## Verifica della base alpha4

- Archivio completo ed essenziale leggibili senza errori CRC.
- `tests/smoke_static.py`, `tests/refinement.cjs` e `tests/phase5_browser.py`: PASS sulla alpha4 prima delle modifiche.
- Il formato patch e i 135 factory preset sono rimasti invariati in alpha5.

## Interventi alpha5

- Arpeggiatore: preparazione ahead-of-time con cursor preview non distruttiva e cancellazione dei one-shot futuri quando cambiano input, controlli, clock o stato del trasporto.
- Sequencer: supporto Strum breve sul clock audio. Offset e gate finale condiviso; fallback quando lo Strum non può essere contenuto nel gate.
- Le callback tardive dello Strum non inviano più un doppio Note On dopo una preparazione audio valida.

## Test della nuova build

| Test | Stato | Significato |
|---|---|---|
| `tests/smoke_static.py` | PASS | Sintassi JS, JSON, asset HTML, 135 factory preset, 229 target MIDI Learn |
| `tests/refinement.cjs` | PASS | Regressione logica, 1.485 confronti Morph |
| `tests/smoke_browser.py` | PASS | Browser, WebAudio, creazione/rilascio nota |
| `tests/consolidamento_browser.py` | PASS | Correzioni consolidate v0.26.9 |
| `tests/phase2_browser.py` | PASS | Note ownership, allocator, trasporto |
| `tests/phase3_browser.py` | PASS | Voice lifecycle e sospensione/resume |
| `tests/phase4_browser.py` | PASS | Cache impulsi e lookahead |
| `tests/phase5_browser.py` | PASS | One-shot anticipato del Sequencer e isolamento note MIDI |
| `tests/phase5_audio_signal.py` | PASS | Render mirato di one-shot, silenzio/attacco/gate/rilascio |
| `tests/tempo_regression.py` | PASS | MIDI Clock simulato e Delay/LFO sync |
| `tests/matrix_routes_regression.py` | PASS | 200 combinazioni della Mod Matrix |
| `tests/phase6_browser.py` | PASS | Arp anticipato, invalidazione, Seq Strum breve, preservazione ownership, timestamp Strum 10/20 ms |
| Render di tutti i 135 preset | NON ESEGUITO | Solo integrità statica dei 135 |
| MIDI hardware e ascolto umano | NON ESEGUITI | Necessaria sessione dedicata |

### Misura mirata alpha5

Una esecuzione di `phase6_browser.py`: Arp 10 one-shot preparati, 9 consumati prima della lettura, poi 2 invalidazioni su modifica/stop; Sequencer 8 preparati e 7 consumati; verificati timestamp con Strum 10 e 20 ms. Questi sono conteggi di un test e non indicano il carico CPU o il jitter fisico.

## Limiti tecnici aperti

- Il timer di lookahead continua a dipendere dal thread JavaScript; il percorso timestamped riguarda soltanto i one-shot accettati.
- Tie e Strum non contenibile nel gate usano il vecchio percorso temporizzato.
- Il grafo WebAudio cattura la patch al momento della preparazione, potenzialmente prima dell'ultimo gesto espressivo.
- Il limite di 24 one-shot preparati e le code di rilascio possono forzare il fallback; i test non certificano tutte le condizioni di stress.
- La validazione completa di tutti i preset, jitter di hardware MIDI, ascolto e confronti anti-aliasing sono ancora aperti.

Giudizio: alpha5 di sviluppo con nessuna regressione bloccante nei test eseguiti; NON release stabile certificata.
