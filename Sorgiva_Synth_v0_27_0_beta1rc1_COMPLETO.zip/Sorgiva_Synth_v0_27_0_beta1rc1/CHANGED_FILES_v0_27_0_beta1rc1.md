# Modifiche beta1 RC1 rispetto alla alpha17

**Runtime (metadati e UI, non DSP):** `index.html`, `src/core/identity.js`, `src/main.js`, `src/presets/presets.js`, `src/presets/preset-morph.js`, `src/arp/arpeggiator.js`, `src/sequencer/step-sequencer.js`, `src/midi/midi-learn.js` e commento in `src/performance/adaptive-performance.js`.

**Versioni:** `VERSION`, `VERSION.txt`. **Documentazione:** `README.txt`, release notes, quick start, checklist, changelog, report QA e manifesto SHA-256.

**Test:** suite preesistenti ripetute con nuova versione, `tests/beta_offline_full.py`, `tests/beta_offline_full_results.json`. I 135 factory preset e l'intera directory `src/audio/` sono byte-identici alla alpha17.
