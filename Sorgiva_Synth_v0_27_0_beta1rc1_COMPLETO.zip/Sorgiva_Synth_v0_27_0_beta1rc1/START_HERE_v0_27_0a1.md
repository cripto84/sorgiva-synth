# Sorgiva Synth v0.27.0-alpha1 — Guida rapida

Build sperimentale della seconda fase, basata sull'archivio verificato v0.26.9 (SHA256 originale `87f2565a73df89eba4b2bf3d4887b171f07d559cdd865f568397c588b31d1d30`).

1. Estrarre interamente l'archivio in una cartella.
2. Aprire `index.html` nel browser desktop aggiornato. Per l'uso MIDI hardware avviare invece la cartella tramite localhost/HTTPS in Chromium.
3. Premere **Sblocca Audio**, iniziare con volume moderato e provare Default Init.
4. Non sostituire le copie dei preset utente: esportare prima le proprie banche. I vecchi formati e le chiavi di localStorage restano supportati.

**Completo:** conserva storico, documentazione tecnica, suite QA e manuale precedente.
**Essenziale:** contiene soltanto il runtime completo più licenze e note di rilascio, senza lo storico né suite QA.

Questa alpha non è una release stabile. Gli impulsi sonori in condizioni MIDI reali e il carico CPU su macchine differenti non sono stati certificati. Il manuale storico incluso nel completo descrive una build precedente e va riallineato.
