# Come provare la alpha14

1. Estrai completamente lo ZIP e apri `index.html` con Chromium; per WebMIDI preferisci `localhost` o HTTPS.
2. Premi **Sblocca Audio**. Nella scheda **Performance → Adaptive Performance**, seleziona **AUTO** e lascia abilitato l'adattamento automatico.
3. Ripeti il benchmark silenzioso **solo senza note o code attive**. È un test offline, non un misuratore della CPU reale.
4. Nel pannello osserva «Governor dinamico AUTO» e lo storico riduzioni, recuperi e nuove note rinviate.
5. Per non ricevere alcun intervento dinamico usa **STUDIO**, **ECO**, **MANUALE** (profili statici) o togli la spunta ad adattamento automatico per ripristinare il comportamento alpha12.

Il segnale usato è il ritardo dello scheduling JavaScript e NON è una misura diretta del flusso DSP. È possibile che un computer senza problemi audio mostri un ritardo di interfaccia o viceversa. Non usare la alpha14 in un concerto senza collaudo esteso sul tuo hardware.
