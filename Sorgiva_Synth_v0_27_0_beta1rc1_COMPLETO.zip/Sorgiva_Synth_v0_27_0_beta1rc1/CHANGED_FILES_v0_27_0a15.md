# File modificati alpha15

- `src/audio/audio-context.js` — snapshot FX, budget code lazy-sort, selezione singola vittima e contatori.
- `src/audio/voice-allocator.js` — `pick` equivalente a `candidates()[0]`.
- `src/core/identity.js`, `src/main.js`, `index.html` — versione/UI e metadati.
- `src/midi/midi-learn.js`, `src/presets/presets.js`, `src/sequencer/step-sequencer.js` — versione nei nomi esportati; formato invariato.
- `README.txt`, `CHANGELOG.txt`, `VERSION`, `VERSION.txt`, documentazione alpha15.
- `tests/smoke_static.py`, `tests/phase15_resource_optimization.py` e risultati QA.

Nessuna modifica a `src/presets/factory-presets.js` né agli algoritmi DSP.
