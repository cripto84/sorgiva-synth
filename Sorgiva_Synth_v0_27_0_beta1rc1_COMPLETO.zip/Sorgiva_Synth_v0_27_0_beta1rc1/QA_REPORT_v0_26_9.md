# QA — Sorgiva Synth v0.26.9 Consolidamento

Verifiche effettuate nel container con Node.js, Python Playwright e Chromium headless.

| Verifica | Esito | Copertura |
|---|---|---|
| `python tests/smoke_static.py` | PASS | versioni, JS sintassi, JSON, riferimenti risorse, 135 preset, 229 MIDI Learn target |
| `node tests/refinement.cjs .` | PASS | test logici voice stealing, smoothing, 1.485 interpolazioni factory Morph |
| `python tests/smoke_browser.py` | PASS | bootstrap Chromium, audio running, voce, release, Morph startup |
| `python tests/consolidamento_browser.py` | PASS | test browser di ownership note, tastiera/campi testo, LFO senza sorgenti, 10 Morph |
| `CHROMIUM_PATH=/usr/bin/chromium python tests/tempo_regression.py` | PASS | MIDI clock sintetico, internal BPM, sync LFO/Delay, step input |
| `CHROMIUM_PATH=/usr/bin/chromium python tests/matrix_routes_regression.py` | PASS | 200 combinazioni, limite pitch e sustain |
| `CHROMIUM_PATH=/usr/bin/chromium python tests/regression_r3.py` | INCOMPLETO | test precedenti fino al primo segmento factory superati, limite di esecuzione durante il ciclo di tutti i preset |
| `python tests/factory_audio.py` | NON ESEGUITO | 135 render integrali offline e verifiche relative |
| MIDI hardware e confronto d'ascolto | NON ESEGUITI | necessitano hardware/audio ascoltato |

### Dati della regressione mirata

- Due sorgenti sul medesimo pitch: **2 owner / 1 voce**; rilasciando il primo, **1 owner / 1 voce**; rilasciando anche il secondo, **0 owner / 0 voci**.
- Digitazione `q` in un campo testo: **0 nuove voci**.
- LFO senza generatore sonoro: **1 start / 1 stop** intercettato.
- Dieci applicazioni Morph su una nota tenuta: **9** nuove code di release, contro il tetto di **10** atteso (una al massimo per applicazione), con voce mantenuta.
- Factory preset: **135** presenti e inalterati (SHA256 verificato rispetto alla RC1).

### Nota di interpretazione

Gli esiti browser headless non garantiscono assenza di glitch percepibili, compatibilità universale WebMIDI, né prestazioni CPU su tutti i sistemi. La v0.26.9 rimane una build candidata; consigliabile una verifica musicale approfondita prima della distribuzione pubblica.
