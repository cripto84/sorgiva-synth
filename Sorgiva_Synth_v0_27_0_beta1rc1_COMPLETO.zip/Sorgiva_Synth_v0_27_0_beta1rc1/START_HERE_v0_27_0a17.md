# Sorgiva Synth v0.27.0-alpha17 — Quick Start

1. Estrai l'ESSENZIALE, apri `index.html` in Chromium desktop. Per WebMIDI preferisci `localhost` o HTTPS.
2. Parti con volume moderato; premi **Sblocca Audio** e prova **Default Init**.
3. In **Performance → Adaptive Performance**, lascia **AUTO** e avvia eventualmente un benchmark silenzioso quando non stai suonando.
4. Per la validazione musicale prova almeno pad a Release lunga, bassi monofonici, lead con Unison, sequenze, MIDI Sustain e morph A/B. Controlla durante le note attive il comportamento dei limiti adattivi.
5. Esegui un backup della User Preset Bank prima di aggiornare. Per tornare alla build precedente, riapri la cartella alpha16.

I test audio offline e MIDI simulati non certificano l'assenza di problemi su hardware reale.
