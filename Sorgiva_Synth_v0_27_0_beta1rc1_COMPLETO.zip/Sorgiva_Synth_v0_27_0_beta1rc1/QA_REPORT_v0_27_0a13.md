# QA — Sorgiva Synth v0.27.0-alpha13

**Data:** 27 ottobre 2026  
**Build:** Adaptive Performance Engine — sperimentale  
**Baseline:** archivi completi ed essenziali v0.27.0-alpha12 forniti dall'utente. CRC di entrambi gli input: PASS.

## 1. Esito sintetico

**PASS nei percorsi testati.** Nuovo motore adaptivo integrato senza alterare i dati factory. I 135 factory preset sono stati sottoposti a controllo statico e breve render offline. I 3 render audio deterministici alpha12/alpha13 rispettano la tolleranza definita. **Non è una certificazione audio su hardware reale.**

## 2. Funzionalità introdotte

- **Hardware Profiler:** processori logici; memoria indicativa se esposta dal browser; supporto WebAudio/OfflineAudioContext; sample rate e latenze disponibili. Informazioni assenti mostrate come non disponibili.
- **Resource Budget Manager:** pesi centralizzati per note, oscillatori×Unison, Noise, filtri, Advanced Filter, LFO, Mod Matrix, FM, Ring Mod, Osc Sync, FX e voci Release. La stima è in unità relative, non in percentuali CPU DSP.
- **Adaptive Voice Governor:** tetto ponderato delle nuove voci e dei generatori, code Release gestite col sistema alpha12, protezione delle note già attive durante il cambio profilo. Nessuna reimpostazione automatica dei preset.
- **Profili AUTO/ECO/STUDIO/MANUALE:** limiti realmente differenti; AUTO non abbassa automaticamente il numero di layer di una patch già programmata, mentre ECO/manuale possono limitarli per le nuove note; bypass del governo automatico ripristina il comportamento alpha12.
- **Interfaccia Performance:** stato hardware, ultimo benchmark, polifonia suggerita/effettiva, limite Unison, cap delle code, carico stimato, azioni protettive e benchmark ripetibile.
- **Persistenza isolata:** chiave `sorgivaSynth.adaptivePerformance.v1`, esclusa dai parametri dei preset JSON e legacy.

## 3. Benchmark eseguito (Chromium headless, non hardware musicale)

- Processori logici comunicati dal browser: **5**; memoria indicativa: **non disponibile** nel browser di test.
- Sample rate AudioContext: **44100 Hz**, `baseLatency` **0.01 s**, `outputLatency` **0.032 s**. Non sono misure end-to-end con interfaccia audio fisica.
- Benchmark finale: **completato**, **6** render, ciascuno **90 ms** a **22.050 Hz** con detune/filtri (4, 7, 10 oscillatori, 2 ripetizioni).
- Tempi preparazione nodi, ms: **0.5, 0.6, 0.8, 0.6, 0.9, 0.9**.
- Tempi rendering offline, ms: **0.9, 0.5, 0.9, 0.3, 0.4, 0.6**.
- Microbenchmark JavaScript **2.3 ms**; variabilità max ripetizioni **60%**.
- Un rendering offline più veloce del tempo reale **non garantisce** l'assenza di dropout nel flusso WebAudio reale. Non sono stati inventati valori di utilizzo CPU o memoria libera.

## 4. Test eseguiti e risultati effettivi

| Categoria | Procedura | Esito |
|---|---|---|
| Integrità input | CRC ZIP alpha12 completo + essenziale | PASS |
| Statico | `tests/smoke_static.py`: 33 script JS, file JSON, ID HTML, riferimenti, versione | PASS |
| Factory | 135 preset: unicità, valori finiti e integrità | PASS 135/135 |
| Factory audio | `tests/phase9_factory_audio.py`: 24 kHz mono, Do4 1 s, Release a 240 ms | PASS **135/135**, zero non-finiti e zero preset muti |
| Compatibilità timbrica | `phase11_audio_parity.py` con alpha12 completo: 3 render stereo 48 kHz, 1 s | PASS **288.000 campioni**, differenza assoluta massima **3.92273068e-06** (soglia 0,00002) |
| Audio/eventi | `phase5_browser.py`, avvio WebAudio e percorso note | PASS |
| Note programmate | `phase12_future_shots.py` | PASS |
| Code rilascio | `phase12_tail_budget.py` | PASS: code normali preservate, overflow sfumato e cleanup |
| Profilo sostenuto | `phase11_sustained_profile.py`: accordi leggeri, Unison pesante, retrigger, 32 alternanze | PASS 4/4, cleanup |
| Polifonia/nodi | `phase10_polyphony_profile.py` | PASS |
| FM/Sync | `phase8_fm_sync.py`: confronto spettrale FM e Osc Sync | PASS |
| Mod Matrix | `matrix_routes_regression.py`: 200 combinazioni, modifiche su note attive | PASS |
| MIDI Clock / Sequencer | `tempo_regression.py` con eseguibile Chromium di sistema | PASS, clock esterno simulato, MIDI step input e import patch |
| Adaptive Performance | `phase13_adaptive.py`: **21** asserzioni (hardware basso/medio/alto/assente, profili, carico, benchmark, stop/failure, live note, bypass) | PASS |
| Impostazioni dopo riavvio | Due istanze di pagina con storage simulato condiviso, modalità e limiti | PASS in ambiente simulato; il comportamento persistente di storage reale resta da verificare in HTTPS/localhost |
| Interfaccia | Sezione Adaptive in Performance, 4 opzioni selezionabili | PASS in Chromium headless |

## 5. Differenze rispetto ad alpha12 e problemi corretti

- Preset factory identici byte per byte: SHA-256 **`1a886b4c9dddad1f0e07da0812f0156534c75098ed9f977cafcf0cf4e8d227c2`**.
- Tre confronti timbrici alpha12/alpha13: massimi per caso **clean=0, dual=0, unison=3.92273068e-06**. Nessun cambiamento intenzionale del percorso DSP.
- Durante la prima implementazione il budget AUTO limitava troppo aggressivamente la polifonia su patch con Unison alto. Coefficienti iniziali ritarati, seguito da **PASS** del profilo sostenuto con 8 note e 8 layer.
- Esclusi esplicitamente i controlli Adaptive dall'associazione generale di parametri serializzabili. Ripristinato bypass senza interventi governativi sulle regole di voice/release alpha12.
- Sistemata la sintassi e la coerenza dei metadati/nomi dei file di esportazione della nuova versione.
- Un'esecuzione iniziale di `tempo_regression.py` non partiva perché Playwright cercava un Chromium scaricabile assente; rieseguita con `CHROMIUM_PATH=/usr/bin/chromium`: **PASS**. Questo era un problema d'ambiente, non un bug musicale.

## 6. Limitazioni e test non verificati

1. **Non eseguiti** ascolto critico A/B su altoparlanti o cuffie, MIDI hardware, latenza fisica end-to-end, misure CPU del thread audio, underrun/dropout reali e benchmark su più macchine.
2. La verifica factory audio riproduce **un solo Do4 breve per preset**, non l'intera gamma, il carattere dopo Release molto lunga, tutte le articolazioni o combinazioni di note.
3. Il benchmark è silenzioso e limitato; i suoi pesi sono euristici, non una calibrazione scientifica di capacità DSP. Il 100% del pannello è una quota del **budget stimato**, non la CPU.
4. **Regressione `regression_r3.py` estesa non conclusa** in questa istanza (tempo d'esecuzione superiore al test run assegnato); non considerarla superata. Test equivalenti mirati su audio, note, clock, Mod Matrix e preset sono stati eseguiti separatamente e hanno avuto esito PASS.
5. Ripetere i test su browser, OS e dispositivi audio reali. L'adattamento automatico continuo alla misura dei dropout non è incluso; possibile fase alpha14.
6. Il manuale storico completo della build precedente è conservato nell'archivio completo, ma **non è stato riscritto integralmente per alpha13**: leggere l'addendum `docs/ADAPTIVE_PERFORMANCE_v0_27_0a13.md`.

## 7. Raccomandazioni alpha14

Convalidare una matrice reale di hardware/patch con dropout e latenza, registrare baseline stabili in varie classi di processori, migliorare calibrazione dei pesi, introdurre eventuale risposta a degrado in tempo reale solo con isteresi e senza interrompere note sostenute, ascoltare il trattamento delle code con riverberi intensi e testare controller MIDI reali.

## 8. Integrità distribuzione

Il packaging produce un archivio **COMPLETO** con sorgenti, preset, test, documentazione e storico, e un archivio **ESSENZIALE** con il solo runtime, licenze e note minime. Gli script runtime sono identici nei due pacchetti. La verifica conclusiva CRC/hashes di entrambi gli ZIP è riportata nell'appendice del rapporto QA esterno.
