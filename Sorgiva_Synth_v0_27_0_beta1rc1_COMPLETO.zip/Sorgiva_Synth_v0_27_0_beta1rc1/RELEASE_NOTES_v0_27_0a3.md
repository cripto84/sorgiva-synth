# Sorgiva Synth v0.27.0-alpha3 — Lookahead preparatorio e ottimizzazione risorse

## Provenienza

La base di sviluppo è **v0.27.0-alpha2 COMPLETO**, verificata contro i due ZIP alpha1 caricati successivamente dall'utente. Si è deliberatamente proseguito da alpha2 per non perdere Voice Lifecycle e trasporto audio introdotti nella fase precedente. Nessun factory preset è stato modificato.

## Cambiamenti principali

1. **Riverbero con cache LRU limitata:** il nuovo `src/audio/reverb-impulse-cache.js` conserva fino a cinque impulsi per `AudioContext` (massimo 20 MiB stimati in PCM). Se la configurazione già utilizzata ricompare, riusa lo stesso `AudioBuffer`. La cache è associata al contesto con `WeakMap`. La prima generazione di un impulso mai usato rimane sincrona: non promettiamo assenza completa di micro-pause.
2. **Riverbero lazy:** quando il riverbero è spento o il mix è zero, l'inizializzazione non genera impulsi inutili. Quando torna attivo, un impulso mancante o obsoleto viene creato o recuperato dalla cache. Inclusa correzione esplicita dei casi `rev-enabled` e `rev-mix` dopo il primo test di integrazione.
3. **Trasporto audio con preflight lookahead (65 ms):** lo scheduler `waitUntil` accetta una callback opzionale `prepare()` da eseguire poco prima della scadenza; Sequencer e Arpeggiatore la usano per leggere in anticipo i controlli pertinenti, senza generare note in anticipo. L'esecuzione musicale continua a usare le scadenze riferite a WebAudio e i callback JavaScript, dunque **non è sample accurate**.
4. **Diagnostica trasporto:** contatori di eventi preparati/trasmessi, ritardi e latenze massime, disponibili con `SorgivaSynthAudioTransport.diagnostics()` e azzerabili con `.resetDiagnostics()`.
5. **Sequencer:** eliminata la validazione/scrittura ripetuta di tutti i 32 step a ogni tick musicale. Il controllo completo resta all'avvio e nei percorsi di gestione dei pattern; i singoli step vengono comunque letti per l'esecuzione.

## Compatibilità e limiti

- Ancora 135 factory preset invariati, 229 MIDI Learn target, stesso schema JSON e stesse chiavi localStorage.
- Nessuna modifica intenzionale alla generazione delle forme d'onda, agli algoritmi sonori o ai parametri dei preset.
- `lookahead` anticipa solo la preparazione; **non** programma gli inviluppi delle note su `AudioParam` prima dello step. Non è il completamento del futuro scheduler sample-accurate.
- La cache limita i buffer trattenuti esplicitamente, non può limitare la memoria interna posseduta dai nodi `ConvolverNode` ancora attivi.
- La validazione audio completa e i test MIDI hardware restano aperti.

Vedi `QA_REPORT_v0_27_0a3.md` per i test realmente eseguiti e i limiti.
