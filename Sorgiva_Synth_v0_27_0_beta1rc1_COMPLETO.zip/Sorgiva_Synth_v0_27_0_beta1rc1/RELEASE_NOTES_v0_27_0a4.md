# Sorgiva Synth v0.27.0-alpha4 — Release notes

**Base:** v0.27.0-alpha3. **Data:** 24 ottobre 2026.

## Novità

- Time-stamped WebAudio one-shots: sorgenti, LFO, ADSR e release pianificati
  mediante `AudioContext.currentTime` e metodi WebAudio nativi per step semplici.
- Il Sequencer usa `prepare()` per programmare anticipatamente i passi senza
  Tie o Strum, preservando la via JS nei casi più complessi.
- Limite di massimo 24 voci one-shot ancora registrate, con fallback JS.
- Cancellazione delle note future a stop, panic e modifica di uno step.
- Ritiro e disconnessione del grafo dopo il reale istante di release programmato.
- Motion Engine e Sequencer non mandano più un All Notes Off globale al
  semplice cambio modalità: note MIDI e tastiera non vengono azzerate.

## Compatibilità

135 factory preset e schemi di serializzazione invariati rispetto alla alpha3.
I controlli di editing, MIDI Learn, import/export e licenza rimangono compatibili.

## Limiti

Scheduling audio anticipato per un sottoinsieme degli eventi. Timer JS tuttora
necessari per il lookahead, la UI, l'Arpeggiatore e le articolazioni complesse.
Il codice non è una garanzia di tempo perfetto per tutti i preset o su hardware
reale. Mancano test audio completi su tutta la libreria e MIDI fisico.
