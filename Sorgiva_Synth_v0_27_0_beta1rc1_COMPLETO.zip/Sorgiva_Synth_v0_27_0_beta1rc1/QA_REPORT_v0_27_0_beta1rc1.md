# Rapporto QA — Sorgiva Synth 0.27.0-beta1-rc1

**Data:** 27 ottobre 2026. **Baseline:** i due archivi alpha17 caricati dall'utente.
**Stato:** **Beta 1 Release Candidate per collaudo**, **NON** beta pubblica validata su tutte le piattaforme.

## Modifiche effettive
- Riallineate versione runtime, interfaccia e metadati delle esportazioni.
- Corretto il titolo HTML ancora ancorato al nome della fase alpha16.
- Nessuna modifica al DSP, ai file `src/audio/*.js`, al Governor o ai 135 factory preset.
- Nuova documentazione di collaudo e pacchetti di rilascio.

## Controlli eseguiti sulla candidata

| Area | Esito | Ambito reale |
|---|---|---|
| Analisi statica | 8/8 PASS | sintassi di 33 JS, JSON, asset/ID, preset, MIDI Learn, guardrail |
| Factory preset integrita dati | 135/135 PASS | banco staticamente valido e byte-identico ad alpha17 |
| Factory preset WebAudio alpha17->beta | 20/135 PASS, poi TIMEOUT | 20 carichi con NoteOn/Panic riusciti, sweep beta NON completato |
| Test musicali e compatibilita | 33/33 PASS | JSON legacy sintetico, Morph, MIDI simulato, Sequencer/Arp |
| Regressione R3 runtime | 32/32 PASS | filtri/matrix, LFO, BPM, MIDI Step, motion engine |
| Render offline R3 | 24/24 PASS | 24 condizioni controllate con campioni finiti/limiti di coda |
| Adaptive Engine base | 21/21 PASS | profili, benchmark offline, fallback |
| Adaptive Governor | 25/25 PASS | lag JS sintetico, limite nuove note, recupero, note attive |
| Stabilita voci | 30/30 PASS | 120 retrigger, 24 accordi da 6 note, 16 one-shot |
| Ottimizzazione allocator | 512/512 equivalenze PASS | stessa selezione di voce anche in pareggio |
| Release Tail Budget | PASS | budget, expedite e cleanup sul test dedicato |
| Parita audio con alpha17 | 3/3 PASS | stereo 48 kHz, 1s, 288000 campioni totali |

**Parita audio:** massima differenza assoluta 4.44334e-06, inferiore alla soglia 2e-5. Le differenze minime di Unison possono derivare da sorgenti non perfettamente deterministiche. Non e una garanzia su tutte le patch.

**R3 factory:** il processo aveva salvato 4 checkpoint completi (0-5,5-10,10-15,15-20); e stato interrotto dal limite di esecuzione senza registrare un errore applicativo. I dati dei 135 preset rimangono uguali ad alpha17 e alla copertura 135/135 della alpha16; non trasformare questa prova storica in un nuovo PASS beta per l'intero audio.

## Limiti di collaudo
1. Chromium headless (browser della suite: 144.0.7559.96) e render WebAudio offline: nessuna misura diretta di glitch, dropout, underrun o CPU del motore audio in tempo reale.
2. Nessun collaudo fisico con interfacce audio e controller MIDI eseguito in questa sessione; il riscontro dell'utente sulla alpha17 e incoraggiante ma non certifica la beta.
3. Mancano sessioni pluriorarie su OS/browser diversi, ascolto completo dei 135 timbri e importazione di tutte le varianti legacy storiche.
4. Governor AUTO usa il ritardo JavaScript come indicatore indiretto; non modifica il timbro di voci sostenute.
5. Le prove audio deterministiche hanno copertura limitata e non assicurano assenza di click in ogni combinazione.

## Gate di pubblicazione
**Decisione:** pubblicabile a piccoli tester volontari come **beta candidata** con avvertenze, non ancora dichiarabile stabile o universalmente pronta alla diffusione pubblica.
Prima di una beta pubblica piu ampia: completare lo sweep WebAudio 135/135 su beta, eseguire un test pluriorario, verificare MIDI fisico e almeno due combinazioni di browser/sistema operativo. Nessuna funzione nuova finche non sono risolti eventuali bug bloccanti.

## Riproducibilita
Script test in `tests/`; test offline beta `python tests/beta_offline_full.py`, statico `python tests/smoke_static.py`, MIDI+Morph `python tests/phase17_musical_compatibility.py`, governor `python tests/phase14_governor.py`, runtime R3 `python tests/regression_r3.py --part runtime`.
L'ESSENZIALE estratto ha superato 10/10 controlli in Chromium con i file runtime reali inlined; le restrizioni dell'ambiente non hanno consentito una navigazione diretta localhost/file://. La versione completa contiene il risultato `tests/beta_essential_smoke_results.json`.

## Collaudo del pacchetto essenziale estratto
- **10/10 PASS**: identita versione, 135 preset, tab Performance, Adaptive Profile, Governor, audio unlock, Note On, Note Off/Panic, metadati export, esclusione Adaptive da JSON.
- Eseguito con asset realmente estratti dall'ESSENZIALE e caricati come HTML/CSS/JS incorporati in Chromium; non prova una navigazione diretta mediante localhost/file:// o audio hardware.
- Il manuale editoriale esteso di progetto e storico e ancora riferito a una build precedente: aggiornamento manuale completo prima di una release stabile.
