# Sorgiva v0.27.0-alpha5 — file modificati/nuovi

- `QA_REPORT_v0_27_0a5.md (new)`
- `RELEASE_NOTES_v0_27_0a5.md (new)`
- `START_HERE_v0_27_0a5.md (new)`
- `VERSION`
- `VERSION.txt`
- `index.html`
- `src/arp/arpeggiator.js`
- `src/core/identity.js`
- `src/main.js`
- `src/midi/midi-learn.js`
- `src/presets/presets.js`
- `src/sequencer/step-sequencer.js`
- `tests/__pycache__/smoke_browser.cpython-313.pyc`
- `tests/runtime_sha256.json`
- `tests/smoke_browser.py`
- `tests/smoke_static.py`
