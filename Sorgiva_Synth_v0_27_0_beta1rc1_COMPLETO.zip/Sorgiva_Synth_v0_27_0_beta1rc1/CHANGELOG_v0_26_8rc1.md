# 0.26.8 RC1 — Engine refinement

- Fix: le voci Sustain/Hold rimangono attive dopo ricostruzione della topologia e restano rilasciabili.
- Voice stealing: livello stimato entro le priorità esistenti; protezione dei nuovi attacchi; pareggi deterministici.
- Smoothing: profili centralizzati, anchoring corrente per Matrix/Master/controller, tempi legacy conservati e nessun fallback brusco su errore.
- Morph: interpolazione semantica con gestione dello zero e rispetto dei controlli già logaritmici.
- QA: test di logica e 1.485 combinazioni Morph; nuova suite audio locale per 135 factory e pagina browser r3.
- Versioni/export aggiornati; 135 factory e formati dati invariati.

Stato RC: test statici e di logica PASS; test browser/audio non eseguiti. Rebuild ADSR e transizioni Drive/Reverb restano da approfondire. Leggere QA_REPORT_v0_26_8rc1.md.
