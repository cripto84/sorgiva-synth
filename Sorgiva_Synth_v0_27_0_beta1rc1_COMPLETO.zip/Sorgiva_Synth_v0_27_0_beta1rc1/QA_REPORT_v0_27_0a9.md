# QA Sorgiva Synth v0.27.0-alpha9

**Data:** 26 ottobre 2026. **Base:** i due ZIP alpha8 forniti dall'utente. **Stato:** alpha, controlli sotto elencati superati, non certificazione hardware/percezione.

## Verifica della base

- ZIP sorgenti alpha8 completi ed essenziali: CRC validi; 48 file condivisi confrontati byte per byte, 0 differenze.
- 32 file JavaScript, JSON, riferimenti HTML, 135 factory preset e 229 target MIDI Learn: **PASS** nei controlli statici.
- Node `refinement.cjs`: **PASS**, compresi 1.485 confronti del Preset Morph.
- Chromium `smoke_browser.py`: **PASS**, AudioContext running, note-on, note-off, zero voci rimaste.

## Nuova fase: 135 factory preset verificati realmente

- `factory_apply_batched.py`: **135/135 PASS**, normalizzazione/applicazione dei preset, costruzione snapshot e immutabilità dei dati.
- `phase9_factory_audio.py` in contesti OfflineAudioContext separati: **135/135 PASS** come prova audio breve, con 0 errori o campioni NaN/Infinity e tutti i Note Off applicati.
- Segnale massimo (picco assoluto per render): **0.00004328–0.390089**; nessun preset con picco inferiore a 1×10⁻⁷ nel singolo registro testato.
- Metodo del render: **mono, 24.000 Hz, 1 secondo, Do4, velocity 0,7, rilascio a 240 ms**, motore e catena globale del preset presenti. Queste prove NON coprono code integrali di riverbero/Delay, accordi estesi, tutti i registri, listening test o MIDI hardware.
- File risultati: `tests/phase9_factory_audio_results.json` con una riga per ciascuno dei 135 preset e log di rendering intermedi. Il processo a intervalli evita che una singola lunga sessione oscuri i risultati già completati.

## Ottimizzazione mirata DSP

- `src/audio/audio-context.js`: `createVoice()` verifica la presenza di sorgenti prima di costruire il grafo per-voce. Se Osc 1/2/3 non producono suono e Noise è spento, torna senza allocare filtri, LFO o inviluppi. Resta il controllo dopo la costruzione, come protezione di secondo livello.
- Test specifico senza sorgenti e con LFO filtro abilitato: **0 nodi allocati**, 0 voci create, 0 oscillatori orfani. Il vecchio test di regressione è stato aggiornato perché in questa condizione nessun LFO deve più essere creato.
- Il file dei 135 factory preset è **identico bit per bit** al corrispondente asset alpha8; algoritmi sonori delle patch con almeno una sorgente non modificati intenzionalmente.

## Profiling della costruzione dei grafi (Chromium, singola esecuzione)

| Scenario (4 note) | OscillatorNode creati | Nodi WebAudio totali contati | Tempo totale setup JS (ms) | Cleanup dopo Panic |
|---|---:|---:|---:|---|
| one-osc-four-notes | 4 | 36 | 14.5 | Sì |
| three-osc-four-notes | 12 | 60 | 6.3 | Sì |
| three-osc-unison-six-four-notes | 72 | 276 | 10.8 | Sì |
| three-osc-unison-six-filters-four-notes | 72 | 292 | 19.4 | Sì |

Queste sono **allocazioni di nodi e tempo JavaScript di avvio**, con sensibilità a cache, scheduler e macchina di prova. Non rappresentano carico CPU audio sostenuto, utilizzo RAM del processo né affidabilità di una DAW su computer diversi. Il test `phase9_performance.py` può essere ripetuto localmente.

## Regressioni browser sulla alpha9

- `pulse_bandlimited_regression.py`: **PASS**.
- `phase8_fm_sync.py`: **PASS** (FFT/FM Guarded).
- `phase6_browser.py`: **PASS** (Arpeggiatore/Strum).
- `dsp_cache_regression.py`: **PASS**.
- `matrix_routes_regression.py`: **PASS**, 200 combinazioni (necessario `CHROMIUM_PATH=/usr/bin/chromium` in questo ambiente).
- `consolidamento_browser.py`: **PASS** dopo aggiornamento dell'aspettativa sulla patch priva di sorgenti; l'attesa originale, che richiedeva la creazione di un LFO inutile, non è più appropriata.

## Integrità degli archivi finali

- ZIP completo: **969 file**, ZIP essenziale: **53 file**. Test CRC di entrambi **PASS**, i 53 file condivisi sono identici, 968 hash del manifesto del completo verificati.
- La distribuzione essenziale è stata estratta e provata in Chromium con le risorse incorporate dalla stessa cartella: **PASS**, versione alpha9, 135 preset presenti, `AudioContext` in stato running, una nota attiva durante il Note On e zero voci/code dopo il rilascio. La navigazione diretta `file://` non è stata verificata nell'ambiente sandbox.

## Limiti aperti / prossimi controlli

1. CPU DSP real-time e dropout/xrun misurati su più macchine reali, con Unison 8–12 e polifonia elevata.
2. Analisi delle code complete e dei picchi di ogni preset in stereo e su più registri; confronti timbrici α8/α9 automatizzati e ascolto critico.
3. Controller MIDI fisico e differenze Chromium/OS.
4. Documentazione lunga storica: il manuale conservato nello ZIP completo si riferisce anche a versioni precedenti e richiede allineamento editoriale specifico per alpha9.

**Conclusione:** la alpha9 supera la suite statica, il caricamento e il render **breve** dei 135 preset e le regressioni citate. È idonea alla successiva prova musicale, ma resta sperimentale.
