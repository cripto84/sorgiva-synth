# QA — Sorgiva Synth v0.27.0-alpha3

Data: 24 ottobre 2026. Ambiente: Python/Node.js, Chromium headless con WebAudio. Questi test non rappresentano ascolto umano né test con MIDI fisico.

## Ingresso e baseline

- Gli ZIP alpha1 completo/essenziale caricati nel turno corrente risultano identici byte per byte alle rispettive copie precedenti.
- Gli ZIP alpha1 **non** sono l'ultimo baseline: alpha2 è disponibile nella stessa sessione ed è stata verificata prima di proseguire.
- Baseline alpha2: controlli ZIP, statici, `refinement.cjs`, `smoke_browser.py`, `phase3_browser.py` PASS.

## Test alpha3

| Test | Stato | Portata |
|---|---|---|
| `python tests/smoke_static.py` | PASS | Sintassi di 29 JS, asset HTML, JSON, 135 preset, 229 target MIDI Learn |
| `node tests/refinement.cjs .` | PASS | Algoritmi e 1485 confronti Preset Morph |
| `python tests/smoke_browser.py` | PASS | Avvio, WebAudio, suono sintetico e note off |
| `python tests/consolidamento_browser.py` | PASS | Regressioni introdotte nel consolidamento 0.26.9 |
| `python tests/phase2_browser.py` | PASS | Ownership note, voice stealing, clock a scadenze |
| `python tests/phase3_browser.py` | PASS | Voice lifecycle, sospensione e ripresa AudioContext |
| `CHROMIUM_PATH=/usr/bin/chromium python tests/tempo_regression.py` | PASS | Clock MIDI simulato, divisioni, Delay e LFO |
| `CHROMIUM_PATH=/usr/bin/chromium python tests/matrix_routes_regression.py` | PASS | 200 combinazioni Mod Matrix |
| `python tests/phase4_browser.py` | PASS | Cache impulsi, bounded memory, riutilizzo, lookahead, nessun anticipo di dispatch, sospensione |
| `python tests/factory_apply_batched.py 0 20` | PASS | Applicazione e roundtrip di 20 factory preset in Chromium |
| `python tests/factory_apply_batched.py 20 70` | INCOMPLETO (timeout) | Ulteriori 25 preset completati senza errori, test non terminato |
| Render audio completi dei 135 preset | NON ESEGUITO | Richiede una suite dedicata a lotti e una maggiore finestra di calcolo |
| Ascolto umano e controller MIDI hardware | NON ESEGUITO | Da validare con dispositivo fisico e su più browser/OS |

Totale factory preset applicati nella prova a lotti: **45 su 135**, senza errori nei lotti conclusi. I 135 su 135 sono stati verificati unicamente per struttura e integrità statica.

## Misura mirata

Con ritorno Room → Hall → Room a reverb abilitato, i contatori cache sono passati da due miss a un hit, senza nuova generazione dell'impulso Room. Nel test di un evento a 220 ms, `prepare()` è avvenuta circa 90 ms prima del callback e il dispatch circa 0,6 ms dopo la scadenza nell'ambiente sintetico. Un singolo campione temporale NON giustifica una dichiarazione di jitter garantito.

## Stato del rilascio

**Alpha funzionale nelle aree testate**, non release stabile certificata. I controlli brevi superati non escludono problemi di CPU, browser throttling, lunghe sessioni live o qualità sonora. L'attivazione del reverb può ancora richiedere generazione sincrona per configurazioni mai viste; l'implementazione realmente anticipata di note/inviluppi rimane una fase distinta.
