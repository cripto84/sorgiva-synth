# Sorgiva Synth v0.27.0-alpha5 — Note di rilascio

Data: 24 ottobre 2026. Base: v0.27.0-alpha4 (ZIP completi ed essenziali caricati dall’utente).

## Modifiche

- `src/arp/arpeggiator.js`: preparazione temporizzata WebAudio delle note di Arpeggiatore con selezione anticipata non distruttiva del cursore. Le note vengono effettivamente lanciate al timestamp audio. Invalidazione delle prenotazioni su modifica di input, controlli, MIDI Clock e arresto. Nuova diagnostica `getPreparedAudioDiagnostics()`.
- `src/sequencer/step-sequencer.js`: one-shot timestamped estesi agli accordi con Strum breve purché ogni nota cominci e termini entro il gate. La durata è compensata per l'offset Strum. Fallback invariato per Tie, Strum troppo lungo e casi non compatibili.
- Il controllo che evita un secondo Note On su eventi Strum preparati viene ora catturato nella callback ritardata: elimina un rischio di doppio attacco.
- Versione ed etichette aggiornate. Schema dei preset e dei pattern invariato; 135 factory preset immutati.

## Limitazioni

- La preparazione del lookahead continua a dipendere da callback JavaScript. Solo i one-shot accettati da `scheduleOneShot` sono programmati sul clock audio; in altri casi è usato il percorso JS.
- Gli one-shot catturano la configurazione audio al momento della preparazione e non riflettono necessariamente un controllo espressivo cambiato nel brevissimo intervallo precedente all'attacco.
- Un nuovo accordo può invalidare una nota futura. Il percorso di disattivazione applica uno smorzamento, senza garantire cancellazione DSP a precisione di campione.
- I test non sono ascolto umano né convalida hardware di jitter/aliasing. Build sperimentale, non release stabile.
