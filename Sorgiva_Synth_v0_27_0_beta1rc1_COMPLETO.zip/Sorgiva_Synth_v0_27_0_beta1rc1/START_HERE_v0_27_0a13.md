# Primo avvio — alpha13

1. Estrai il pacchetto; apri `index.html` (oppure avvia un server statico locale per WebMIDI).
2. Premi **Sblocca Audio** e prova una nota.
3. Apri **Performance → Adaptive Performance**. AUTO è il profilo iniziale.
4. A synth inattivo usa **Ripeti benchmark silenzioso**. I numeri confrontano rendering offline e non indicano la percentuale di CPU reale.
5. Se desideri meno risorse seleziona ECO; per configurazioni più complesse seleziona STUDIO; per limiti numerici scegli MANUALE.
6. Disattiva l'adattamento per ripristinare le regole di allocazione di alpha12 (con Max Voices originale).

**Attenzione:** verificare suono/latency con hardware reale prima di una performance dal vivo.
