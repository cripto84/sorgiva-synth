# File modificati per alpha14

- `src/performance/adaptive-performance.js`: monitor foreground, policy a isteresi, down/up step, interfaccia e test API.
- `src/audio/audio-context.js`: accettazione prudente delle nuove note live/scheduled; preservazione voci esistenti, release invariata.
- `src/presets/presets.js`: esclusione di parametri Adaptive dal JSON e filtraggio dei vecchi input.
- `index.html`: titolo/versione, nuovi indicatori governor nella scheda Performance.
- `src/main.js`, `src/core/identity.js`, `src/presets/presets.js`, `src/sequencer/step-sequencer.js`, `src/midi/midi-learn.js`: metadati e nomi export alpha14.
- `VERSION`, `VERSION.txt`, `README.txt`, `CHANGELOG.txt`, `tests/smoke_static.py`: versione e istruzioni.
- `tests/phase14_governor.py`, `tests/phase14_governor_results.json`: 25 assert del governor con segnali sintetici.
- Addendum e rapporto QA; runtime SHA256.

Nessuna modifica ai factory preset, ai moduli DSP e alla licenza.
