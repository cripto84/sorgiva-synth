# Sorgiva Synth v0.27.0-alpha12 — Release Notes

**Base:** v0.27.0-alpha11. Nessuna modifica intenzionale ai timbri ordinari, ai factory preset o agli schemi di import/export.

- Budget dei grafi in Release: limite prudente secondo numero di voci e generazioni oscillator/unison. Le code più vecchie sono selezionate soltanto quando si superano le soglie (almeno 24 code / 320 generatori, soglie maggiori con Max Voices elevato).
- L'uscita delle voci selezionate si attenua su circa 48 ms; gli oscillatori vengono arrestati intorno a 60 ms, con disconnessione del grafo successiva. Le voci attive e le note pianificate nel futuro non sono sacrificate dal budget.
- `voice-lifecycle.js` supporta ora `expedite()`, con timer e scadenze audio coerenti anche dopo una precedente pianificazione di stop.
- Il comando di annullamento delle one-shot programmate anticipa anche lo stop dei relativi generatori e la disconnessione, anziché conservare le allocazioni fino alla scadenza originaria.
- Nuovi test headless `phase12_tail_budget.py` e `phase12_future_shots.py`, statistiche diagnostiche `getVoiceManagementStatus().tailBudget`.

**Limitazioni:** sotto sovraccarico le code più vecchie vengono abbreviate: non è garantita perfetta trasparenza all'ascolto nel caso estremo. Nessuna misurazione dell'utilizzo CPU del thread audio, del jitter end-to-end o di dropout su hardware reale. La release rimane alpha.
