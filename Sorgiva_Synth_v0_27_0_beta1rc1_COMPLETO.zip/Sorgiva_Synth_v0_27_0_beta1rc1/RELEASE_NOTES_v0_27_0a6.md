# Sorgiva Synth v0.27.0-alpha6 — Note di rilascio

Data: 26 ottobre 2026. Base: v0.27.0-alpha5 caricata dall'utente, verificata con CRC e confronto SHA-256.

## Cambiamenti

- `src/audio/audio-context.js`: cache LRU delle curve del Filter Drive, chiavi fondate sui valori esatti utilizzati nella generazione. Evita di eseguire la funzione matematica per ogni voce identica. Massimo 64 curve da 4096 campioni Float32 (1 MiB massimo di dati JS), con riutilizzo anche sugli aggiornamenti live.
- `src/audio/audio-context.js`: cache LRU massima di 64 `PeriodicWave` per Osc Sync. La precedente cache cresceva senza un limite esplicito.
- `SynthXAudio.getDspCacheStatus()`: contatori di hit, miss, eviction e dimensione delle cache, per QA e profiling; non influenza il suono.
- Versione, stringhe UI, nomi dei file esportati e documentazione di avvio aggiornati. Chiavi di storage, formati dei preset e contenuti dei 135 factory preset invariati.
- Test aggiunti: `tests/dsp_cache_regression.py`, `tests/dsp_audio_compare.py`, `tests/dsp_alias_probe.py`.

## Risultati

- Otto voci con Filter Drive identico: un solo calcolo curva, poi sette riutilizzi. Al cambio di Amount: un altro calcolo, sette riutilizzi.
- Tre render WebAudio deterministici (sine/clean, saw/warm, triangle/dirty), 21.600 campioni ciascuno: differenza assoluta massima **0.0** rispetto alla alpha5 nel browser di prova.
- Test di saturazione della cache: 64 voci logiche di cache massime, eviction funzionante; nessuna eccezione riscontrata durante la prova.
- Diagnostica sperimentale aliasing a 48 kHz / 5300 Hz: native saw e waveshaper pulse mostrano differenze importanti. La misura non riguarda tutte le patch ed è solo esplorativa. Nessun algoritmo è stato sostituito.

## Limiti

La riduzione di calcoli di **preparazione** delle curve non equivale a una misurazione di riduzione del carico audio per campione. I render audio completi di tutte le factory patch, la prova con MIDI fisico e l'ascolto comparativo restano aperti. La release rimane alpha.
