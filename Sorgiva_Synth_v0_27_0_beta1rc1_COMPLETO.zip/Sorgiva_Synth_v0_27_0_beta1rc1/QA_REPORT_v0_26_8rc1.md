# Sorgiva Synth 0.26.8 RC1 — QA report

**Modifiche effettive al motore. Stato: RELEASE CANDIDATE con QA audio aperta.**

Input: 0.26.7r3-audio-matrix-tempo-fixes, archivio COMPLETO fornito. Output: 0.26.8rc1-engine-refinement. Data: 11 settembre 2026.

Il precedente checkpoint non conteneva modifiche. Questa RC contiene correzioni e raffinamenti; non è dichiarata GOLD né interamente verificata. L'utente ha chiesto esplicitamente di procedere dopo la spiegazione del blocco browser. Sono stati eseguiti test statici e di logica; la policy browser già incontrata impedisce le prove locali WebAudio in questa sessione. Nessun aggiramento tentato. Nessun risultato storico è presentato come nuova esecuzione.

## Correzioni e risultati

| Intervento | Motivazione / cambiamento | Esito |
|---|---|---|
| Sustain/Hold durante rebuild | La r3 ricreava soltanto le note fisicamente premute. Ora conserva anche le voci sustained, con velocity e flag, senza aggiungerle alle note premute. La normale procedura di rilascio resta responsabile di spegnerle. | Test di logica PASS: 100 rebuild, conservazione note e velocity, successivo rilascio, nessuna resurrezione di voci non sostenute. Audio NON TESTATO. |
| Voice stealing | Conservata la priorità fra voci sostenute/non più premute e voci premute. A pari priorità si considera livello ADSR stimato × velocity. Gli attacchi in corso ricevono protezione; età e ID risolvono i pareggi. | Test di selezione PASS. Non è un loudness meter: timbro, risonanza e FX non sono stimati. |
| Release e polifonia | Le code rilasciate erano già fuori dalla Map delle voci attive; restano protette da questa separazione. | Comportamento architetturale conservato. Nessuna nuova regola sul numero di code. |
| Smoothing | Esteso helper esistente con instant/fast/musical/slow e tempo opzionale. Centralizzati Matrix Amount, Master, Mod Wheel ed Expression. Conservate le costanti numeriche dei chiamanti, compreso Pitch Bend a 10 ms. | Test di scheduling con spy PASS: hold → target, fallback ancorato, tempi, input non finiti, profilo instant. Non misura campioni audio. |
| Micro-transizioni Matrix | Il percorso Amount ora usa cancelAndHoldAtTime quando disponibile, prima del nuovo target; mantiene la costante di 12 ms. Evita la cancellazione non ancorata del vecchio helper. | Sequenza di operazioni verificata; beneficio udibile NON TESTATO. La riconciliazione delle sorgenti r3 rimane invariata. |
| Morph | Rate/tempi fisici positivi e livelli oscillatore positivi: interpolazione logaritmica. Tempi ADSR: log1p con riferimento 1 ms, inclusi endpoint zero. Livelli con endpoint zero: lineare. Cutoff già log-normalizzati, dB e pan restano lineari nella propria rappresentazione. | 135 coppie factory adiacenti × 11 rapporti = 1.485 combinazioni PASS: finitezza, range, endpoint entro quantizzazione UI, discreti da A e immutabilità dei dati. |
| Factory audio regression | Nuovo `tests/factory_audio.py`: 135 render stereo a 48 kHz con note basse/medie/alte, accordo, otto note rapide, release naturale e finestra lunga di coda. | Script compilato; esecuzione WebAudio NON TESTATA. Non è lecito contarlo come 135 audio PASS. |

I profili fast/musical/slow hanno costanti 8/18/45 ms. Una costante esponenziale non è la durata di completamento della transizione. Gli inviluppi e gli eventi musicali schedulati non sono stati sostituiti da questi profili. In caso di errore di scheduling l'helper restituisce false, senza forzare una discontinuità con `.value`.

## De-click e compatibilità

Preservati i profili adattivi r3 (normale, low-harmonic, low-harmonic con Noise), il release con stima dell'inviluppo, gli attacchi e il comportamento dei transienti. Nessun crossfade universale o modifica al gain staging introdotti senza una prova audio.

Non sono cambiati: formato patch, factory data, User Bank, pattern, Behavior Macro, MIDI Learn mapping, A/B, protocolli MIDI/Clock, logica Step Input, struttura UI e caricamento a script classici. Le stringhe di versione e i suffissi degli export identificano RC1. La compatibilità statica è verificata; il comportamento end-to-end file:// e localhost resta da verificare nel browser.

I 135 factory preset mantengono esattamente lo stesso file SHA-256 della r3. La classificazione dei controlli Morph tiene conto del fatto che cutoff e Advanced Filter frequency sono già codificati su scala logaritmica: una seconda applicazione del log sarebbe scorretta. Il pan di StereoPanner rappresenta già una posizione sulla legge equal-power. I discreti restano A: Morph 100% non equivale necessariamente a Load B.

## Test effettivamente eseguiti

- `python3 tests/smoke_static.py`: PASS (versioni/export; sintassi dei 24 JS; JSON; asset/ID HTML; 135 factory univoci e numeri finiti; 229 target MIDI Learn e copertura; guardie statiche; superficie runtime).
- `node tests/refinement.cjs`: PASS, otto gruppi di test con 1.485 confronti Morph. Usa le funzioni reali del codice e dipendenze esplicitamente simulate dove occorre; non simula né certifica WebAudio.
- Compilazione Python della nuova suite audio e generazione della pagina browser: eseguite.
- Integrità degli ZIP e identità dei file runtime fra completo ed essenziale: verificate nel packaging.
- La baseline r3 era stata verificata staticamente e il difetto di perdita sustained riprodotto nel precedente checkpoint.

## Prove ancora aperte

Tutti i test browser r3 (runtime, 24 render de-click, Matrix, tempo, Step Input) devono essere rieseguiti sulla RC. La nuova suite factory deve essere eseguita e, se emergono falsi positivi o problemi, corretta senza alterare i preset per farli passare.

Non verificati qui: output audio reale, NaN/Infinity nei campioni, click/pop udibili, transienti, prestazioni e CPU, voice zombie reali, cleanup dei nodi/timer, Panic sulle code pregresse, tutte le waveform e combinazioni PWM/FM/Ring/Sync/Unison, Mono/Glide, filtri e risonanza, tutti gli FX e cambi algoritmo, clock esterno/fallback, tie/accent/chord/gate, import/export end-to-end, A/B/Randomizer/Undo, Apply/Restore/Live Preview Morph. MIDI hardware e ascolto umano richiedono dispositivi reali.

La suite `factory_audio.py` verifica: presenza di sorgenti, tutti i campioni finiti, peak ≤1,01, energia non nulla, coda finale <0,0001, voci marcate released e nessuna nota nel registro del test. Queste soglie sono verifiche numeriche iniziali, non una certificazione di qualità musicale. Le voci sono create/rilasciate con hook privati iniettati solo nella pagina di test; il normale noteOn/noteOff/Panic si verifica con la suite runtime separata. I timer di cleanup usano tempo reale mentre OfflineAudioContext usa tempo audio: render particolarmente lenti richiedono diagnosi del test, non modifiche arbitrarie al motore.

## Registro difetti e limiti

- SG-001: perdita Sustain/Hold durante rebuild — **FIXED, logica verificata; audio da verificare**.
- SG-002: selezione a sola età — raffinata e testata nella logica; valutazione musicale aperta.
- SG-003: Morph uniformemente lineare — raffinato e testato numericamente; ascolto aperto.
- SG-004: rebuild riavvia ancora Amp/Filter ADSR — **rischio noto ancora aperto**, nessuna promessa di continuità d'inviluppo su cambi strutturali. Fix dedicato richiede confronto audio.
- SG-005: curve Drive e impulsi Reverb sostituiti dopo debounce — **rischio di artefatti da misurare**, non corretto con crossfade non verificati.

Le cinque priorità originali non sono dichiarate interamente concluse: smoothing/stealing/Morph hanno modifiche verificabili nella logica; de-click e QA factory audio restano parzialmente aperti. Le rifiniture opzionali non sono state introdotte.

## Manuale v2.1: aggiornamenti necessari

- 29.8 e 29.10: sostituire la descrizione uniforme dei valori intermedi con le famiglie semantiche.
- 29.27–29.33 e 36.45: specificare log dei rate fisici e livelli positivi, log1p dei tempi ADSR, caso zero, cutoff già normalizzati e discreti mantenuti da A.
- Capitolo 17 e parti sulla polifonia: descrivere selezione per stato, livello stimato, protezione attacchi, età/ID e separazione delle code Release.
- Capitoli 13/17: nota correttiva per Sustain/Hold durante ricostruzione, senza promettere conservazione della fase ADSR.
- 11.67: aggiornare il già precedente disallineamento con la riconciliazione live della Matrix r3; aggiungere smoothing unificato Amount.
- Capitolo 33: aggiungere suite factory e separare PASS logico, numerico audio e ascolto.

Il manuale originale non è stato riscritto.

## Avvio e ripresa

Aprire `index.html` come prima. Per i test vedere `tests/README_RC1.txt`.
La prossima attività è il confronto audio r3/RC1, prima di promuovere la build a versione stabile.
