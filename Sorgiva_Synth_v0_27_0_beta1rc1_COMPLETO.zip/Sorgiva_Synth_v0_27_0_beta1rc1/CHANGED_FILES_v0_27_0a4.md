# Modifiche rispetto alla alpha3

- src/audio/audio-context.js — one-shot programmati e diagnostica
- src/audio/voice-lifecycle.js — smaltimento per release futura
- src/sequencer/step-sequencer.js — note anticipate per step semplici
- src/motion/motion-engine.js — esclusione senza All Notes Off indiscriminato
- src/arp/arpeggiator.js — toggle che rispetta note MIDI/manuali
- src/core/identity.js, src/main.js, src/midi/midi-learn.js, src/presets/presets.js — metadata/versione
- index.html, VERSION, VERSION.txt, README.txt — presentazione alpha4
- tests/smoke_static.py — aspettative per alpha4
- tests/phase5_browser.py e tests/phase5_audio_signal.py — nuovi controlli
- documentazione alpha4 e manifest SHA-256
