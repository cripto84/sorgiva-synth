# Sorgiva Synth 0.27.0-alpha7 — Inizia qui

1. Estrai integralmente la distribuzione e apri `index.html` su browser Chromium desktop.
2. Premi **Sblocca Audio**, poi prova la tastiera inferiore.
3. Per sentire la nuova modalità: Oscillatori & LFO → forma `pulse` →
   **Pulse/PWM Quality** → `Band-limited (sperimentale)`.
4. Per riprodurre esattamente il comportamento delle patch storiche, lascia `Classic`.
5. Se usi PWM molto estrema, il synth seleziona internamente il percorso Classic.
6. Conserva una copia delle patch prima di provarne la variante HQ.

Per controller MIDI: avvia un server locale (`python3 -m http.server 8000`)
e usa Chrome/Edge. I 135 factory preset non sono stati modificati.

Leggi `RELEASE_NOTES_v0_27_0a7.md` e `QA_REPORT_v0_27_0a7.md`.
