# File modificati o aggiunti — v0.27.0-alpha9

- `src/audio/audio-context.js` — salto preventivo della creazione di grafi per patch senza sorgenti.
- `src/core/identity.js`, `index.html`, `VERSION`, `VERSION.txt` — versione.
- `src/presets/presets.js`, `src/arp/arpeggiator.js`, `src/sequencer/step-sequencer.js`, `src/midi/midi-learn.js` — metadati di export e suffissi nuovi.
- `tests/smoke_static.py`, `tests/smoke_browser.py` — versione attesa.
- `tests/consolidamento_browser.py` — test no-source compatibile con l'ottimizzazione.
- `tests/phase9_performance.py`, `tests/phase9_factory_audio.py` — suite prestazionale e audio (nuovi).
- `tests/README_v0_27_0a9.md`, `tests/phase9_*results*.json` — esecuzione e risultati.
- `README.txt`, `START_HERE_v0_27_0a9.md`, `RELEASE_NOTES_v0_27_0a9.md`, `QA_REPORT_v0_27_0a9.md`, `SHA256SUMS.txt` — distribuzione e QA.

Tutti i 135 factory preset sono invariati rispetto alla v0.27.0-alpha8.
