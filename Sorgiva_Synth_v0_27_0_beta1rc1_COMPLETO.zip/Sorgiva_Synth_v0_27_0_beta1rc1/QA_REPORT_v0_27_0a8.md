# Sorgiva Synth v0.27.0-alpha8 — Rapporto QA

**Data:** 26 ottobre 2026. **Base:** i due ZIP alpha7 caricati dall'utente. Questa è una verifica automatizzata dei percorsi indicati, non una certificazione sonora complessiva.

## Base e regressioni

| Verifica | Esito |
|---|---|
| ZIP alpha7 completo/essenziale | PASS — `ZipFile.testzip()` |
| Sintassi JS (32 file), JSON, assets, 135 preset e 229 target MIDI Learn | PASS — `smoke_static.py` |
| Test logici: Sustain, Hold, voice stealing, Morph (1.485 confronti) | PASS — `refinement.cjs` |
| Avvio WebAudio, una nota e rilascio, UI | PASS — `smoke_browser.py` |
| Pulse/PWM HQ della alpha7 | PASS — `pulse_bandlimited_regression.py` |
| Regression consolidamento, voice allocator e lifecycle | PASS — `consolidamento_browser.py`, `phase2_browser.py`, `phase3_browser.py` |
| Trasporto, note programmate, Sequencer, Arpeggiatore/Strum | PASS — `phase4_browser.py`, `phase5_browser.py`, `phase6_browser.py` |
| MIDI Clock simulato | PASS — `tempo_regression.py` |
| Mod Matrix, 200 combinazioni | PASS — `matrix_routes_regression.py` |
| Cache DSP e suo limite | PASS — `dsp_cache_regression.py` |
| Nuovo test FFT, FM Guarded, voce FM/Sync reale, import preset legacy | PASS — `phase8_fm_sync.py` |
| Rendering completo dei 135 preset e ascolto musicale | NON ESEGUITO integralmente |
| MIDI hardware fisico, benchmark CPU real-time multidevice | NON ESEGUITO |

## FFT Osc Sync

Fourier FFT radix-2 (2048 campioni, primi 64 coefficienti) confrontata con DFT diretta su sinusoide, saw, pulse e dati pseudocasuali. Errore assoluto massimo fra tutti i coefficienti: **2,51 × 10⁻⁸** nel test Chromium. L'FFT è usata dal generatore reale di PeriodicWave, con percorso diretto di fallback. La cache LRU non cambia.

Misura esplorativa nello stesso browser: ~0,23–0,42 ms per singola FFT e ~7–8,4 ms per sola iterazione trigonometrica del vecchio DFT; dipende dal run e non è una misura del consumo CPU audio per voce o del costo totale `createPeriodicWave`.

## FM High-note Quality: Guarded

Il trattamento opzionale pone `deviation = min(classicDeviation, max(0, 0,44 × sampleRate − carrierHz − 2 × modulatorHz))`. Formula prudente derivata da una stima delle sideband; **non garantisce l'assenza di aliasing** e può cambiare sensibilmente il timbro. I preset esistenti e quelli privi di `fm-quality` scelgono `classic`.

Render dimostrativo offline a 48 kHz, carrier sine 6500 Hz, modulatore sine 5700 Hz, modulazione forte: componente ripiegata dell'upper sideband +4 a **18.700 Hz**. Risultati rispetto alla fondamentale carrier: Classic **−6,98 dB**, Guarded **−70,12 dB** nel caso misurato; la deviazione usata passa da 26.790 Hz a 3.220 Hz. Il confronto riguarda **una sola frequenza spettrale e un solo assetto**: non implica un miglioramento uguale sull'intero spettro o su altri modulatori.

Cambi FM Amount, tuning e pitch bend aggiornano in modo controllato la profondità; l'arresto delle note lascia zero voci e zero release tails nella regressione mirata.

## Compatibilità

- Factory preset: 135/135 validi e codice dati invariato rispetto ad alpha7.
- Export nuovi con suffisso alpha8; formati di serializzazione legacy compatibili.
- FM/Pulse Classic invariati per default. Osc Sync produce coefficienti numericamente equivalenti entro la precisione testata, senza garanzia di identità bitwise per qualsiasi audio.
- Uno ZIP completo mantiene documentazione, test e storico; essenziale contiene il runtime, licenze e note correnti.

## Limiti aperti

La suite completa dei 135 preset in una stessa sessione e i test di ascolto/MIDI hardware restano incompleti. Servono misure percettive, confronto audio multi-browser, stress Unison alto e profili CPU reali prima di una release stabile. La build **rimane alpha**.
