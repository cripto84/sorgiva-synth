# Sorgiva Synth v0.27.0-alpha2 — Rapporto QA (24 ottobre 2026)

## Base e integrità

Sorgente: ZIP `Sorgiva_Synth_v0_27_0a1_COMPLETO(1).zip` fornito dall'utente. Archivio leggibile, senza voci ZIP corrotte. Nuove patch prodotte sopra il contenuto estratto; vecchio archivio non modificato. File `src/presets/factory-presets.js` invariato a livello di byte rispetto alla base. 135 factory preset e 229 target MIDI Learn presenti. I formati JSON, il formato delle patch e le chiavi di storage non sono stati cambiati.

## Test eseguiti sulla nuova build

| Verifica | Esito | Limiti |
|---|---|---|
| `python tests/smoke_static.py` | PASS | Sintassi, risorse, preset e copertura MIDI Learn |
| `node tests/refinement.cjs .` | PASS | Logica, compresi 1.485 confronti Morph; non ascolto |
| `python tests/smoke_browser.py` | PASS | Chromium headless / WebAudio sintetico |
| `python tests/consolidamento_browser.py` | PASS | Note sorgenti, LFO, editing e Morph |
| `python tests/phase2_browser.py` | PASS | Voice allocation, ownership e trasporto alpha1 |
| `python tests/phase3_browser.py` | PASS | Transizioni delle voci, rilascio idempotente, polifonia, AudioContext suspend/resume, scadenze audio |
| `python tests/tempo_regression.py` | PASS | MIDI Clock sintetico, BPM, Delay sync, LFO sync |
| `python tests/matrix_routes_regression.py` | PASS | 200 combinazioni con nota trattenuta; cap pitch 180 |
| `python tests/factory_apply_quick.py` | NON COMPLETATO (timeout 90 s) | Il ciclo di import/applicazione di 135 preset in un'unica pagina è costoso; non è un test PASS |
| `python tests/factory_audio.py` | NON ESEGUITO | Render completo 135 preset non certificato |
| `python tests/regression_r3.py` | NON ESEGUITO in questa sessione | Suite estesa non certificata |
| Ascolto umano + controller MIDI fisico | NON ESEGUITO | Da completare fuori da Chromium headless |

I test browser usano principalmente HTML/script caricati inline per compatibilità con gli ambienti dove `localhost` può essere bloccato; ciò non equivale alla verifica su tutti i browser. Nessuna promessa di scheduling sample-accurate: i callback restano sul main thread JS.

## Nuovi moduli e modifiche

- `src/audio/voice-lifecycle.js` — macchina a stati `active / release / disposed` per voce, un timer finale di cleanup e callback unico; guardie contro il doppio rilascio, tolleranza alla sospensione del contesto audio, watchdog di 30s aggiuntivi.
- `src/audio/audio-context.js` — registra voci create, delega contabilizzazione delle code e disconnessione finale, espone le metriche `lifecycle` nella diagnostica. La generazione sonora e le curve degli inviluppi non sono state modificate.
- `src/motion/audio-transport.js` — scadenze monotone riferite a `AudioContext.currentTime` quando esiste e fallback a `performance.now()` prima dell'inizializzazione. Non avanza il sequencer durante sospensione WebAudio; niente catch-up burst.
- `src/sequencer/step-sequencer.js` e `src/arp/arpeggiator.js` — passi e gate pianificati tramite il nuovo clock; preservati i controlli di token/cancellazione, gli eventi MIDI e le regole di tie, latch e swing.
- `index.html` — inclusione dei due moduli; metadati `VERSION`, `src/core/identity.js`, export filename e guida allineati ad alpha2.

## Problemi ancora aperti

1. **Affidabilità temporalmente rigorosa**: il trasporto usa l'audio clock come riferimento, ma le note sono ancora generate quando arriva un callback JavaScript. Non implementa ancora pre-scheduling WebAudio, look-ahead verso AudioParam o AudioWorklet.
2. **Rischio di CPU/DOM**: ciclo di applicazione di tutti i 135 preset ha raggiunto il timeout. Servono profiling sistematico e test a lotti anziché inferire che ogni preset sia stato verificato.
3. **Release sotto carico**: testate condizioni circoscritte e polifonia breve; restano stress test lunghi, background tab, cambio dispositivo e ascolto di pop/click.
4. **MIDI hardware**: ripetere test reali con controller, sustain e clock esterno.
5. **Manuale**: il PDF editoriale allegato è riferito alla baseline 0.26.7r2 e non è stato riscritto in questa fase.

## Giudizio

**PASS per la promozione a v0.27.0-alpha2 di sviluppo**, non per etichetta stabile o per uso live certificato. Conservare la 0.27.0-alpha1 come rollback. L'archivio essenziale contiene lo stesso runtime della versione completa; verificare sempre i backup dei preset utente prima di aggiornare.
