# Sorgiva Synth v0.27.0-alpha17 — Musical & Compatibility Validation

**27 ottobre 2026 · Alpha sperimentale**

- Rafforzati i test di regressione su JSON patch, importazione sintetica legacy SynthX, Morph live A/B, MIDI multicanale/multiporta simulato, Sustain CC64, Pitch Bend, Sequencer e Arpeggiatore.
- Corretti metadati `exportedBy` e generatori rimasti ancorati alla vecchia Alpha 9; aggiornati versioni e suffissi dei download.
- Nessuna modifica a DSP, Gain Guard, preset factory, threshold del Governor. La calibrazione effettuata dall'utente sulle versioni precedenti non è una prova automatica di questa release.
- Test completi e limitazioni: `QA_REPORT_v0_27_0a17.md` nel pacchetto COMPLETO.

Per il rollback conserva la cartella alpha16. Preset utente e bank restano separati per browser; effettua il backup JSON prima delle prove.
