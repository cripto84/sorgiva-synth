# Sorgiva Synth — Rapporto QA v0.27.0-alpha11

**Riferimento:** archivi alpha10 COMPLETO ed ESSENZIALE caricati dall'utente. **Stato:** alpha sperimentale. Test eseguiti in Chromium headless su un ambiente Linux condiviso; non equivalgono a una certificazione audio/MIDI su hardware reale.

## Baseline alpha10

- CRC ZIP completo ed essenziale: **PASS**, 979 e 54 voci di archivio; i 54 membri comuni coincidono byte per byte.
- Sintassi, dipendenze, schema e integrità statica: **PASS** (135 factory preset, 229 target MIDI Learn).
- Test di regressione Morph: **PASS**, 1.485 confronti.
- Smoke test browser: **PASS**, inizializzazione WebAudio, Note On/Off e cleanup.

## Modifiche alpha11

La funzione `updateClipIndicator` in `src/audio/audio-context.js` ora scrive nei nodi DOM del monitor di Dynamics Safety **soltanto quando il valore visibile cambia** (larghezza meter, label di clipping, classe `clip-hot`, label Gain Guard). Il monitor continua a leggere l'analizzatore e il limiter/clipper/Gain Guard mantengono le medesime impostazioni e lo stesso percorso WebAudio. Non sono stati modificati intenzionalmente gli algoritmi sonori. Nuovi test: `tests/phase11_sustained_profile.py` e `tests/phase11_audio_parity.py`.

### Riduzione delle modifiche DOM a riposo

| Prova Chromium, circa 1,25 s, nessuna nota | Mutazioni nei testi/classe/stili dei tre indicatori |
|---|---:|
| Alpha10 | 152 |
| Alpha11 | 0 |

Il nuovo stress test controlla anche che il Gain Guard **continui ad aggiornarsi sotto carico** (8 note: indicatore a circa −5,2 dB). Sono mutate le scritture UI, non la frequenza del DSP né l'azione della protezione audio. Questi conteggi non rappresentano una riduzione percentuale dimostrata del carico CPU complessivo.

## Test alpha11

| Test | Esito |
|---|---|
| `tests/smoke_static.py` (32 JS, HTML, preset, MIDI Learn) | PASS |
| `tests/refinement.cjs` (Morph) | PASS |
| `tests/smoke_browser.py` (WebAudio, voice cleanup) | PASS |
| `tests/phase2_browser.py` ... `phase6_browser.py` | PASS |
| `tests/tempo_regression.py` | PASS (con `CHROMIUM_PATH` di sistema) |
| `tests/pulse_bandlimited_regression.py` | PASS |
| `tests/phase8_fm_sync.py` | PASS |
| `tests/dsp_cache_regression.py` | PASS |
| `tests/matrix_routes_regression.py` (200 percorsi) | PASS |
| `tests/phase10_polyphony_profile.py` sulla alpha11 | PASS, 288 OscillatorNode / 992 nodi nel profilo più pesante, cleanup PASS |
| `tests/phase11_sustained_profile.py` | PASS, quattro scenari, cleanup PASS |
| `tests/phase11_audio_parity.py` confrontata con alpha10 | PASS, 288.000 campioni (tre render stereo), differenza massima 3,3×10⁻⁶ |

### Profilo sostenuto del thread JavaScript

| Scenario | Configurazione | Setup totale Note On | Picco code Release nel test | Cleanup dopo Panic |
|---|---|---:|---:|---|
| light-sustain | 4 note, 1 layer, FX essenziali | 10,3 ms | 0 | PASS |
| heavy-sustain | 8 note, 8 layer, effetti e filtri | 22,6 ms | 0 | PASS |
| rapid-retrigger | 8 note, 4 layer, 24 riattivazioni | 70,7 ms cumulativi | 17 | PASS |
| long-chord-cycle | 6 note, 4 layer, FX; 32 cambi di accordo su circa 12 s | 314,5 ms cumulativi | 12 | PASS |

I tempi qui riportati descrivono una delle esecuzioni di prova; i risultati JSON della suite contengono i tempi dell’ultima esecuzione, e possono variare. I tempi sono una singola esecuzione non normalizzata, influenzabile dal carico della macchina: non sono confrontabili con il budget audio in tempo reale. La sovrapposizione di 17 code transitorie durante i retrigger è un **tema di carico da investigare**, non una perdita permanente: tutti i contatori erano a zero dopo Panic e la finestra di cleanup. Anche la metrica "event loop lag" rappresenta soltanto jitter osservato dai timer JavaScript, non glitch dell'uscita audio.

### Parità audio alpha10 → alpha11

Un secondo di `OfflineAudioContext`, 48 kHz, stereo, Do4, Release a 250 ms; tre configurazioni, 96.000 campioni per configurazione.

| Configurazione | Differenza assoluta massima |
|---|---:|
| clean | 0 |
| dual | 0 |
| unison | 0,0000032932 |

Tutte inferiori alla tolleranza 2×10⁻⁵ del test. Parità verificata **solo in queste condizioni**, non su ogni possibile preset.

## Rendering batch dei 135 factory preset

**PASS, 135/135**: il test `tests/phase9_factory_audio.py` è stato rieseguito sull’alpha11. Una nota centrale per preset, 24 kHz, 1 secondo tramite `OfflineAudioContext`, Release a 240 ms. Nessun errore, nessun campione non finito, nessun segnale completamente silenzioso nel test. Questo non certifica la qualità artistica, la coda completa degli effetti né il MIDI reale.

## Verifica finale del pacchetto distribuito

- ZIP completi: **PASS**, 988 file completo e 54 essenziale, CRC integro; 54 file condivisi identici.
- Manifest SHA-256: **PASS**, 34 asset runtime verificati su entrambi.
- Runtime essenziale estratto: **PASS** in Chromium con gli script incorporati per le restrizioni di navigazione del sandbox; versione alpha11, 135 preset, nota udibile, zero voci e code dopo il rilascio. Questa prova non convalida l’apertura diretta `file://` su tutti i browser.

## Verifiche esterne ancora necessarie

1. CPU del thread audio, underrun e stabilità del buffer con interfacce fisiche: **non misurati** da questi test browser.
2. Sessioni musicali reali, ascolto critico di aliasing/risonanza e controller MIDI hardware: **non eseguiti**.
3. Stress reale con versioni differenti di Chrome/Edge e sistemi operativi: **non eseguito**.
4. Manuale editoriale lungo non riallineato a tutti gli aggiornamenti alpha; rimane storico.

**Conclusione:** nessuna regressione bloccante rilevata nei test completati. Alpha11 è idonea a ulteriori prove, ma non è una release stabile certificata.
