# File modificati — 0.26.8 RC1

Le modifiche funzionali sono nei due file audio-context.js e preset-morph.js. Factory invariati.

| File | Stato | Motivo/area |
|---|---|---|
| CHANGELOG.txt | modificato | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| CHANGELOG_v0_26_8rc1.md | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| FILES_CHANGED_v0_26_8rc1.md | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| QA_REPORT_v0_26_8rc1.md | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| README.txt | modificato | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| VERSION | modificato | Identità RC1, nome build o suffissi export; nessuna modifica funzionale ulteriore |
| VERSION.txt | modificato | Identità RC1, nome build o suffissi export; nessuna modifica funzionale ulteriore |
| docs/qa-history/r3/baseline_comparison.json | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| docs/qa-history/r3/matrix_routes_results.json | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| docs/qa-history/r3/r3-interface.png | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| docs/qa-history/r3/r3-midi-step.png | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| docs/qa-history/r3/regression_r3_results.json | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| docs/qa-history/r3/runtime_sha256.json | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| docs/qa-history/r3/smoke_browser_results.txt | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| docs/qa-history/r3/smoke_static_results.txt | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| docs/qa-history/r3/tempo_regression_results.json | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| docs/qa-history/r3/tempo_run.txt | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| index.html | modificato | Identità RC1, nome build o suffissi export; nessuna modifica funzionale ulteriore |
| src/arp/arpeggiator.js | modificato | Identità RC1, nome build o suffissi export; nessuna modifica funzionale ulteriore |
| src/audio/audio-context.js | modificato | Sustain/Hold, voice stealing e parameter smoothing |
| src/core/identity.js | modificato | Identità RC1, nome build o suffissi export; nessuna modifica funzionale ulteriore |
| src/main.js | modificato | Identità RC1, nome build o suffissi export; nessuna modifica funzionale ulteriore |
| src/midi/midi-learn.js | modificato | Identità RC1, nome build o suffissi export; nessuna modifica funzionale ulteriore |
| src/presets/preset-morph.js | modificato | Interpolazione semantica e metadati Morph |
| src/presets/presets.js | modificato | Identità RC1, nome build o suffissi export; nessuna modifica funzionale ulteriore |
| src/presets/randomizer.js | modificato | Identità RC1, nome build o suffissi export; nessuna modifica funzionale ulteriore |
| src/sequencer/step-sequencer.js | modificato | Identità RC1, nome build o suffissi export; nessuna modifica funzionale ulteriore |
| src/state/state.js | modificato | Identità RC1, nome build o suffissi export; nessuna modifica funzionale ulteriore |
| tests/QA_BROWSER.html | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| tests/README_RC1.txt | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| tests/build_browser_qa.py | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| tests/factory_audio.py | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| tests/refinement.cjs | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| tests/refinement_results.json | aggiunto | Aggiunta di documentazione/strumenti QA o risultati; non modifica il timbro |
| tests/runtime_sha256.json | modificato | Aggiornamento aspettative versione della suite esistente |
| tests/smoke_browser.py | modificato | Aggiornamento aspettative versione della suite esistente |
| tests/smoke_static.py | modificato | Aggiornamento aspettative versione della suite esistente |
| tests/smoke_static_results.txt | modificato | Aggiornamento aspettative versione della suite esistente |

I vecchi risultati test sono stati spostati in docs/qa-history/r3; nessun vecchio PASS è attribuito alla RC1. I test nominati r3 sono mantenuti come suite di regressione, con versione attesa aggiornata.
