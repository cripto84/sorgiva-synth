# Sorgiva Synth v0.27.0-alpha7 — Release Notes

## Sintesi
La alpha7 introduce una nuova **modalità opzionale Pulse/PWM Band-limited** per
Osc 1, Osc 2 e Osc 3. Il comportamento **Classic rimane predefinito**.
La modalità migliorata usa una sawtooth nativa, una sua copia in ritardo e
una somma con fase opposta: il ritardo controlla il duty cycle e può essere
modulato con l’LFO mediante `DelayNode.delayTime`.

## Miglioramenti
- Riduzione dell’aliasing statico della forma Pulse nelle prove offline documentate.
- PWM a controllo audio-rate anche nel nuovo percorso; compatibilità con note,
  Unison, release, Pitch Bend, Glide e aggiornamenti dei parametri principali.
- Fallback Classic per width/PWM potenzialmente fuori limite e frequenze
  di riferimento fuori dall’intervallo selezionato (25–16.000 Hz).
- Reset automatico su Classic quando si caricano preset storici senza
  `oscN-pulse-quality` (N=1..3); selezioni esplicite vengono conservate
  dai preset creati con alpha7.
- Il nuovo modulo `src/audio/pulse-bandlimited.js` è incluso in entrambi gli ZIP.

## Cosa non cambia
- Tutti i 135 factory preset, le relative categorie e i parametri originali.
- I 229 target MIDI Learn e i formati legacy di salvataggio.
- Sequencer e Arpeggiatore con loro fallback.

## Limitazioni
Il nuovo percorso può cambiare timbro e livello rispetto alla Pulse tradizionale.
La PWM dinamica e le combinazioni con FM, Sync, modulazioni del pitch e drive
non sono garantite prive di alias. Il ritardo modulato introduce un costo DSP
aggiuntivo: non è stata eseguita una misura comparativa percentuale della CPU.
I risultati spettrali sono prove offline circoscritte, non una certificazione
acustica né un ascolto.

La release rimane **alpha**. QA e comandi di regressione nei file dedicati.
