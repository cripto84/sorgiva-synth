# Sorgiva Synth v0.27.0-alpha6

Estrai tutto lo ZIP e apri `index.html` in un browser Chromium desktop. Premi **Sblocca Audio**. Per il MIDI hardware avvia il progetto tramite `localhost` o HTTPS.

Questa alpha6 consolida l'efficienza del DSP tramite cache limitate per le curve del Filter Drive e le onde Osc Sync. **Non modifica deliberatamente i 135 factory preset o il loro timbro.**

Per dettagli, test e limiti consulta `RELEASE_NOTES_v0_27_0a6.md` e `QA_REPORT_v0_27_0a6.md`.
