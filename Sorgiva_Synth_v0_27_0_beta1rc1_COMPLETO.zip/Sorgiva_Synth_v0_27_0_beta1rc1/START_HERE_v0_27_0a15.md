# Sorgiva Synth v0.27.0-alpha15 — avvio e test

1. Estrai l'intero ZIP; avvia `index.html` in Chromium. Per WebMIDI usa localhost o HTTPS.
2. Premi **Sblocca Audio**; in Performance → Adaptive Performance lascia **AUTO** se desideri usare la gestione automatica, oppure un profilo statico per le prove.
3. Il benchmark resta quello silenzioso introdotto nella alpha13, non un test della percentuale CPU audio.
4. Prova accordi ampi, Note On/Off ripetuti, Sustain, Arpeggiatore e Sequencer; verifica che nessuna nota rimanga bloccata e ascolta eventuali click.
5. Puoi tornare alla alpha14 semplicemente aprendo la cartella della release precedente. Esporta sempre i preset utente prima delle prove.

Le ottimizzazioni della alpha15 non cambiano il motore timbrico o i factory preset. Il collaudo su hardware fisico e una suite di regressione completa restano necessari prima di considerarla stabile.
