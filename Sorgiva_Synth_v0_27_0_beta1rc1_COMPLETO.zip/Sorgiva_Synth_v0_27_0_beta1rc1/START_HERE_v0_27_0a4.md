# Sorgiva Synth v0.27.0-alpha4

Apri `index.html` dopo aver estratto lo ZIP, usa **Sblocca Audio**.
Per MIDI hardware avvia tramite localhost/HTTPS e browser Chromium.

## Novità

Il Sequencer può ora predisporre in WebAudio gli step semplici (senza Tie/Strum),
programmando l'inizio della voce e la release nel tempo audio. I controlli
cambiano e le note future possono essere annullate. Il percorso tradizionale
rimane attivo per arpeggi, legature e accordi strummed.

Il cambio tra Manuale, Sequencer e Arpeggiatore non rilascia più globalmente le
note MIDI/PC in esecuzione; Panic continua a liberare l'intero motore.

**Alpha sperimentale**: verifiche positive nei test dichiarati nel QA, ma non
certificata per tutti i 135 render audio o dispositivi MIDI.

Leggi `RELEASE_NOTES_v0_27_0a4.md` e `QA_REPORT_v0_27_0a4.md`.
