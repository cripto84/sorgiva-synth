# Sorgiva Synth v0.27.0-alpha14 — Intelligent Adaptive Governor

- Incremental AUTO-only dynamic admission control, implemented without modifying real-time DSP or factory presets.
- Foreground JS scheduling lateness sampled periodically as an **indirect advisory signal only**. It is NOT DSP CPU, a dropout counter or a guaranteed predictor of audio failure.
- 3 consecutive >=120 ms late, foreground, sufficiently complex/active samples required for a 10% reduction; minimum 70%; 10-second cooldown; after 12 healthy <=45 ms observations, recovery of 5% at a time.
- No governor changes during hidden tabs, stopped/suspended audio, manual/other modes or disabled automatic mode. Runtime derating is never persisted to patch/user bank.
- Notes already sounding or scheduled are not interrupted by an adjustment; new held and time-stamped notes may be declined at the reduced admission ceiling. This deliberate tradeoff is shown in the UI.
- Fix: Adaptive input controls are excluded from preset JSON export and removed when normalizing legacy/user imports that contain them.
- Preserved Unison topology, FM, Osc Sync, Mod Matrix, Gain Guard and Release Tail Budget; original alpha13 budget remains baseline.
- Known limits: no audio worklet xrun telemetry, real hardware dropout data, end-to-end latency measurements, or long-session hardware qualification.
- See `docs/INTELLIGENT_ADAPTIVE_GOVERNOR_v0_27_0a14.md` and QA report.
