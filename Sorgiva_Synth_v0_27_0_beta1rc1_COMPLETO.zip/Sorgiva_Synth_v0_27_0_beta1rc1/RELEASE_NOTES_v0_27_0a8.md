# Release notes — Sorgiva Synth v0.27.0-alpha8

**Base:** v0.27.0-alpha7 caricata dall'utente (completa ed essenziale).

## Cambiamenti

- **Osc Sync:** analisi spettrale 2048 campioni / 64 armonici con FFT radix-2; preserva il formato `PeriodicWave` e il vecchio DFT come fallback. Cache LRU 64 elementi inalterata.
- **FM Light:** nuova scelta `FM High-note Quality`: `classic` (default) o `guarded`. La seconda applica un tetto prudente alla deviazione secondo la frequenza carrier, modulatore e sample rate. Il parametro viene ricalcolato su note nuove, FM Amount, tuning e pitch bend.
- **Preset legacy:** import senza `fm-quality` riporta esplicitamente a `classic`; i 135 preset inclusi non sono stati riscritti.
- **QA:** test addizionale su coefficienti FFT, modalità FM, voce reale in Chromium, teardown e alias di una sideband selezionata.

## Compatibilità

- Nessun algoritmo sonoro è stato rimosso. Classic FM e Pulse/PWM Classic rimangono i comportamenti predefiniti.
- `guarded` non è oversampling; può ridurre il carattere brillante/aggressivo della FM alta e non annulla tutti gli alias. La resa dipende da modulatore, frequenze, altre elaborazioni e browser.
- L'ottimizzazione FFT cambia i coefficienti solo entro l'errore numerico float32 testato: non si certifica identità campione per campione di qualsiasi patch Osc Sync.

## Test e limiti

Dettagli in `QA_REPORT_v0_27_0a8.md`. Validazione hardware e rendering di tutti i 135 preset ancora aperti.
