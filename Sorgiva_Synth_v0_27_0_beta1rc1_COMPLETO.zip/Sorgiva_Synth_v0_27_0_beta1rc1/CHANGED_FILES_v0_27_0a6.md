# File modificati — Alpha6

- `src/audio/audio-context.js` — cache Filter Drive e Osc Sync; diagnostica.
- `src/core/identity.js`, `src/main.js`, `src/arp/arpeggiator.js`, `src/presets/presets.js`, `src/sequencer/step-sequencer.js`, `src/midi/midi-learn.js`, `index.html`, `VERSION`, `VERSION.txt` — versione e metadata/export.
- `README.txt`, `START_HERE_v0_27_0a6.md`, `RELEASE_NOTES_v0_27_0a6.md`, `QA_REPORT_v0_27_0a6.md` — informazioni e verifiche.
- `tests/smoke_static.py`, `tests/smoke_browser.py` — aspettative della versione.
- `tests/dsp_cache_regression.py`, `tests/dsp_audio_compare.py`, `tests/dsp_alias_probe.py` — nuovi test e misure.
- `SHA256SUMS.txt` — rigenerato per la nuova distribuzione.

Nessun file preset factory è stato modificato.
