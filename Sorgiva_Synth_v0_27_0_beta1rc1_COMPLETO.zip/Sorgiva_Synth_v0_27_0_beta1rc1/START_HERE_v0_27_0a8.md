# Sorgiva Synth 0.27.0-alpha8 — Inizia qui

1. Estrai l'intero ZIP, apri `index.html` in un browser Chromium desktop.
2. Premi **Sblocca Audio**, poi prova le note dalla tastiera.
3. In **Oscillatori & LFO**, attiva **FM Light** e imposta un Amount moderato.
4. Se desideri diminuire le sideband molto alte, prova **FM High-note Quality → Guarded** e confronta l'ascolto con Classic.
5. **Classic** rimane la modalità predefinita dei preset storici, che non vengono modificati.
6. **Pulse/PWM Quality → Band-limited** resta disponibile individualmente per oscillatore dalla alpha7.

Per MIDI hardware, avvia un server locale con `python3 -m http.server 8000` e utilizza Chromium. Conserva una copia esportata delle patch utente prima dei test.

Il rapporto tecnico è in `QA_REPORT_v0_27_0a8.md`. La release è sperimentale.
