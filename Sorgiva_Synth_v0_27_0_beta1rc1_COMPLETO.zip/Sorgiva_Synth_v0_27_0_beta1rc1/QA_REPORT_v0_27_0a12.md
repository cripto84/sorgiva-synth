# Sorgiva Synth — QA v0.27.0-alpha12

**Origine:** i due ZIP essenziali alpha11 caricati dall'utente sono identici (SHA-256 `4eaa6a8c97547a46a41aad1f79f3dcd67318ca8cb73c33c0728436cb81d81529`) e coincidono sui file condivisi con la alpha11 completa presente nella sessione. Tutti gli originali rimangono invariati.

## Baseline e regressioni

- Integrità degli ZIP alpha11 e identità dei file runtime: **PASS**.
- Static smoke, JavaScript, JSON, dipendenze HTML, 135 factory preset e 229 target MIDI Learn: **PASS**.
- Test logici Node, Preset Morph (1.485 confronti): **PASS**.
- WebAudio smoke Note On/Note Off: **PASS**.
- `phase5_browser.py`: **PASS**.
- `phase8_fm_sync.py` (FFT/FM): **PASS**.
- `tempo_regression.py` con Chromium di sistema: **PASS**.
- `phase11_sustained_profile.py`: **PASS**, inclusa la prova lunga di alternanza degli accordi con risorse residue zero.

## Alpha12 — nuovo budget dei Release tail

- 11 code con una nota mantenuta: **11 preservate**, interventi di budget **0**.
- Retrigger di 48 Note On sulla stessa altezza, release lunga: picco di **47 code**, di cui **23** scelte per abbreviazione, **24** conservate dal budget. La nota attiva non viene interrotta.
- A fine test: voci attive 0, code 0, record lifecycle 0: **PASS**.
- Un'one-shot programmata nel futuro durante stress: **non sacrificata**. Dopo annullamento e Panic: disconnessione anticipata, nessun record residuo: **PASS**.
- Sospensione/ripresa e trasporto nel test di regressione: **PASS**.

## Verifica timbrica e preset

- 3 configurazioni con render WebAudio stereo 48kHz/1s: **288.000 campioni confrontati** rispetto alla alpha11; differenza massima nell'Unison `3,77 × 10⁻⁶`, altri due render campione per campione identici. Test **PASS** secondo tolleranza `2 × 10⁻⁵`. L'azione del budget non è attiva in queste configurazioni.
- Factory preset: **135/135 controlli statici**. Rendering breve (24 kHz mono, 1 secondo, singolo Do4) effettuato su **30 preset della nuova build**, 15 iniziali e 15 finali: **30/30 PASS**, nessun errore o segnale interamente silenzioso.
- Factory preset JS: **identico byte per byte** alla alpha11.

## Rischi e limiti rimasti

- Il troncamento delle code musicali in condizioni estreme è intenzionale: i test numerici non certificano l'assenza assoluta di click o artefatti percettivi.
- Il picco transitorio di code registrate può superare il budget: le code selezionate si estinguono nei successivi ~75 ms, non vengono disconnesse brutalmente.
- Il render audio alpha12 riguarda **30 preset, non tutti i 135**; la alpha11 aveva una verifica automatizzata precedente di 135/135.
- Non effettuati test su un'interfaccia audio e un controller MIDI reali; non misurate CPU audio, underrun né latenza end-to-end.

**Verdetto:** alpha12 adeguata a ulteriori prove, non release stabile certificata.

## Verifica finale del pacchetto distribuito

- ZIP alpha12 completo: **1000 file, CRC PASS**. ZIP alpha12 essenziale: **54 file, CRC PASS**. I 54 file condivisi coincidono esattamente.
- I **34 hash SHA-256** del manifesto della nuova distribuzione sono validi.
- Versione essenziale estratta, CSS e script incorporati nella pagina Playwright: **PASS**, versione corretta, AudioContext `running`, una nota creata e rilasciata, zero code residue.
- L'accesso `localhost` diretto è bloccato dalla policy dell'ambiente di prova; questa modalità di avvio non è stata verificata qui, né l'apertura diretta `file://`.
