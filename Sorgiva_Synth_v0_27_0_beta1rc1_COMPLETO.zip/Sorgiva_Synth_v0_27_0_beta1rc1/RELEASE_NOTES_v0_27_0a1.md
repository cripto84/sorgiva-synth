# Sorgiva Synth v0.27.0-alpha1 — Seconda fase (prima tranche)

## Modifiche al codice

- `src/audio/voice-allocator.js` (nuovo): centralizza la priorità delle voci da sacrificare (sustain fisico, livello stimato, anzianità, id). La selezione è integrata in `audio-context.js`. I casi di voice stealing usano il rilascio rapido per liberare prima i nodi audio dopo il superamento del limite.
- `src/motion/phase-clock.js` (nuovo): helper basato su scadenze monotone assolute; Sequencer e Arpeggiatore usano la fase prevista anziché sommare `setTimeout` in modo relativo a callback già in ritardo. In caso di tab sospesa non recupera tutti gli step persi con un burst.
- Il Sequencer e l'Arpeggiatore assegnano ora i propri source ID agli eventi audio. `noteOffImmediate(note, reason, source)` è source-aware; il vecchio comportamento con due argomenti rimane disponibile per compatibilità. Una nota generata non può liberare una nota con la stessa altezza ancora fisicamente tenuta da un altro sorgente.
- Aggiornati versione visualizzata ed export filename della build, senza modificare i formati JSON, le chiavi localStorage o i 135 factory preset.

## Ambito

La logica di allocazione è separata, **non è ancora un Voice Manager completo**. Non sono stati implementati pooling dei nodi DSP, scheduler AudioContext look-ahead/sample accurate, AudioWorklet, Morph dual-engine o oversampling. Queste parti richiedono modifica architetturale e test d'ascolto ulteriori.

## Controlli e limiti

Vedere `QA_REPORT_v0_27_0a1.md`. Il phase clock riduce la deriva *causata dal tempo di esecuzione dei callback*, ma i timer JS rimangono soggetti a jitter e throttling. La release v0.26.9 originale resta immutata come rollback.
