# Sorgiva Synth — Rapporto QA v0.27.0-alpha10

**Base:** ZIP alpha9 completo ed essenziale caricati dall'utente il 26 ottobre 2026. **Stato:** Alpha sperimentale; le conclusioni valgono solo per i test effettuati.

## Verifica di partenza

- Integrità CRC degli ZIP ricevuti: **PASS** (969 file nel completo, 53 nell'essenziale).
- Controlli sintattici/statici alpha9: **PASS** (32 moduli JS, HTML e dipendenze, 135 factory preset, 229 MIDI Learn).
- Test Node alpha9: **PASS** (1.485 confronti Morph).
- Smoke test Chromium alpha9: **PASS** (AudioContext, nota e cleanup).

## Codice modificato per alpha10

`src/audio/audio-context.js`: estratta la funzione `getVoiceConfig()` con i soli 14 gruppi di parametri necessari alla costruzione della voce. Il normale `getGlobalConfig()` continua a contenere i parametri completi degli effetti, dell'EQ e della performance. Le note ora leggono la configurazione per-voce, evitando di valutare ripetutamente i parametri degli effetti globali. Nessuna cache persistente: cambiamenti MIDI, patch e controlli restano immediatamente visibili alle nuove note. Non sono stati modificati intenzionalmente gli algoritmi sonori.

## Risultati nuovi

- `tests/smoke_static.py`: **PASS** per alpha10.
- `tests/refinement.cjs`: **PASS** con 1.485 confronti Morph.
- `tests/smoke_browser.py`: **PASS** per alpha10, AudioContext running e voice cleanup.
- `tests/phase10_polyphony_profile.py`: **PASS**, 14 gruppi della configurazione per-voce identici ai corrispondenti gruppi dello snapshot completo; quattro scenari di polifonia e cleanup tutti superati.
- Test di qualità DSP opzionale già presenti: `phase8_fm_sync.py` **PASS**, `pulse_bandlimited_regression.py` **PASS**.
- Applicazione/round trip UI in Chromium tramite `factory_apply_batched.py`: **25 preset su 135** superati; il processo di prova esteso ha raggiunto il limite di esecuzione dopo il 25°. Non è una certificazione di 135 preset sulla alpha10. La alpha9 dispone di un precedente render breve 135/135, che non va scambiato per una nuova prova completa sulla alpha10.

### Tempi di lettura della configurazione, Chromium headless

| Configurazione | Mediana per chiamata, 250 iterazioni |
|---|---:|
| Snapshot completo | 0.03360 ms |
| Solo parametri per-voce | 0.01560 ms |

**Precisazione:** la differenza riguarda esclusivamente la lettura dei parametri durante l'avvio delle note. Non implica un'analoga riduzione dell'uso CPU DSP/audio in tempo reale.

### Profilo polifonia

| Scenario | OscillatorNode | Nodi WebAudio creati | Setup totale JS | Cleanup |
|---|---:|---:|---:|---|
| 4notes-3osc-1layer | 12 | 64 | 12.00 ms | PASS |
| 8notes-3osc-4layers | 96 | 416 | 17.90 ms | PASS |
| 8notes-3osc-8layers | 192 | 704 | 20.10 ms | PASS |
| 8notes-3osc-12layers | 288 | 992 | 18.40 ms | PASS |

I conteggi misurano i nodi creati durante gli eventi di Note On e non includono automaticamente tutti i nodi globali già allocati. Gli esempi con 8 note e 12 layer coinvolgono 288 oscillatori; il costo è fortemente dipendente da macchina, browser, cache e impostazioni.

### Parità sonora rispetto all'alpha9

`tests/phase10_audio_parity.py`: tre render in `OfflineAudioContext` stereo, 48.000 Hz, 1 s, Do4, release a 250 ms. Controllati 96.000 campioni per caso, 288.000 in totale, con una tolleranza massima di 2×10⁻⁵ sul campione. Risultati:

| Configurazione | Differenza assoluta massima | Esito |
|---|---:|---|
| clean | 0.000000000 | PASS |
| dual | 0.000000000 | PASS |
| unison | 0.000003844 | PASS |

Le due configurazioni senza Unison risultano identiche campione per campione. La configurazione con Unison presenta una differenza nell'ordine dei milionesimi, entro tolleranza, potenzialmente attribuibile alla non perfetta riproducibilità della fase/temporizzazione del rendering. Questo test non copre rumore, riverberi lunghi, MIDI fisico o tutte le possibili patch.

## Limitazioni ancora aperte

1. **CPU audio real-time e dropout/xrun**: non misurabili in modo affidabile con questi benchmark Chromium headless; richiedono audio hardware e test su dispositivi reali.
2. **135 preset alpha10**: integrità statica PASS, prova dinamica completa non terminata; il precedente rendering alpha9 non equivale a convalida completa della nuova build.
3. **Ascolto musicale e MIDI hardware**: non eseguiti in questo ambiente.
4. **Manuale editoriale lungo**: conservato come storico; non ancora sincronizzato con la serie alpha10.

**Conclusione:** alpha10 supera i test principali eseguiti ed è idonea a una prova musicale sperimentale. Non è certificata come release stabile.
