# Sorgiva Synth v0.27.0-alpha15 — rapporto QA

**Data:** 27 ottobre 2026  
**Baseline:** ZIP alpha14 COMPLETO/ESSENZIALE allegati dall'utente; entrambi CRC PASS, tutti i 50 file dell'essenziale identici ai corrispondenti del completo.  
**Ambito:** ottimizzazione della gestione voci e dei dati temporanei senza alterare la catena DSP.

## Modifiche implementate

1. `src/audio/audio-context.js`: `getGlobalConfig()` legge i parametri di Saturation, Modulation, Delay e Reverb una volta sola, riutilizzandoli per il budget e il risultato. Nessuna cache persistente, per evitare dati non aggiornati.
2. `enforceReleaseTailBudget()`: effettua una sola scansione dei candidati e li ordina per anzianità solo in caso di superamento del limite. L'algoritmo di fade protetto e il trattamento delle note future restano invariati.
3. `src/audio/voice-allocator.js`: nuovo `pick()` con lo stesso confronto di `candidates()`, ma con costo O(n) e memoria ausiliaria O(1). Attivato solo quando l'eccesso è una voce; overflow multiplo usa ancora l'ordinamento.
4. Diagnostica: contatori di proprietari e code senza array temporanei.
5. Versione, metadati UI, nomi dei file esportati, README e documentazione aggiornati. Corretto un riferimento a documentazione inesistente nel README ereditato dalla alpha14.
6. **Non modificati** factory preset, DSP, Gain Guard, soglie del governor, voce in riproduzione e struttura delle patch.

## Risultati realmente eseguiti

| Test | Esito |
|---|---|
| static | PASS |
| alpha13 adaptive | PASS (21 checks) |
| alpha14 governor | PASS (25 checks) |
| alpha12 tail budget | PASS |
| future scheduled shots | PASS |
| WebAudio note and scheduled notes | PASS |
| polyphony/unison (1,4,8,12 layers) | PASS |
| alpha15 equivalence (512 candidate sets) | PASS |
| alpha15 normal-release fast path | PASS (0 calls to Array.sort in 10 ordinary releases) |
| alpha15 cleanup | PASS |
| alpha15 essential extracted startup and Note On/Off | PASS |
| alpha15 short preset renders | PASS (5/5 tested) |
| audio parity | PASS (3 deterministic stereo renders at 48 kHz, 288,000 samples) |
| full regression_r3 | INCOMPLETE (timeout; partial assertions emitted, no final verdict) |
| real MIDI, hardware audio dropout, multi-hour stress | NOT RUN |
| 135 preset audio re-render alpha15 | NOT RUN (hash parity only; alpha14 inherited earlier alpha13 audio baseline) |


Il test di selezione ha confrontato **512 insiemi sintetici di voci** di dimensioni 1–64, inclusi legami, priorità e tie-breaker; per tutti `pick()` ha selezionato lo stesso oggetto di `candidates()[0]`.

Nei test di 10 Release ordinarie, l'ottimizzazione non ha chiamato `Array.sort`; la protezione di overflow è stata verificata separatamente con 47 code di picco e **23 code accorciate** secondo la policy originale. Il test successivo ha confermato l'azzeramento delle risorse dopo Panic.

**Audio deterministico:** 3 scenari, 288,000 campioni stereo a 48 kHz, differenza assoluta massima **4.3772161e-06**, soglia 2e-5. Nessun campione non finito nei campioni confrontati. Non prova uguaglianza timbrica in ogni patch né un ascolto professionale.

**Libreria factory:** 135 preset presenti e hash byte-identico alla alpha14 (SHA-256 `1a886b4c9dddad1f0e07da0812f0156534c75098ed9f977cafcf0cf4e8d227c2`). Nell'alpha15 sono stati realmente renderizzati **5/5 preset** in una prova breve offline; il rendering completo 135/135 non è stato rieseguito.

## Performance: limiti delle misure

- Meno ordinamenti, letture e array significano minore lavoro JavaScript **in quei percorsi**, ma non è stata misurata una percentuale riproducibile di guadagno CPU o RAM sul computer dell'utente.
- Il benchmark esistente resta silenzioso e offline e non misura la CPU DSP in tempo reale.
- Il Governor alpha14 continua a basarsi su latenza del thread UI, un segnale indiretto e fallibile; può rifiutare nuove note sotto stress senza interrompere quelle già tenute.
- La regressione generale `tests/regression_r3.py` ha eseguito numerose verifiche ma non è arrivata al verdetto conclusivo entro il timeout. **INCOMPLETE, non PASS.**
- Non sono stati effettuati collaudi MIDI reali, ascolti A/B con un musicista, test su device multipli, misure dropout audio o sessioni di durata plurioraria.

## Indicazioni per il collaudo

1. Estrarre l'ESSENZIALE e aprire `index.html` in Chromium; verificare Note On/Off, sustain e Panic.
2. In Performance → Adaptive Performance provare AUTO prima con patch leggere e poi con più oscillatori/Unison e code lunghe; valutare se il governor rifiuta note inaspettatamente.
3. In caso di note mancanti, tornare al profilo statico STUDIO e annotare configurazione, browser e patch; confronto con alpha14.
4. Prima della beta, rieseguire regressione R3 fino al termine, 135 preset audio e test su dispositivi reali.

## Distribuzione

Il completo include codice, test, storico, QA e documentazione. L'essenziale contiene runtime, licenze e le istruzioni tecniche alpha13–alpha15. File condivisi identici (SHA256), CRC ZIP verificato prima della consegna.
