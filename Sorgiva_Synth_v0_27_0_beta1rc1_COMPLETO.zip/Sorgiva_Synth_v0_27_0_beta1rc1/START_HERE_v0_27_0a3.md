# Sorgiva Synth v0.27.0-alpha3

Per avviare il synth, estrarre interamente lo ZIP e aprire `index.html` con un browser desktop moderno. Premere **Sblocca Audio**. Per WebMIDI, usare Chromium tramite localhost/HTTPS secondo il manuale. Volume di ascolto moderato durante le prime prove.

Questo pacchetto è una build alpha sperimentale. Sono conservati i 135 factory preset e la compatibilità dei normali salvataggi precedenti. Effettuare comunque il backup dei propri User Preset prima di aggiornare.

Novità: cache limitata degli impulsi del riverbero, ottimizzazione del loop degli step, diagnostica e preparazione lookahead lato JavaScript. Non è uno scheduler a precisione di campione. Per i dettagli vedere `RELEASE_NOTES_v0_27_0a3.md` e `QA_REPORT_v0_27_0a3.md`.
