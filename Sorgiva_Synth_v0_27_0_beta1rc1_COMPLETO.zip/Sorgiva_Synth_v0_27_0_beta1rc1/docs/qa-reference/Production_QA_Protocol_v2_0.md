# SORGIVA MUSIC PRODUCTION & QA PROTOCOL v2.0

## Protocollo di produzione, verifica, correzione e rilascio dei brani

---

# 1. SCOPO

Questo protocollo serve a produrre brani che siano contemporaneamente:

- musicalmente validi;
- tecnicamente puliti;
- privi di difetti accidentali;
- coerenti nei livelli;
- stabili nelle transizioni;
- controllati nello spettro;
- leggibili nelle sezioni dense;
- privi di clipping indesiderato;
- coerenti nello stereo;
- dotati di code controllate;
- riproducibili e correggibili senza perdere il lavoro precedente.

Il protocollo non serve a rendere la musica sterile.

Una distorsione, una transizione violenta, una dissonanza, un brusco cambio dinamico o un suono sporco possono essere perfettamente validi quando sono intenzionali.

La distinzione fondamentale è:

**INTENZIONALE = carattere musicale**

**ACCIDENTALE = difetto**

---

# 2. PRINCIPIO FONDAMENTALE

## Nessun difetto deve essere trascinato allo step successivo.

Ogni fase termina con un controllo chiamato:

# GATE

Ogni Gate può ricevere uno dei seguenti stati:

- **PASS** — risultato verificato;
- **FAIL** — esiste almeno un problema da correggere;
- **BLOCCATO** — non è possibile completare il test;
- **NON TESTATO** — il controllo non è stato ancora eseguito;
- **NON APPLICABILE** — il controllo non riguarda quel brano.

Solo **PASS** permette normalmente di procedere.

---

# 3. STATI GLOBALI DEL BRANO

Ogni progetto passa attraverso questi stati:

### WORK
Composizione e sperimentazione.

### STRUCTURE PASS
Struttura musicale approvata.

### MUSICAL PASS
Il brano funziona musicalmente.

### TECHNICAL PASS
Non sono presenti difetti tecnici conosciuti rilevanti.

### MIX PASS
Il mix è approvato.

### RELEASE CANDIDATE
Il master è potenzialmente definitivo.

### GOLD
Versione finale congelata.

Il passaggio:

**GOLD → modifica**

non è consentito.

Qualsiasi modifica successiva genera una nuova revisione.

---

# 4. PRE-FLIGHT

Prima di iniziare una sessione importante creare la scheda tecnica del brano.

## Identità

- Titolo:
- Versione:
- Data:
- Stato:
- BPM:
- Metro:
- Tonalità/centro tonale:
- Durata prevista:
- Durata attuale:

## Ambiente

- Versione Sorgiva Synth:
- Browser:
- Sistema operativo:
- Sample rate:
- Bit depth:
- Interfaccia audio:
- Sistema di ascolto:

## Materiali

- Patch:
- Pattern:
- MIDI:
- Stem:
- Registrazioni:
- Versione maestro:
- Reference audio:

## Obiettivo della sessione

Descrivere in una frase cosa deve essere ottenuto.

Esempio:

> Sistemare le transizioni della seconda metà senza modificare struttura, timbro o dinamica generale.

### PRE-FLIGHT GATE

PASS quando:

- versione identificata;
- materiali disponibili;
- baseline precedente conservata;
- obiettivo della sessione definito.

---

# 5. VERSIONAMENTO OBBLIGATORIO

Non sovrascrivere continuamente lo stesso file.

Formato consigliato:

`Titolo_v01`

`Titolo_v02_STRUTTURA`

`Titolo_v03_TRANSITION_FIX`

`Titolo_v04_LEVEL_FIX`

`Titolo_v05_MIX_PASS`

`Titolo_MASTER_RC1`

`Titolo_MASTER_GOLD`

Ogni modifica significativa genera una nuova versione.

Conservare sempre:

1. ultimo PASS;
2. versione corrente;
3. materiale necessario a ricostruire il progetto.

---

# 6. ROLLBACK

Se una modifica peggiora il risultato:

**ritornare immediatamente all'ultima versione PASS.**

Non cercare di correggere una correzione sbagliata con altre cinque modifiche.

---

# 7. DEFECT LEDGER

Ogni problema reale deve essere registrato.

Formato:

| ID | Timestamp | Gravità | Descrizione | Versione | Stato |
|---|---|---|---|---|---|
| SM-001 | 01:38.2 | P1 | micro-salto nella transizione | v12 | FIXED |
| SM-002 | 04:57.5 | P1 | ingresso brusco | v25 | PASS |
| SM-003 | 06:42 | P2 | tema leggermente debole | v37 | OPEN |

Ogni difetto deve indicare almeno:

- ID;
- timestamp;
- descrizione;
- gravità;
- versione nella quale è stato osservato;
- causa sospetta;
- fix applicato;
- versione corretta;
- risultato del regression test.

Un problema non viene cancellato dal registro.

Viene marcato:

- OPEN;
- FIXING;
- FIXED;
- VERIFIED;
- REJECTED;
- WONT FIX.

---

# 8. CLASSIFICAZIONE DEI DIFETTI

## P0 — BLOCCANTE

Esempi:

- file corrotto;
- sezione mancante;
- export sbagliato;
- forte clipping digitale;
- interruzione del brano;
- glitch macroscopico.

### Conseguenza

**Release vietata.**

---

## P1 — GRAVE

Esempi:

- click evidente;
- salto di volume evidente;
- transizione rotta;
- coda incontrollata;
- basso fuori controllo;
- tema palesemente sbilanciato;
- stereo gravemente instabile.

### Conseguenza

**Release vietata.**

---

## P2 — MEDIO

Esempi:

- zona troppo densa;
- elemento leggermente troppo forte;
- transizione poco fluida;
- stereo migliorabile;
- frequenza dominante;
- sezione meno leggibile.

### Conseguenza

Da correggere normalmente prima del GOLD.

---

## P3 — MINORE

Esempi:

- micro-variazione discutibile;
- dettaglio timbrico;
- preferenza estetica;
- differenza difficilmente percepibile.

### Conseguenza

Può essere consapevolmente accettato.

---

# 9. FASE A — IDENTITÀ MUSICALE

Prima del lavoro tecnico definire:

- atmosfera;
- linguaggio;
- carattere;
- durata;
- arco narrativo;
- elementi principali;
- sviluppo;
- climax;
- conclusione.

La domanda fondamentale è:

**che cosa deve fare musicalmente questo brano?**

Non:

**quante cose possiamo aggiungere?**

### GATE A

PASS se:

- esiste un'identità riconoscibile;
- il brano ha una direzione;
- gli elementi principali hanno una funzione;
- il climax ha un ruolo;
- il finale è concettualmente definito.

---

# 10. FASE B — OSSATURA

Creare una versione essenziale.

Usare soltanto gli elementi necessari.

Possibili elementi:

- ritmo;
- basso;
- sequenza;
- tema;
- drone;
- pad;
- elemento distintivo.

Evitare inizialmente:

- decorazioni;
- automazioni inutili;
- FX complessi;
- stratificazioni eccessive.

### GATE B — STRUCTURE PASS

Ascoltare tutto il brano.

PASS se:

- la struttura regge;
- non ci sono sezioni palesemente inutili;
- non esistono vuoti accidentali;
- il climax arriva in modo credibile;
- il finale funziona;
- il brano conserva interesse senza dover essere mascherato dagli effetti.

---

# 11. FASE C — QA DEI SINGOLI ELEMENTI

Ogni elemento importante deve essere controllato isolatamente.

## Attacco

Verificare:

- click;
- pop;
- transiente;
- volume;
- chiarezza.

## Corpo

Verificare:

- livello;
- stabilità;
- intonazione;
- modulazioni;
- distorsione;
- equilibrio spettrale.

## Rilascio

Verificare:

- Release;
- eventuali click;
- coda;
- rumore;
- sovrapposizione.

### GATE C

Ogni elemento necessario deve essere individualmente PASS.

---

# 12. FASE D — COSTRUZIONE INCREMENTALE

Costruire progressivamente:

A

A+B

A+B+C

A+B+C+D

Dopo ogni aggiunta:

1. ascoltare;
2. confrontare con la versione precedente;
3. verificare il livello;
4. verificare lo spettro;
5. verificare la densità;
6. decidere se l'elemento contribuisce realmente.

Se eliminando l'elemento il brano non perde nulla:

**eliminarlo.**

---

# 13. REFERENCE PASS

Quando struttura, arrangiamento e identità sono convincenti:

creare una versione:

# REFERENCE PASS

Questa diventa il riferimento musicale del progetto.

Le modifiche successive devono essere confrontate anche con questa versione.

La Reference Pass protegge il brano da un fenomeno comune:

**cento piccoli miglioramenti locali che peggiorano il risultato globale.**

---

# 14. FASE E — TRANSITION GATE

Ogni giunzione deve essere controllata.

Punti interessati:

- ingresso di uno strumento;
- uscita;
- cambio pattern;
- cambio armonico;
- cambio sezione;
- ritorno del tema;
- climax;
- decostruzione;
- finale.

Per ogni transizione eseguire tre controlli.

## Controllo 1 — Regionale

10–15 secondi prima e dopo.

## Controllo 2 — Locale

2–4 secondi intorno alla giunta.

## Controllo 3 — Ripetuto

Ripetere il passaggio più volte.

Cercare:

- click;
- pop;
- micro-silenzio;
- doppio transiente;
- salto di fase;
- salto stereo;
- salto timbrico;
- salto di livello;
- coda tagliata;
- sovrapposizione.

### TRANSITION GATE

PASS solamente quando ogni transizione significativa è classificata.

---

# 15. FASE F — LEVEL GATE

Analizzare il volume percepito tra sezioni.

Confrontare:

A → B

B → C

C → D

e così via.

Particolare attenzione ai materiali ricorrenti.

## Tema ricorrente

Quando un tema ritorna con la stessa funzione deve conservare una percezione di livello coerente.

Una differenza intenzionale è ammessa.

Una differenza accidentale è FAIL.

Come riferimento operativo iniziale:

**circa ±1 dB** può essere usato come zona di attenzione per materiale equivalente, senza trasformarlo in una regola assoluta.

Analizzare anche:

- avvallamenti locali;
- gonfiamenti;
- automazioni;
- code;
- accumulo.

### LEVEL GATE

PASS quando nessuna sezione sembra accidentalmente:

- troppo forte;
- troppo debole;
- lontana;
- svuotata;
- schiacciata.

---

# 16. FASE G — LOW-END GATE

Controllare:

- sub;
- kick;
- basso;
- drone;
- riverbero grave;
- Release;
- accumulo tra note.

Eseguire il test anche a basso volume.

Verificare:

- kick vs basso;
- risonanze;
- EQ;
- Drive;
- Unison;
- stereo dei bassi;
- code.

### LOW-END GATE

PASS quando il basso è:

- leggibile;
- stabile;
- profondo quando necessario;
- non dominante accidentalmente;
- compatibile con il climax.

---

# 17. FASE H — TAIL GATE

Controllare il sistema completo:

Amp Release

+

Delay

+

Feedback

+

Reverb

+

Decay

Dopo eventi importanti:

1. interrompere la sorgente;
2. ascoltare la coda;
3. verificare che diminuisca;
4. controllare eventuali risonanze;
5. controllare l'ingresso della sezione successiva.

FAIL se:

- il livello cresce;
- rimane stabile indefinitamente;
- invade accidentalmente la sezione successiva;
- viene tagliato bruscamente;
- crea un salto di volume.

---

# 18. FASE I — STEREO GATE

Ascoltare:

1. stereo;
2. solo L;
3. solo R;
4. mono.

Verificare:

- stabilità del centro;
- elementi che spariscono;
- bassi troppo larghi;
- riverbero sbilanciato;
- phase cancellation;
- bruschi spostamenti.

### STEREO GATE

PASS quando il brano conserva una struttura intelligibile anche in mono.

---

# 19. FASE J — DENSITY GATE

Controllare soprattutto:

- climax;
- accordi;
- tema + sequenza;
- basso + kick;
- Unison;
- code;
- Delay;
- Reverb.

Domanda fondamentale:

**riesco ancora a capire gli elementi importanti?**

Se no, ridurre preferibilmente:

1. elementi non necessari;
2. Release;
3. Reverb;
4. Delay;
5. Unison;
6. medio-bassi;
7. livelli concorrenti.

---

# 20. FASE K — TECHNICAL LISTEN

Eseguire un ascolto completo senza modificare nulla.

È vietato:

- mettere pausa per correggere;
- tornare indietro;
- modificare parametri.

Annotare soltanto.

Esempio:

`01:38.1 — possibile micro-click`

`04:57.4 — transizione brusca`

`06:15 — tema leggermente basso`

`07:22 — accumulo low-end`

---

# 21. FASE L — FIX CHIRURGICO

Ogni difetto viene corretto singolarmente.

Procedura:

1. selezionare un ID dal Defect Ledger;
2. identificare il timestamp;
3. descrivere il sintomo;
4. formulare una causa;
5. modificare una sola cosa principale;
6. renderizzare;
7. confrontare A/B;
8. testare localmente;
9. testare regionalmente;
10. eseguire il regression test;
11. aggiornare il registro.

Formula:

# FIX → LOCAL QA → REGIONAL QA → REGRESSION QA

---

# 22. REGRESSION MATRIX

Ogni tipo di intervento attiva automaticamente verifiche correlate.

## Modifica livello

Ricontrollare:

- elemento;
- sezione;
- sezione precedente;
- sezione successiva;
- climax;
- limiter.

## Modifica Release

Ricontrollare:

- code;
- transizioni;
- densità;
- Delay;
- Reverb.

## Modifica basso

Ricontrollare:

- kick;
- mono;
- climax;
- limiter;
- low-mid.

## Modifica stereo

Ricontrollare:

- mono;
- centro;
- L/R;
- reverb;
- basso.

## Modifica Delay

Ricontrollare:

- transizioni;
- code;
- ritmo;
- Reverb;
- climax.

## Modifica Reverb

Ricontrollare:

- code;
- intelligibilità;
- basso;
- stereo;
- transizioni.

## Modifica tema

Ricontrollare:

- prima esposizione;
- ripresa;
- sezione precedente;
- sezione successiva;
- climax.

---

# 23. BLIND A/B

Utilizzare quando la differenza è sottile.

Particolarmente utile per:

- ±0,5–1 dB;
- piccoli EQ;
- stereo width;
- micro-variazioni;
- compressione;
- limiter;
- saturazione.

Se non si riesce a identificare quale versione sia realmente migliore:

**mantenere preferibilmente la versione precedente PASS.**

---

# 24. FIX BUDGET

Dopo il MUSICAL PASS:

le modifiche creative importanti vengono progressivamente limitate.

Dopo il MIX PASS:

sono ammessi principalmente:

- correzioni;
- bilanciamenti;
- eliminazione difetti;
- ottimizzazioni minori.

Un P3 non deve generare una cascata di modifiche che rischia di compromettere più sezioni già PASS.

---

# 25. MUSICAL PASS

Eseguire un ascolto dedicato esclusivamente alla musica.

Ignorare momentaneamente analizzatori e misure.

Domande:

- il brano racconta qualcosa?
- mantiene interesse?
- respira?
- possiede abbastanza variazione?
- esistono parti troppo lunghe?
- il climax funziona?
- il finale soddisfa?
- qualche elemento distrae?
- qualche elemento manca?

Se sì:

# MUSICAL PASS

---

# 26. TECHNICAL PASS

Eseguire un ascolto dedicato esclusivamente ai difetti.

Cercare:

- click;
- pop;
- crepitii;
- clipping;
- buchi;
- salti;
- code;
- livelli;
- stereo;
- fase;
- accumuli;
- errori di montaggio.

Se non esistono P0, P1 o P2 aperti:

# TECHNICAL PASS

---

# 27. MIX

Il mix può iniziare definitivamente soltanto dopo:

- STRUCTURE PASS;
- MUSICAL PASS;
- principali TECHNICAL GATE.

Priorità:

1. equilibrio;
2. definizione;
3. spazio;
4. low-end;
5. stereo;
6. dinamica;
7. colore.

Il volume finale non è ancora l'obiettivo.

---

# 28. MIX PASS

Prima di dichiarare MIX PASS verificare:

- livelli;
- spettro;
- basso;
- stereo;
- mono;
- climax;
- code;
- transizioni;
- dinamica.

Confrontare anche con REFERENCE PASS.

Se il nuovo mix è tecnicamente migliore ma musicalmente peggiore:

FAIL.

---

# 29. THREE-LISTEN TEST

Prima del mastering eseguire tre ascolti distinti.

## A — Tecnico

Cercare difetti.

## B — Musicale

Valutare il brano.

## C — Passivo

Ascoltare senza analizzare intenzionalmente.

Annotare soltanto ciò che spontaneamente attira l'attenzione.

---

# 30. MASTERING

Il master deve partire esclusivamente da MIX PASS.

Obiettivi:

- livello finale adeguato;
- controllo dei picchi;
- equilibrio tonale;
- compatibilità di riproduzione;
- conservazione della dinamica;
- conservazione del carattere.

Indicazione prudente:

**true peak intorno o inferiore a -1 dBTP**, salvo esigenze differenti.

Il limiter non deve essere utilizzato per nascondere un mix sbagliato.

---

# 31. MASTER A/B

Confrontare:

A = MIX PASS

B = MASTER

a loudness percepita comparabile.

Il master deve migliorare almeno uno dei seguenti aspetti:

- solidità;
- controllo;
- traduzione;
- consistenza;

senza peggiorare:

- transitori;
- profondità;
- dinamica;
- stereo;
- basso;
- code;
- carattere.

---

# 32. DEVICE TEST

Provare almeno su:

- sistema principale;
- cuffie;
- speaker piccoli;
- mono.

Facoltativamente:

- smartphone;
- automobile;
- hi-fi.

Non correggere un'anomalia presente su un solo dispositivo mediocre.

Cercare problemi ricorrenti.

---

# 33. RELEASE CANDIDATE

Quando il master supera i controlli precedenti viene creato:

`MASTER_RC1`

Da questo momento:

- niente nuove idee;
- niente nuovi strumenti;
- niente nuovi arrangiamenti;
- niente “proviamo questo”.

Sono ammessi solamente fix documentati.

---

# 34. ZERO-INTERVENTION LISTEN 1

Ascolto tecnico completo.

È vietato interrompere.

Annotare soltanto.

Se compare un P0/P1/P2:

RC FAIL.

---

# 35. ZERO-INTERVENTION LISTEN 2

In sessione separata:

ascolto musicale completo.

Nessun intervento.

Se il brano continua a sembrare musicalmente corretto:

PASS.

---

# 36. FINAL DEFECT SWEEP

Ultimo controllo tecnico.

Cercare esclusivamente:

- click;
- pop;
- crepitio;
- clipping;
- silenzio accidentale;
- salto;
- avvallamento;
- coda;
- stereo;
- fase;
- inizio tagliato;
- finale tagliato;
- file sbagliato.

Nessuna modifica creativa è permessa.

---

# 37. RELEASE GATE

Per diventare GOLD devono essere verificati:

## MUSICA

- [ ] STRUCTURE PASS
- [ ] MUSICAL PASS
- [ ] climax approvato
- [ ] finale approvato
- [ ] durata approvata
- [ ] nessuna sezione inutile evidente

## TRANSIZIONI

- [ ] tutte verificate
- [ ] nessun P0
- [ ] nessun P1
- [ ] nessun P2 non accettato

## LIVELLI

- [ ] coerenza generale
- [ ] temi ricorrenti verificati
- [ ] nessun avvallamento accidentale
- [ ] climax controllato

## SPETTRO

- [ ] low-end controllato
- [ ] low-mid leggibili
- [ ] alte non problematiche
- [ ] nessuna risonanza grave

## SPAZIO

- [ ] stereo PASS
- [ ] mono PASS
- [ ] Delay PASS
- [ ] Reverb PASS
- [ ] code PASS

## DINAMICA

- [ ] clipping assente
- [ ] limiter controllato
- [ ] transienti conservati
- [ ] dinamica appropriata

## QA

- [ ] TECHNICAL PASS
- [ ] MIX PASS
- [ ] MASTER A/B PASS
- [ ] device test
- [ ] regression matrix completata
- [ ] zero-intervention listen tecnico
- [ ] zero-intervention listen musicale
- [ ] Defect Ledger senza P0/P1/P2 aperti

---

# 38. GOLD FREEZE

Quando tutti i controlli necessari sono PASS:

# MASTER GOLD

Creare:

- master WAV;
- eventuale master 24 bit;
- eventuale MP3/AAC;
- stem finali;
- patch;
- pattern;
- MIDI;
- maestro/documentazione;
- Defect Ledger;
- checksum quando utile;
- pacchetto archivio.

Il GOLD non viene più modificato.

Una modifica futura genera:

`v2`

oppure:

`REVISION 1`

---

# 39. REGOLA DELLA PERFEZIONE

Quando il brano è già molto buono:

il rischio maggiore non è più lasciare un piccolo difetto.

Il rischio maggiore diventa:

**rovinare un equilibrio funzionante cercando continuamente di migliorarlo.**

Pertanto:

> una modifica non viene mantenuta perché è nuova.

Deve dimostrare di essere migliore.

---

# 40. REGOLA DEL FIX MINIMO

Per ogni problema:

**usare la modifica minima capace di risolverlo.**

Evitare:

problema locale  
→ modifica globale  
→ nuovi problemi  
→ altre modifiche  
→ perdita della baseline.

Preferire:

problema locale  
→ fix locale  
→ verifica  
→ PASS.

---

# 41. FLUSSO COMPLETO

PRE-FLIGHT

↓

IDEA

↓

OSSATURA

↓

STRUCTURE PASS

↓

QA ELEMENTI

↓

COSTRUZIONE INCREMENTALE

↓

REFERENCE PASS

↓

TRANSITION GATE

↓

LEVEL GATE

↓

LOW-END GATE

↓

TAIL GATE

↓

STEREO GATE

↓

DENSITY GATE

↓

TECHNICAL LISTEN

↓

DEFECT LEDGER

↓

FIX CHIRURGICI

↓

REGRESSION MATRIX

↓

MUSICAL PASS

↓

TECHNICAL PASS

↓

MIX

↓

MIX PASS

↓

THREE-LISTEN TEST

↓

MASTER

↓

MASTER A/B

↓

DEVICE TEST

↓

RELEASE CANDIDATE

↓

ZERO-INTERVENTION LISTEN ×2

↓

FINAL DEFECT SWEEP

↓

RELEASE GATE

↓

GOLD FREEZE

---

# 42. PRINCIPIO FINALE

Il protocollo non deve decidere se una musica sia bella.

Deve garantire che:

**ciò che l'autore vuole sentire sia realmente ciò che esce dal file finale.**

Ogni stranezza intenzionale può rimanere.

Ogni difetto accidentale deve essere trovato, isolato, corretto e verificato.

La qualità finale nasce dall'unione di:

**intenzione musicale + controllo tecnico + versionamento + verifica + capacità di fermarsi.**
