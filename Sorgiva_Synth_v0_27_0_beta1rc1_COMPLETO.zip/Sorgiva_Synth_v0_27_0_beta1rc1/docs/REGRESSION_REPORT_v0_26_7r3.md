# Sorgiva Synth v0.26.7r3 — Rapporto di verifica

Base: ZIP FULL r2 fornito dall'utente, 828 file; documento possibili-bug.odt;
manuale editoriale v2.1 (1.267 pagine). Inventariati tutti i file e verificati
JavaScript, JSON, riferimenti runtime e metadati; approfondita la lettura del
codice e delle sezioni documentali pertinenti alle segnalazioni. L'inventario
non equivale a una revisione editoriale integrale delle 1.267 pagine.

## Segnalazioni e risultato

| Segnalazione | Riscontro | Correzione |
| --- | --- | --- |
| Mod Matrix ferma su nota lunga | Confermati LFO Matrix non aggiornati da Rate/Depth e rebuild della voce ad ogni modifica slot | Routing riconciliati senza ricreare la voce; sorgenti e fase conservate negli edit Amount; Rate/Depth aggiornati |
| Click/pop in triangle+sine+saw debole | Confermata esclusione binaria dal profilo low-harmonic | Profilo selezionato con stima energetica pesata, soglia 75%; corretta stima ADSR exp nel fallback |
| BPM globale poco individuabile | Mancava un BPM interno unico; Rate liberi e fallback LFO/Delay a 120 | Barra BPM 20–300, sync opzionale Seq/Arp e priorità clock MIDI stabile |
| Mancanza input MIDI nel sequencer | Funzione assente, non un guasto MIDI | Inserimento monofonico passo per passo di nota/velocity; non registrazione in tempo reale |
| Alcuni routing sembrano inattivi | Velocity/Filter Env sono per voce e non pilotano FX globali per progetto | Avviso UI esplicito e conteggio attivi corretto; nessuna semantica globale inventata |

Il test prima/dopo sull'originale rileva: protezione del timbro misto false→true;
aggiornamento Rate false→true; Depth false→true; voce preservata false→true;
25 modifiche Amount producono 25 code di voce nella baseline e zero nella r3.
Questa è la riproduzione dei difetti tecnici correlati; non dimostra che ogni
possibile blocco sul computer dell'utente abbia la stessa causa.

## Prove superate

- Test statico: sintassi dei 24 JS, validità JSON, asset/ID HTML, versioni/export,
  135 factory preset, 229 target MIDI Learn, guardie Morph e assenza runtime remoto.
- Smoke browser: avvio, 32 step, 48 tasti, 135 preset, 229 target MIDI Learn,
  self-test accordi, Morph A/B, AudioContext e noteOn/noteOff; nessun errore.
- 34 controlli di regressione runtime, incluso stress di 350 edit sullo slot 8,
  assenza di code create dagli edit, cambi sorgente/destinazione, reset,
  retrigger della stessa nota, noteOffImmediate, voice stealing e Panic.
- Caricamento di tutti i 135 preset e creazione di voci audio; pulizia finale.
  Questa prova non è un ascolto musicale individuale dei 135 preset.
- 24 render della catena WebAudio a 48 kHz: triangle+sine, stessa base con saw
  debole, saw dominante; ADSR lineare/esponenziale; rilascio durante attacco,
  decadimento e sustain; fast release e fallback senza cancelAndHoldAtTime.
  Campioni finiti, picchi entro scala e coda finale nulla nei casi renderizzati.
- 15 verifiche tempo/MIDI/UI: intervalli interni, clock esterno simulato a
  120 BPM, priorità e ritorno al BPM interno, Delay/LFO, limiti BPM, import
  patch che non sovrascrive controlli di sessione, velocity debole e barre sticky.
- 200 combinazioni sorgente/destinazione Matrix controllate: collegamenti
  supportati presenti; 18 combinazioni per-voice→FX globali escluse e segnalate.
  Somma Pitch limitata a 180 cent; lo slot finale torna a contribuire quando
  si libera il budget; edit con sustain mantengono la voce.

Browser: Chromium 152.0.7977.0, Linux headless. Test WebMIDI con messaggi simulati.
Le schermate confermano la disposizione dei controlli a risoluzione desktop.
Risultati e script sono nella cartella tests. Le sonde interne sono iniettate
solo nelle pagine di test, mai nel runtime dei pacchetti.

## Consegna e compatibilità

Dati factory identici byte per byte all'originale; schema preset invariato.
Entrambi gli ZIP contengono identici index.html, styles e src. La versione
completa conserva tutti i percorsi originali, oltre a test/report e allegati;
l'essenziale contiene il runtime completo, README, versione e licenze.
Nessun archivio ZIP annidato, dipendenza di test o cache nel runtime essenziale.
L'HTML va aperto dopo aver estratto la cartella intera.

## Limiti della conclusione

I problemi riprodotti sono corretti e le prove elencate superate. Non si dichiara
assenza universale di bug. Nessun nuovo ascolto con Brave/Launchkey Mini/Yamaha
P-44 o scheda audio dell'utente; non era fornita la patch esatta di Tarantella
del Vespro. Non qualificati mobile, tutti i browser e tutti gli stress Unison/FX.
MIDI Step Input non registra durata/tempo reale; tempo e armamento restano di
sessione. Vedere KNOWN_LIMITS.txt e l'aggiornamento al manuale.
