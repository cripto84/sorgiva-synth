Sorgiva Synth v0.26.7r3 — Indice corrente

1. REGRESSION_REPORT_v0_26_7r3.md: problemi, correzioni, prove e limiti.
2. UPDATE_MANUALE_v0_26_7r3.txt: uso delle funzioni modificate e errata.
3. input/Manuale_Utente_v2_1_originale.pdf: manuale fornito, preservato.
4. input/possibili-bug.odt: segnalazioni originali.
5. ../tests/README.txt: comandi e risultati delle verifiche ripetibili.
6. baseline_r2/: inventario e documenti correnti originali della r2.

Tutti gli altri documenti preesistenti restano conservati: i riferimenti alle
build precedenti sono storici e non attestano test della versione corrente.
Per l'indice precedente vedere baseline_r2/docs_README.txt.
