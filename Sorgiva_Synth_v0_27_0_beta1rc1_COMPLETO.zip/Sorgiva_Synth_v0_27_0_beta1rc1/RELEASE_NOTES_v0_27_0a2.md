# Sorgiva Synth v0.27.0-alpha2 — Ciclo di vita delle voci e trasporto WebAudio

## Cosa è cambiato

1. **Voice Lifecycle**: `src/audio/voice-lifecycle.js` tiene traccia del passaggio `active → release → disposed` e gestisce un unico timer per voce in release. Il teardown dei filtri, dell'output e del Filter Drive avviene in un solo callback idempotente, con contabilizzazione delle code aggiornata alla fine. Se `AudioContext` è sospeso, il gestore attende il suo ripristino senza perdere il riferimento al tempo audio; un watchdog di sicurezza evita riferimenti permanenti in situazioni patologiche.
2. **Trasporto audio-referenced**: `src/motion/audio-transport.js` usa `AudioContext.currentTime` (quando il contesto esiste) come base per le scadenze assolute di Sequencer e Arpeggiatore e dei relativi Gate. Le callback attendono un audio clock in esecuzione e non avanzano durante la sospensione. In assenza di AudioContext si applica il fallback monotono `performance.now()`. Rimane una pianificazione lato JavaScript, *non sample accurate*.
3. **Compatibilità**: i vecchi moduli `voice-allocator.js` e `phase-clock.js` restano presenti, per preservare i controlli e le API. Nessuna modifica ai 135 factory preset, ai formati JSON o alle chiavi dei dati locali. Metadati e suffissi export portati ad alpha2.

## Esclusioni esplicite

Non sono inclusi ancora: pool dei nodi DSP, Voice Manager completamente separato da `audio-context.js`, scheduling look-ahead con note programmate anticipatamente sull'AudioContext, DSP AudioWorklet, oversampling e Morph dual-engine. Questi richiedono ulteriori prove e interventi più profondi.

## Prove e rischi

Vedi `QA_REPORT_v0_27_0a2.md`. Questa è una build **alpha**. Le prove audio di riferimento mediante controller fisico e il rendering completo dei 135 preset non sono stati certificati.
