# Sorgiva Synth v0.27.0-alpha12 — Avvio rapido

Estrarre interamente lo ZIP. Avviare `index.html` in un browser Chromium moderno e premere **Sblocca Audio**. Per WebMIDI usare localhost/HTTPS quando necessario. Impostare inizialmente un volume di ascolto moderato.

Questa build preserva i 135 factory preset e la modalità sonora Classic. Introduce soltanto protezioni per carichi anomali di code Release; durante l'esecuzione ordinaria i tempi musicali sono invariati. Il budget può abbreviare le code meno recenti in condizioni di retrigger estremo: provare pad lunghi e sequenze dense prima di utilizzarla dal vivo.

Leggere `RELEASE_NOTES_v0_27_0a12.md` e `QA_REPORT_v0_27_0a12.md`. Versione alpha sperimentale, non certificata per MIDI hardware o prestazioni audio reali.
