# Sorgiva Synth v0.27.0-alpha6 — QA

Data: 26 ottobre 2026. Base: due ZIP alpha5 caricati, entrambi privi di errori CRC e identici ai corrispondenti ZIP originali secondo SHA-256.

## Ambito e risultati

| Verifica | Esito | Evidenza |
|---|---|---|
| Static smoke, JS/JSON/HTML, 135 preset, 229 target MIDI Learn | PASS | `tests/smoke_static.py` |
| Avvio WebAudio, nota e Release | PASS | `tests/smoke_browser.py` |
| Logica e Morph (1.485 confronti) | PASS | `tests/refinement.cjs` |
| Correzioni consolidamento e ownership note | PASS | `tests/consolidamento_browser.py` |
| Voice allocator | PASS | `tests/phase2_browser.py` |
| Voice lifecycle + suspend/resume | PASS | `tests/phase3_browser.py` |
| Reverb cache e preparazione transport | PASS | `tests/phase4_browser.py` |
| One-shot WebAudio e note MIDI | PASS | `tests/phase5_browser.py` |
| Arp preparato e Strum breve | PASS | `tests/phase6_browser.py` |
| Clock MIDI simulato, sync Delay/LFO | PASS | `tests/tempo_regression.py` (CHROMIUM_PATH configurato) |
| Mod Matrix: 200 combinazioni | PASS | `tests/matrix_routes_regression.py` (CHROMIUM_PATH configurato) |
| Cache curve Filter Drive e PeriodicWave Osc Sync | PASS | `tests/dsp_cache_regression.py` |
| Confronto audio numerico con alpha5 | PASS | `tests/dsp_audio_compare.py`: 3 render × 21.600 campioni, differenza massima 0.0 |
| Misura esplorativa di aliasing | ESEGUITA | `tests/dsp_alias_probe.py`, non test di conformità |
| Caricamento browser di tutti i 135 preset | INCOMPLETO | primi 15 in tre lotti senza errori; esecuzione interrotta per timeout |
| Render completo dei 135 preset | NON ESEGUITO | integrità statica non implica qualità audio |
| Runtime ZIP essenziale estratto | PASS con limitazione | script estratti, incorporati nella pagina di Chromium; avvio, nota e rilascio validi. Apertura `file://` diretta bloccata dalle policy del browser nel sandbox. |
| Hardware MIDI / ascolto umano | NON ESEGUITI | richieste prove su hardware e condizioni di ascolto reali |

## Nuove misure DSP

- 8 note simultanee Filter Drive warm/Amount 0.51: **1 miss + 7 hit**, generazione della curva effettuata una sola volta.
- Dopo passaggio Amount a 0.65 con voci attive: ulteriore **1 miss + 7 hit**.
- Stress LRU: Filter Drive **64/64** curve, 37 eviction, memoria array JS stimata **1.048.576 byte**. Osc Sync **64/64**, 2 eviction in prova.
- Confronti audio: `sine/clean 0.3214567`, `saw/warm 0.61523`, `triangle/dirty 0.83`; rendering Chromium `OfflineAudioContext` a 24 kHz, differenza massima campione per campione 0.0 su 21.600 campioni per caso.
- Profilo spettrale didattico, **non comparazione di loudness/qualità percepita**: oscillatore saw nativo a 5300 Hz / 48 kHz, alias massimo misurato circa **−139,5 dB relativo alla fondamentale**; soglia pulse tramite waveshaper 2x circa **−59,9 dB**. Questi valori dipendono dal metodo FFT di prova e non descrivono un'intera patch con filtri/effetti.

## Interpretazione

Questa fase **riduce il lavoro JS di costruzione delle curve e la crescita della cache Osc Sync**, senza cambiare intenzionalmente algoritmi o preset. Non sono disponibili misurazioni affidabili che consentano di quantificare un guadagno percentuale di CPU DSP o latenza su dispositivi reali. La misura aliasing suggerisce come successiva fase un generatore pulse anti-aliasing opzionale, accompagnato da confronto AB e migrazione non distruttiva. La versione rimane **alpha**, non release stabile certificata.
