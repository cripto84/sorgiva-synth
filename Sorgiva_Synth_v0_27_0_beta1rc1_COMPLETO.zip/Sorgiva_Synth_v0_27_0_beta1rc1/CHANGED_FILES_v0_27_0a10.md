# File modificati / aggiunti — Alpha10

- `src/audio/audio-context.js`: funzione `getVoiceConfig()`, usata nella creazione delle voci; snapshot globali preservati.
- `src/core/identity.js`, `src/main.js`, `index.html`, `VERSION`, `VERSION.txt`: versione esposta.
- `src/presets/presets.js`, `src/sequencer/step-sequencer.js`, `src/midi/midi-learn.js`: nomi di export aggiornati, formati invariati.
- `tests/smoke_static.py`, `tests/smoke_browser.py`: aspettative di versione aggiornate.
- `tests/phase10_polyphony_profile.py`, `tests/phase10_audio_parity.py`: nuovi test con report JSON.
- `QA_REPORT_v0_27_0a10.md`, `RELEASE_NOTES_v0_27_0a10.md`, `START_HERE_v0_27_0a10.md`: nuova documentazione.

Gli altri file e i 135 factory preset rimangono invariati a livello di codice/dati salvo i metadati citati.
