Sorgiva Synth v0.27.0-alpha5

Estrai interamente lo ZIP e apri index.html in un browser moderno. Premi Sblocca Audio. Per WebMIDI preferisci localhost/HTTPS e Chromium.

Leggi RELEASE_NOTES_v0_27_0a5.md e QA_REPORT_v0_27_0a5.md.
