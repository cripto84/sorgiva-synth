# Sorgiva Synth v0.27.0-alpha13 — Adaptive Performance

- Introdotti Hardware Profiler (dati disponibili nel browser), Resource Budget Manager e Adaptive Voice Governor.
- Profili AUTO/ECO/STUDIO/MANUALE con persistenza separata dai preset e override manuale.
- Benchmark silenzioso, breve, cancellabile, su OfflineAudioContext: preparazione nodi, oscillatori, filtri, layer simulati Unison, JS e variabilità tra ripetizioni.
- La nuova governance limita prioritariamente la polifonia delle nuove allocazioni; il cambio profilo non emette All Notes Off e non altera intenzionalmente le voci già suonanti.
- In ECO il limite Unison può ridurre i layer delle note **nuove**: è una scelta esplicita del musicista, non un'alterazione dei factory preset.
- Alpha12 Release Tail Budget conservato, con possibilità di budget più prudenti o personalizzati.
- Il sistema non misura la CPU della scheda audio, gli underrun né i dropout in tempo reale.
- Factory preset invariati; compatibilità di import JSON e legacy conservata.
