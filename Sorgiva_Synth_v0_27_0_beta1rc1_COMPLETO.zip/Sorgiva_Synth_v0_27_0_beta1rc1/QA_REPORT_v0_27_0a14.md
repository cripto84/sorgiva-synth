# Rapporto QA — Sorgiva Synth v0.27.0-alpha14

**Data:** 27 ottobre 2026  
**Build:** Intelligent Adaptive Governor (sperimentale)  
**Baseline:** Sorgiva Synth v0.27.0-alpha13 completo e relativo archivio essenziale.

## 1. Sintesi dell'esito

**PASS nei test eseguiti e completati.** L'integrazione alpha14 funziona negli scenari automatici verificati, ma non è certificata per concerti o produzione audio professionale. Il precedente test reale positivo dell'utente riguardava **alpha13**, non costituisce una prova reale della nuova gestione dinamica alpha14.

## 2. Modifiche tecniche

1. Monitor di ritardo del thread JavaScript ogni circa 1000 ms solo in foreground e con contesto audio attivo. Il ritardo non è una misura diretta del carico CPU audio e non dimostra che ci siano o non ci siano dropout.
2. AUTO con isteresi: 3 osservazioni negative (ritardo >=120 ms, >=2 voci/code/note programmate, costo stimato >=55%), riduzione del 10% per volta, minimo fattore 0,70, cooldown 10 s; recupero +5% dopo 12 osservazioni positive (<=45 ms).
3. Il fattore modifica **soltanto il limite delle nuove allocazioni**, calcolato sulla polifonia effettivamente richiesta: le note in esecuzione sono preservate. Una nuova nota può essere rifiutata quando il nuovo limite è già occupato. Questo comportamento è intenzionale, ma musicalmente va verificato sul campo.
4. Le note già programmate non vengono cancellate; nuove note schedulate possono essere rifiutate oltre il nuovo budget.
5. ECO, STUDIO e MANUALE rimangono profili statici; il bypass dell'adattamento automatico conserva la gestione precedente. Nessuna modifica alla generazione timbrica o alla protezione dinamica.
6. **Bug di compatibilità alpha13 corretto:** esclusione dei campi `adaptive-*` dal JSON dei preset in esportazione e importazione. La migrazione ignora tali campi qualora siano presenti in una patch già esportata.
7. Aggiornati interfaccia, versione, esportazioni, documentazione, storico e test.

## 3. Test completati

| Prova | Risultato | Significato effettivo |
|---|---|---|
| ZIP alpha13 sorgente | PASS | sorgente presente e usata come baseline |
| Sintassi, JSON, riferimenti HTML, factory, MIDI Learn, versioni | PASS | `tests/smoke_static.py` |
| Governor alpha14, eventi sintetici e note già attive | PASS **25** asserzioni | soglie, cooldown, recupero, foreground, preset e pulizia |
| Adaptive alpha13, profili/benchmark/bypass | PASS **21** asserzioni | regressione funzioni precedenti |
| Budget Release/Tail alpha12 | PASS | contabilità e cleanup, browser headless |
| Note e scheduling WebAudio | PASS | `tests/phase5_browser.py` |
| Polifonia e 1/4/8/12 layer Unison | PASS | `tests/phase10_polyphony_profile.py` |
| Note programmate future e cleanup | PASS | `tests/phase12_future_shots.py` |
| Confronto audio alpha13→alpha14, 3 casi stereo 48 kHz | PASS | **288.000 campioni**, massimo scarto 5.37186861e-06 con soglia 2e-5 |
| Preset factory, struttura integrità | PASS **135/135** | hash contenuti factory invariato |
| Mini-render di 10 factory preset | 10/10 validi *nel sottoinsieme completato* | prova pianificata di 15 non conclusa, non contare 15/15 |
| Archivio essenziale estratto, note On/Off, UI, preset, JSON | PASS | Chromium headless senza hardware MIDI reale |
| CRC ZIP e corrispondenza fra le distribuzioni | PASS | tutti i file condivisi identici |

**Factory preset invariati:** SHA-256 `src/presets/factory-presets.js` = `1a886b4c9dddad1f0e07da0812f0156534c75098ed9f977cafcf0cf4e8d227c2` (identico alla alpha13). I render brevi di **135/135 factory preset** furono completati in alpha13; per alpha14 si è verificata la stessa libreria e il nuovo codice non altera il percorso DSP, ma NON è stata completata di nuovo l'intera campagna 135/135.

## 4. Benchmark e misurazioni

- Il benchmark silenzioso dell'alpha13 continua a funzionare e il relativo test automatizzato alpha14 di compatibilità è passato.
- I valori 120 ms, 45 ms, 55%, cooldown e coefficienti di riduzione sono **parametri prudenziali** di policy, non misure scientifiche della capacità del computer.
- La percentuale del pannello riguarda il **budget stimato**, non la CPU DSP.
- Le iniezioni di ritardo usate nei test del governor sono **simulate**; non devono essere interpretate come registrazioni di problemi reali su un dispositivo fisico.
- Nessuna misura reale di CPU audio, deadline AudioWorklet, underrun, temperatura o latenza fisica.

## 5. Compatibilità audio rispetto all'alpha13

| Scenario | Campioni stereo confrontati | Scarto assoluto massimo |
|---|---:|---:|
| clean | 96,000 | 0 |
| dual | 96,000 | 0 |
| unison | 96,000 | 5.37186861e-06 |

Il test è un render deterministico a 48 kHz con tre configurazioni fissate, non una verifica di tutte le note, i timbri o le condizioni di esecuzione. I valori riportati sono differenze numeriche e non una certificazione percettiva.

## 6. Test incompleti e limitazioni

- `tests/phase11_sustained_profile.py`: esecuzione avviata, **timeout**; nessun esito PASS finale. Restano validi i test mirati separati di polifonia/Unison/code, ma non equivalgono al test di durata.
- `tests/phase9_factory_audio.py 0 15`: interrotto dopo **10 su 15** render, con zero errori nei 10 completati; batch **INCOMPLETE**. Non è stato ripetuto il render 135/135 in questa versione.
- `tests/regression_r3.py`: non completata integralmente nella sessione corrente, non dichiarata superata.
- Non rieseguiti nella build finale completa test hardware MIDI, prova uditiva comparata su cuffie, interfaccia audio reale, test su sistemi multi-browser/OS e stress su più macchine.
- Nuovi rifiuti di note sotto pressione possono essere percepibili come note mancate: questa conseguenza è preferita al taglio improvviso di note già tenute, ma richiede valutazione musicale reale.
- Un ritardo UI non prova la saturazione audio: **la policy può intervenire inutilmente** in alcuni casi e non può identificare ogni dropout. Per uso live preferire profili statici finché non è validata sul dispositivo.

## 7. Raccomandazioni

Per alpha15: validare su hardware eterogeneo, valutare telemetria da AudioWorklet dove affidabile, misurare il rapporto tra ritardi JS e veri dropout, stress test lunghi, ascoltare specialmente il rifiuto di note in sequenze/accordi, adottare alternative musicalmente preferibili quando necessario. Nessuna correzione dei preset è richiesta da alpha14.

## 8. Distribuzione

- `Sorgiva_Synth_v0_27_0a14_COMPLETO.zip`: runtime, licenze, sorgenti, test, QA, documentazione e storico.
- `Sorgiva_Synth_v0_27_0a14_ESSENZIALE.zip`: runtime completo, licenze e istruzioni minime, senza suite test o storico editoriale.
- Versione dichiarata `0.27.0-alpha14`. ZIP CRC verificato con `zipfile.testzip()`. Tutti i file dell'archivio essenziale risultano byte-identici ai file corrispondenti nell'archivio completo. 
