# Sorgiva Synth — Release notes v0.27.0-alpha10

Versione incrementale basata su v0.27.0-alpha9.

- Semplificato il percorso di `createVoice()`: i parametri di EQ/FX globali non vengono più riletti per ogni nota.
- Conservato `getGlobalConfig()` per le elaborazioni e le protezioni globali.
- Introdotti benchmark di polifonia fino a otto note, tre oscillatori e 12 layer Unison, con verifica della pulizia delle voci.
- Introdotto confronto audio diretto con alpha9 su tre configurazioni stereofoniche a 48 kHz.
- Factory preset, algoritmi DSP e formati di salvataggio non modificati intenzionalmente.

**Nota importante:** le misure migliorano il costo di preparazione JavaScript; non sono ancora benchmark CPU audio real-time. Alpha sperimentale, non release stabile. Leggere `QA_REPORT_v0_27_0a10.md`.
