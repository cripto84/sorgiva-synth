# File modificati / nuovi in v0.27.0-alpha7

- `src/audio/pulse-bandlimited.js` — nuovo oscillatore Pulse/PWM band-limited opzionale.
- `src/audio/audio-context.js` — integrazione source/Unison, pitch e cleanup.
- `src/presets/presets.js` — sanificazione e fallback sicuro per preset legacy.
- `index.html` — tre nuovi selettori, import dello script, versione e descrizione.
- `src/core/identity.js`, `src/main.js` — identificativi di versione.
- `src/midi/midi-learn.js`, `src/sequencer/step-sequencer.js` — suffissi esportazione.
- `VERSION`, `VERSION.txt`, `README.txt` — nuova release.
- `tests/smoke_static.py`, `tests/smoke_browser.py` — versione e inventario JS.
- `tests/pulse_bandlimited_regression.py` — nuovo test grafi, PWM e alias.
- `tests/classic_audio_regression.py` — confronto render Classic rispetto ad alpha6.
- `tests/README_v0_27_0a7.md` e i documenti di release.
- `SHA256SUMS.txt` — generato nuovamente dopo il confezionamento.

I file dati dei 135 factory preset restano byte-per-byte invariati.
