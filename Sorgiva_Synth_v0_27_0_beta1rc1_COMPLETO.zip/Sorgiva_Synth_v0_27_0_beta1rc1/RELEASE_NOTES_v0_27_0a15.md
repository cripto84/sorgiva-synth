# Sorgiva Synth v0.27.0-alpha15 — Resource & Voice Efficiency

Modifiche mirate al percorso di gestione voci e alla memoria temporanea del thread JavaScript, senza alterare il DSP WebAudio.

- Le configurazioni FX destinate sia al governor sia all'istantanea globale sono lette una sola volta per chiamata.
- Quando una nota termina, i candidati alle protezioni delle code vengono ordinati solo se è superato il budget di code o generatori.
- Per lo stealing di una sola voce viene eseguita una selezione lineare che replica esattamente le precedenti priorità, livelli e precedenze temporali; nel caso di più vittime resta l'ordinamento completo.
- Diagnostica dei proprietari e delle code normali senza generare array intermedi.
- Interfaccia/versione/esportazioni aggiornate; metadata obsoleti della scheda Info corretti; factory preset identici.

Limiti: questi cambiamenti riducono lavoro JavaScript e allocazioni temporanee, ma NON costituiscono una misura di riduzione dell'uso CPU del thread audio né un test su hardware musicale fisico. Il governor alpha14 rimane sperimentale.
