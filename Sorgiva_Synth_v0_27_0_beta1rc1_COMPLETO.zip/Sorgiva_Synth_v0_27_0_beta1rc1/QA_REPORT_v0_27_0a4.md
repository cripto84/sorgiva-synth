# Rapporto QA — Sorgiva Synth v0.27.0-alpha4

**Data:** 24 ottobre 2026. **Base:** v0.27.0-alpha3 (i due ZIP forniti dall'utente coincidono SHA-256 con quelli precedentemente consegnati).
**Ambiente:** Python 3, Node.js 22, Chromium headless, Playwright, WebAudio. Test locali non equivalenti ad ascolto umano o prove hardware MIDI.

## Modifiche effettive

1. `src/audio/audio-context.js`: nuovo metodo `scheduleOneShot`, creazione anticipata del grafo per note brevi, inizio delle sorgenti e inviluppi con timestamp WebAudio; release programmata sul clock audio; cancellazione e diagnostica; limite di 24 shot registrati.
2. `src/audio/voice-lifecycle.js`: deadline di smaltimento calcolata dal tempo effettivo della release programmata, non dal momento di creazione anticipata.
3. `src/sequencer/step-sequencer.js`: lookahead che prepara automaticamente step semplici senza Tie o Strum, con fallback su note standard; annullamento durante modifiche/stop e protezione da duplicazioni. Rimangono da implementare eventi MIDI/Arp, Tie e Strum nella nuova via.
4. `src/motion/motion-engine.js` e `src/arp/arpeggiator.js`: eliminazione dei comandi globali All Notes Off sul normale cambio di modalità, per non spegnere note MIDI/manuali; Panic resta globale.
5. Aggiornati metadata di versione e nomi dei file di esportazione, senza cambiare gli schemi dei preset.

## Esiti disponibili

| Test | Esito | Ambito |
|---|---|---|
| ZIP alpha3 d'ingresso, SHA-256 | PASS | Copie dell'alpha3 identiche byte per byte ai due ZIP precedenti |
| `tests/smoke_static.py` | PASS | JS sintattico, JSON, HTML, asset, 135 preset statici, 229 target MIDI |
| `tests/refinement.cjs` | PASS | Logica delle voci, 1485 casi Morph |
| `tests/smoke_browser.py` | PASS | Avvio WebAudio, note e rilascio |
| `tests/consolidamento_browser.py` | PASS | Bug di consolidamento 0.26.9 |
| `tests/phase2_browser.py` | PASS | Ownership, voice stealing, anti-deriva |
| `tests/phase3_browser.py` | PASS | Lifecycle e sospensione/resume |
| `tests/phase4_browser.py` | PASS | Cache Reverb, preparazione trasporto |
| `tests/phase5_browser.py` | PASS | `OscillatorNode.start(at)`, prepare/consume, annullamento e isolamento MIDI tramite Seq/Arp |
| `tests/phase5_audio_signal.py` | PASS | Energia audio prima/durante/dopo nota programmata |
| Contenuto ZIP essenziale estratto | PASS (smoke inline) | Stessi script dell'archivio estratto caricati in Chromium; note, release, 135 preset e nuova API verificati. Navigazione diretta `file://`/`localhost` bloccata dall'ambiente gestito. |
| `tests/tempo_regression.py` | PASS | MIDI Clock simulato, Delay e LFO sincronizzati |
| `tests/matrix_routes_regression.py` | PASS | 200 combinazioni, limite pitch e voce conservata |
| `tests/factory_apply_batched.py 0 10` | PASS | Applicazione 10 factory in Chromium |
| `tests/factory_apply_batched.py 10 45` | INCOMPLETO | 15 factory ulteriori applicati senza errore; timeout prima degli altri 20 |
| Render audio di tutti i 135 factory preset | NON ESEGUITO | Non certificato |
| MIDI hardware / ascolto umano | NON ESEGUITO | Richiede apparecchi e ascolto su macchina reale |

**Nota importante:** 25 factory preset sono stati applicati senza errore in questa sessione, mentre la validazione statica riguarda tutti e 135. Il test esteso si è fermato per timeout, non dimostra una failure del synth ma non consente di certificare gli altri preset.

## Misurazione audio spot

Il test `phase5_audio_signal.py`, con una nota programmata 300 ms nel futuro e gate di 250 ms, ha rilevato in una esecuzione: RMS prima dell'onset = 0; RMS durante il gate circa 0,405; RMS successivo circa 0,0025. Non sono misure di jitter campione-per-campione, ma confermano che il segnale non partiva in anticipo nel campione di controllo e veniva effettivamente prodotto.

Il test trasporto alpha3/alpha4 ha mostrato anche un dispatch JavaScript con circa 18 ms di ritardo in una singola prova. Questo rende utile la nuova programmazione anticipata ma conferma che il trasporto JS resta soggetto a variazioni.

## Rischi e limiti ancora aperti

- **Solo sequencer semplice:** Arpeggiatore, note in Tie e accordi con Strum usano ancora gli eventi JS.
- Un evento preparato in WebAudio cattura il timbro alla creazione e non partecipa alle strutture ordinarie `voices`/`noteOwners`; i controlli espressivi cambiati nel brevissimo intervallo di preparazione potrebbero non applicarsi a quel singolo shot.
- Il lookahead stesso dipende dai timer JS; se il thread rimane bloccato, interviene il fallback anziché una garanzia di precisione.
- Limite di 24 shot in corso di smaltimento; in patch con release molto lunga alcune note possono tornare sul percorso JS.
- I test browser non sostituiscono misure comparative di aliasing, latenza e jitter con interfaccia audio reale.

**Giudizio:** alpha4 utilizzabile come build di sviluppo; nessuna regressione bloccante emersa nei test eseguiti. Non è una release stabile certificata.
