# Sorgiva Synth v0.27.0-alpha16 — Extended Stability & Regression

La alpha16 consolida la verifica automatizzata della alpha15 senza modificare algoritmi DSP, factory preset, quantità di Unison, Gain Guard, soglie AUTO o comportamento musicale previsto.

- `tests/regression_r3.py` può ora eseguire autonomamente `--part runtime`, `--part factory` e `--part offline`, salvando checkpoint JSON. Factory viene testata a gruppi isolati, evitando il precedente accumulo di grafi WebAudio in un'unica pagina.
- `tests/phase16_stability.py` introduce cicli ripetibili di retrigger, accordi e note programmate, controllando pulizia di voci, code e risorse dopo Panic.
- `tests/phase16_factory_coverage.py` aggrega i checkpoint dei preset, ignorando test che hanno errori e segnando un esito positivo solo se tutti i 135 indici sono coperti.
- Gli script per verifiche statiche e metadati della build sono allineati alla nuova versione.

**Risultati:** 32 test funzionali R3, 24 render offline R3, 135/135 preset caricati in sessioni isolate e 30 verifiche di stabilità (cicli di nota, non ore di funzionamento). Audio deterministico con alpha15: 3 casi PASS, massimo scostamento 5,32e-6, soglia 2e-5.

**Limiti:** non sono stati misurati dropout o uso CPU del thread audio reale, né test MIDI con hardware, né stress di molte ore. Il governor resta sperimentale. La regressione R3 è stata completata suddividendo le sue componenti, non come esecuzione monolitica.
