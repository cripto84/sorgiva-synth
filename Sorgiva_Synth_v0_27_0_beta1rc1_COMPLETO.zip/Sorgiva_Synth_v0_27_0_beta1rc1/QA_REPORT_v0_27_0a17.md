# Sorgiva Synth v0.27.0-alpha17 — Musical & Compatibility Validation · Rapporto QA

**Data:** 27 ottobre 2026  
**Baseline:** ZIP alpha16 COMPLETO/ESSENZIALE allegati dall'utente  
**Obiettivo:** compatibilità con suoni e dati legacy, percorsi MIDI/Sequencer/Arp/Morph, coerenza metadati, senza alterare DSP o factory preset.

## Integrità della baseline e modifiche

- CRC dei due ZIP alpha16: **PASS**. Tutti i 52 file dell'essenziale condivisi con il completo sono identici.
- **Corretto il metadato di versione** nelle esportazioni di patch, MIDI Learn, preset dell'Arpeggiatore e pattern del Sequencer (alcuni fallback riportavano ancora `Alpha 9`). Il Morph usa ora la versione pubblica attuale per il proprio riepilogo e per gli stati generati.
- Aggiornati badge UI, nomi di file esportati, versione e testi operativi a `0.27.0-alpha17`.
- Aggiunta suite `tests/phase17_musical_compatibility.py` per controlli specifici di compatibilità musicale.
- Tutti i file di `src/audio/*.js` sono **byte-identici alla alpha16**. Anche `src/presets/factory-presets.js` è byte-identico, SHA-256 `1a886b4c9dddad1f0e07da0812f0156534c75098ed9f977cafcf0cf4e8d227c2`. Nessuna modifica intenzionale del timbro dei 135 factory preset, di Gain Guard, di polifonia o delle soglie del Governor.

## Risultati effettivi

| Verifica | Risultato |
|---|---|
| ZIP alpha16, CRC e parità completo/essenziale | PASS |
| Avvio alpha17 ESSENZIALE estratto, Note On/Off/Panic | PASS* |
| Analisi statica alpha17 (JS, JSON, HTML, 135 preset, 229 target MIDI Learn) | PASS |
| Test musicali e compatibilità alpha17 | 33/33 PASS |
| R3 runtime (Mod Matrix, BPM, clock, step MIDI, Sequencer, Arpeggiatore) | 32/32 PASS |
| R3 factory alpha17 | 10/10 PASS |
| Test Governor ereditato | 25/25 PASS |
| Stress voci alpha16 rieseguito su alpha17 | 30/30 PASS |
| Confronto audio deterministico alpha16/alpha17 | 3/3 PASS |
| R3 offline alpha17, suite 24 scenari | PARZIALE: 19 completati, processo interrotto senza esito finale |
| 135 preset: sweep alpha16 | 135/135 nella versione precedente; stessi factory byte-identici nella alpha17 |
| 135 preset: rendering audio integrale alpha17 | NON ESEGUITO |
| Collaudo audio/MIDI hardware reale alpha17 | NON ESEGUITO |
| Test pluriorario reale / test su più sistemi operativi | NON ESEGUITO |


### Dettaglio dei 33 controlli alpha17

- Export di patch e assenza di parametri runtime nelle patch.
- Round-trip JSON di oscillatori, PWM band-limited, FM guarded, inviluppi, curva velocity e Mod Matrix.
- Caricamento di una patch SynthX legacy priva di nuovi campi e ripristino dei fallback Classic e La4=440 Hz.
- Morph A/B tra due livelli di oscillatore, preview senza terminare la nota sostenuta, Restore e pulizia Note Off.
- MIDI sintetico multi-porta e multi-canale (proprietà delle note per sorgente), Note On velocity zero, Sustain CC64, Pitch Bend e Panic.
- Avvio/esclusione reciproca Sequencer/Arpeggiatore e spegnimento senza note pendenti.

*Il test dell'ESSENZIALE carica HTML e JavaScript dell'archivio effettivamente estratto in Chromium tramite contenuto incorporato; la navigazione diretta `file://`/`localhost` è limitata nell'ambiente.*

**Audio comparato:** OfflineAudioContext stereo a 48 kHz, 1 s con Note Off a 0,25 s: 3 scenari (`clean`, `dual`, `unison`), **288.000 campioni** totali confrontati. Massima differenza assoluta **1.46802801e-05**, soglia 2e-5, nessun campione non finito. Questi tre scenari non dimostrano identità sonora su tutte le patch.

**Test offline R3 alpha17:** 19 su 24 scenari hanno prodotto dati e nessun errore nei checkpoint raggiunti; il processo complessivo si è fermato per timeout. **Non classificare la suite completa come PASS.** Il file `regression_r3_a17_offline_partial.json` registra il progresso incompleto. Il precedente completamento R3 alpha16 rimane conservato nello storico.

**Preset:** 10 preset sono stati ricontrollati nella alpha17 con loading/Note On/Panic; i 135 factory preset sono identici alla alpha16, per cui la copertura 135/135 della alpha16 resta una baseline valida per i dati, non una nuova campagna audio completa alpha17.

## Limitazioni e rischi residui

1. Chromium headless e WebAudio offline non certificano il funzionamento fisico di tastiere MIDI, schede audio, driver, latenza percepibile o assenza di dropout.
2. Il monitoraggio del Governor AUTO usa segnali indiretti di ritardo JavaScript, non una misura della percentuale di CPU audio.
3. Test deterministici limitati a tre scenari; non sostituiscono ascolto di tutti i 135 preset, verifica in registri differenti e interazioni estreme di FM/Sync/PWM/FX.
4. Mancano collaudi reali pluriorari e prove con più browser/sistemi e controller; la beta pubblica deve essere condizionata a questi collaudi.
5. L'importazione legacy è stata esercitata con una patch sintetica rappresentativa, non con ogni vecchio formato SynthX storico.

## Cosa verificare a orecchio

Aprire in AUTO con volume prudente. Provare i factory preset in diversi registri; suonare e tenere accordi, eseguire Morph lento tra A/B, impostare Unison alto, Sustain, Sequencer e Arpeggiatore con cambi di BPM; ascoltare click, note tagliate e code anomale. Ripetere il confronto con la cartella alpha16 se emerge un cambiamento.

## Esito e fase successiva

**Alpha17 pronta per collaudo musicale, non certificata come beta pubblica.** I percorsi automatizzati descritti sono positivi; la copertura di produzione richiede hardware reale. Passo consigliato: beta candidate soltanto dopo prove reali diversificate e ulteriore chiusura dei test offline incompleti.
