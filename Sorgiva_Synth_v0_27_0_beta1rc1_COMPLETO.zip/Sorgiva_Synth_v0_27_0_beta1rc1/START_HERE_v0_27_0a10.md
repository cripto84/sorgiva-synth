# Sorgiva Synth v0.27.0-alpha10 — Come iniziare

1. Estrai interamente lo ZIP in una cartella dedicata.
2. Apri `index.html` in un browser Chromium desktop; per WebMIDI avvia invece `python3 -m http.server 8000` e visita `http://localhost:8000`.
3. Abbassa il volume di ascolto, premi **Sblocca Audio** e prova la tastiera virtuale.
4. Esplora i **135 factory preset** o parti da **Default Init**. Salva le patch personali ed esporta una copia JSON.
5. Le modalità di qualità **Pulse/PWM Band-limited** e **FM Guarded** sono opzionali: per compatibilità i preset legacy usano **Classic**.

La alpha10 si concentra su stabilità e misure; non aggiunge nuovi effetti creativi. Consulta `QA_REPORT_v0_27_0a10.md` per l'ambito dei test e le limitazioni. Questa è una **alpha sperimentale**.
