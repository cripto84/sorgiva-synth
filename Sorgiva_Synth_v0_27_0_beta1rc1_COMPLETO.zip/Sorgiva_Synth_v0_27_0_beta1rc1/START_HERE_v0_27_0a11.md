# Sorgiva Synth v0.27.0-alpha11 — Avvio e verifiche

1. Estrarre l’intero ZIP essenziale, senza spostare `index.html` fuori dalla cartella.
2. Aprire `index.html` in Chromium aggiornato e premere **Sblocca Audio**. Per MIDI hardware è preferibile un server `localhost` o HTTPS.
3. Caricare **Default Init** nella scheda Preset & Patch, suonare e rilasciare una nota.
4. Partire con volume basso, specialmente usando filtri risonanti, Drive e Unison elevato.

La alpha11 conserva i 135 factory preset e introduce una riduzione delle scritture DOM del monitor di sicurezza, oltre a uno stress test riproducibile. Non modifica volutamente gli algoritmi sonori.

Questa è una release sperimentale, non una certificazione di assenza di glitch con schede audio o controller MIDI fisici. Leggere `QA_REPORT_v0_27_0a11.md`.
