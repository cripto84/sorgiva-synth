# Sorgiva Synth v0.27.0-alpha16 — Quick Start

1. Estrai completamente il pacchetto ESSENZIALE.
2. Apri `index.html` in Chromium; per usare MIDI esterno esegui Sorgiva tramite `localhost` o `https`.
3. Riduci il volume di ascolto, premi **Sblocca Audio**, carica Default Init e suona qualche nota.
4. Per la gestione delle prestazioni apri **Performance → Adaptive Performance**. Parti dal profilo AUTO ed esegui eventualmente il benchmark silenzioso quando non stai suonando.
5. Prova Sustain, note ripetute, accordi, Release lunghe, Arpeggiatore e Sequencer. Ascolta personalmente eventuali anomalie sonore: i test automatici non possono certificare l'assenza di click su ogni hardware.
6. Per tornare alla alpha15 basta usare la cartella della versione precedente; esporta prima la User Bank se necessario.

La alpha16 non cambia i suoni factory e non promette migliori prestazioni CPU rispetto alla alpha15: rende più approfondite e verificabili le prove di stabilità.
