# Sorgiva Synth v0.27.0-alpha16 — Rapporto QA

**Data:** 27 ottobre 2026  
**Versione verificata:** `0.27.0-alpha16`  
**Base:** archivi `Sorgiva_Synth_v0_27_0a15_COMPLETO(1).zip` e `Sorgiva_Synth_v0_27_0a15_ESSENZIALE(1).zip` caricati dall'utente.  
**Obiettivo:** Extended Stability & Regression. Non alterare il suono rispetto alla alpha15.

## Integrità della baseline alpha15

- CRC completo dei due ZIP alpha15: **PASS**.
- Tutti i 51 file dell'ESSENZIALE alpha15 byte-identici ai corrispondenti del COMPLETO: **PASS**.
- Test statici alpha15: **PASS**, inclusi JS, JSON, HTML, 135 preset e 229 destinazioni MIDI Learn.
- Il collaudo musicale alpha15 eseguito dall'utente è stato riferito positivo. Non costituisce una prova automatica dei dropout.

## Modifiche apportate

1. `tests/regression_r3.py`: il test R3 monolitico è stato suddiviso in `runtime`, `factory`, `offline`. Gli scenari factory sono eseguiti a gruppi, ognuno in una pagina Chromium nuova, con checkpoint JSON e recupero delle prove concluse dopo interruzione di un processo.
2. `tests/phase16_factory_coverage.py`: aggrega e verifica la copertura puntuale degli indici 0–134, senza dichiarare PASS un processo interrotto; i suoi segmenti individuali completati possono tuttavia contribuire alla copertura.
3. `tests/phase16_stability.py`: nuovo stress browser di retrigger, turnover di accordi, voci programmate nel futuro e pulizia dei registri dopo Panic.
4. Metadati della versione, file export, static check, README, release notes e istruzioni di QA allineati ad alpha16.
5. **Non modificati:** `src/audio/*.js`, `src/presets/factory-presets.js`, algoritmi DSP, Gain Guard, preset, parametri o regolazione del Governor.

## Test effettivamente eseguiti

| Controllo | Esito |
|---|---|
| Static (JS syntax, JSON, HTML, factory, MIDI Learn) | **PASS** |
| Adaptive alpha13, 21 verifiche | **PASS** |
| Intelligent Governor alpha14, 25 verifiche | **PASS** |
| Voice Allocator equivalence alpha15, 512 insiemi | **PASS** |
| Budget Release alpha12 + future-scheduled notes | **PASS** |
| R3 funzionale, 32 controlli | **PASS** |
| R3 WebAudio offline, 24 render a 48 kHz | **PASS** |
| Factory R3 in pagine isolate, 135/135 preset | **PASS** (checkpoint aggregati) |
| Stress alpha16, 30 controlli | **PASS** |
| Confronto audio alpha15 vs alpha16, 3 configurazioni stereo | **PASS** |
| Avvio ESSENZIALE estratto (HTML/JS caricati in Chromium) | **PASS** |
| R3 monolitica in un unico processo | **NON ESEGUITA** (sostituita da esecuzioni separate) |
| 135 preset con rendering integrale della patch | **NON ESEGUITO** |
| MIDI hardware fisico / driver / dropout realtime | **NON ESEGUITO** |
| Test di durata plurioraria su un computer reale | **NON ESEGUITO** |

La copertura **135/135** è relativa a caricamento preset, creazione voce WebAudio, assenza di mutazione del preset e pulizia post-Panic. **Non** è una misura timbrica completa dei 135 preset. Due sessioni di scansione si sono interrotte senza verdetto finale; i rispettivi gruppi già conclusi sono stati salvati in JSON e sono stati combinati con esecuzioni autonome sui gruppi successivi. Il riepilogo `tests/phase16_factory_coverage_results.json` verifica l'assenza di indici mancanti.

La prova di stabilità alpha16 ha effettuato **120** riattivazioni della stessa nota, **24** cicli di accordi da **6** note e **16** note pianificate, con azzeramento di voci, voci sospese, Release e voci programmate dopo Panic. Le 30 verifiche NON equivalgono a un test continuativo di ore.

**Parità audio deterministica:** confronto con alpha15 in 3 scenari stereo (48 kHz, 1 s, 96.000 campioni per scenario, 288.000 totali). Differenza massima assoluta **5.31971455e-06**; soglia **2e-5**, nessun valore non finito. Confronto limitato alle tre configurazioni del test.

**Factory byte-identici** alla alpha15, SHA-256: `1a886b4c9dddad1f0e07da0812f0156534c75098ed9f977cafcf0cf4e8d227c2`.

## Limiti importanti

- Nell'ambiente QA la navigazione Chromium verso `file://` e `localhost` è bloccata amministrativamente. Il controllo ESSENZIALE è stato eseguito caricando **i file HTML e JavaScript dall'archivio realmente estratto**, iniettati nella pagina headless solo come contenuto, senza gli hook audio interni della suite. Non è una prova di navigazione diretta.
- Le prove Chromium headless simulano il motore WebAudio, non misurano dropout audio, uso CPU DSP o latenze acustiche reali.
- Il Governor in AUTO continua a usare il ritardo del thread JavaScript come segnale indiretto, NON una misura della CPU audio.
- Non si dichiarano riduzioni di CPU/RAM per questa versione, né garanzia universale di qualità timbrica.
- Un intervento di governor sotto stress può impedire la creazione di nuove note; non dovrebbe interrompere le note già suonate. Confrontare con alpha15 in caso di problemi.
- Le prove future necessarie prima della beta includono stress realmente prolungato, MIDI esterno, dispositivi e browser diversi e una nuova campagna di ascolti su più patch.

## Distribuzione e rollback

Il pacchetto COMPLETO include sorgenti, test, checkpoint, QA e storico. L'ESSENZIALE contiene runtime, licenze e documentazione operativa, senza test e log. Gli ZIP vengono sottoposti a CRC, verifica dei file condivisi e smoke browser su archivio essenziale estratto. Per tornare alla alpha15 basta aprire la relativa cartella; i formati delle patch restano invariati.
