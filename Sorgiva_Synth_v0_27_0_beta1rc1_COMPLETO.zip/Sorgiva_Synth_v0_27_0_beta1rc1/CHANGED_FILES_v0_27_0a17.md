# File modificati v0.27.0-alpha17

Runtime: `src/core/identity.js`, `src/main.js`, `index.html`, `src/presets/presets.js`, `src/presets/preset-morph.js`, `src/arp/arpeggiator.js`, `src/sequencer/step-sequencer.js`, `src/midi/midi-learn.js`, commento versione `src/performance/adaptive-performance.js`. Version metadata: `VERSION`, `VERSION.txt`.

Test e documenti: `tests/phase17_musical_compatibility.py`, `tests/smoke_static.py`, `tests/regression_r3.py` e risultati corrispondenti; `README.txt`, release notes, quick start, QA e documentazione alpha17. I file audio DSP e i factory preset sono invariati.
