# Sorgiva Synth v0.26.7h — Parameter Coverage Audit / Control Surface Map

Baseline analizzata: `Sorgiva Synth v0.26.7g1 — Advanced Chord Motion Param Routing Hotfix`.

Questa build è un audit/documentation pass: non introduce nuove funzioni sonore, non modifica oscillatori, filtri, FX, voice management, MIDI runtime o preset factory. Lo scopo è mappare le superfici di controllo attuali e stabilire cosa deve essere riallineato nei passi successivi: Sequencer Randomizer, pattern preset del sequencer, Sound Randomizer, MIDI Learn, Morph, A/B Compare, export/import e confini tra preset.

---

## 1. Metodo

Controlli analizzati:

- `index.html`: tutti gli `input`, `select`, `button`, `textarea` con `id`.
- `src/ui/controls.js`: controlli effettivamente collegati allo stato tramite binding UI.
- `src/presets/presets.js`: raccolta/esportazione dei parametri di preset.
- `src/presets/randomizer.js`: copertura del Sound Randomizer.
- `src/sequencer/step-sequencer.js`: pattern, randomize prudente, schema export/import pattern 1.2.
- `src/presets/preset-morph.js`: lista dei parametri numerici morfabili.
- `src/midi/midi-learn.js`: target MIDI Learn disponibili.
- `src/presets/preset-constants.js`: esclusioni preset/runtime.

Controlli sintassi effettuati:

- `node --check src/sequencer/step-sequencer.js`
- `node --check src/presets/randomizer.js`
- `node --check src/midi/midi-learn.js`
- `node --check src/presets/presets.js`

Esito syntax check: **OK**.

---

## 2. Conteggio superfici di controllo

| Area | Numero |
|---|---:|
| Input/select totali UI | 679 |
| Input/select bindati dalla UI principale | 639 |
| Parametri raccolti da `collectParameters()` prima del filtro runtime | 639 |
| Parametri che finiscono nel preset export dopo filtro runtime | 637 |
| Target MIDI Learn attuali | 59 |
| Parametri morfabili secondo `SAFE_NUMERIC_IDS` | 88 |

Distribuzione dei parametri che entrano nel preset export:

| Famiglia | Parametri |
|---|---:|
| Sequencer | 420 |
| FX/EQ | 38 |
| Filters / Advanced Filter | 36 |
| LFO | 33 |
| Mod Matrix | 32 |
| Oscillators | 27 |
| Oscillator Extensions | 20 |
| Arpeggiator | 10 |
| Master / Safety / Tuning | 9 |
| Performance | 7 |
| Amp Envelope | 5 |

### Nota importante

Il fatto che **420 parametri Sequencer** risultino inclusi nel sound preset export è il punto architetturale più importante dell'audit. Attualmente il sound preset può catturare l'intero stato degli step del sequencer. Questo può essere utile per snapshot completi, ma non è coerente con la separazione ideale:

- Sound Preset = timbro;
- Sequencer Pattern = pattern;
- Arp Behavior = comportamento arpeggiatore;
- MIDI Mapping = controller hardware;
- Scene Preset = eventuale formato futuro totale.

Raccomandazione: nella prossima fase non rimuovere subito questi campi in modo distruttivo, ma introdurre una policy esplicita di confine e decidere se i sound preset devono continuare a salvare motion oppure se il motion va spostato in formati dedicati.

---

## 3. Sound Randomizer

Stato attuale: **buono sul timbro, assente sul sequencer**.

Il randomizer sonoro copre semanticamente:

- Oscillatori 1/2/3: enabled, wave, level, semi, fine, pan;
- Pulse/PWM: pulse width, PWM amount, PWM source quando la wave è pulse;
- Noise: enabled, type, level;
- Ring Mod: enabled, source A/B, amount;
- FM Light: enabled, carrier, modulator, amount;
- Osc Sync: enabled, master/slave, amount;
- Unison: enabled, voices, max layers, detune, spread;
- LFO 1/2/3: enabled, wave, rate mode, rate, sync, depth, destination, mode;
- Filtri base: HPF/BPF/Notch/VCF enabled, cutoff, Q, slope ove previsto;
- Filter ADSR e Filter Drive;
- Advanced Filter: enabled, mode, freq, depth, mix, vowel, env/velocity routing;
- Amp ADSR;
- Drive/Saturation, EQ, Mod FX, Delay, Reverb;
- Mod Matrix 8 slot con source/destination/amount e guardrail.

Esclusioni intenzionali attuali:

- MIDI runtime;
- User Bank / factory preset browser;
- import/export;
- Master Tuning;
- Safety bypass;
- Sequencer/Arpeggiator transport;
- Sequencer pattern avanzato.

Valutazione: corretta come Sound Randomizer, ma non basta più. Serve un **Sequencer Randomizer separato**.

---

## 4. Sequencer Randomizer

Stato attuale: **presente ma legacy/prudente**.

Funzione identificata: `randomizePattern()` in `src/sequencer/step-sequencer.js`.

Cosa randomizza ora:

- lunghezza corrente mantenuta;
- active/rest con probabilità prudente;
- note da scala safe;
- octave base 3/4 con nudge leggero;
- step fuori lunghezza spenti.

Cosa NON randomizza ora:

- velocity musicali;
- gate per step;
- accent;
- tie;
- chord type;
- custom intervals;
- inversion;
- spread;
- strum;
- chord velocity mode;
- profili musicali;
- densità ritmica/armonica regolabile;
- stili tipo Acid/Berlin/Ambient/Industrial/Odd Meter.

Nota dal codice: il commento interno dice esplicitamente che il randomize mantiene i nuovi parametri espressivi neutri e non introduce un randomizer pattern avanzato.

Conclusione: questa è la priorità del prossimo passo. Il nuovo modulo deve diventare:

`Sequencer Randomizer v0.26.7i`

con profili musicali e controlli di densità, ma senza toccare il sound preset.

---

## 5. Sequencer Pattern Presets / Export / Import

Stato attuale: **buona base tecnica, libreria da rifare musicalmente**.

Elementi già presenti:

- 32 step;
- lunghezze 3–32;
- schema pattern `sorgiva-synth-step-pattern-v1`;
- formatVersion `1.2`;
- feature flag per step chords;
- chord presets;
- custom intervals;
- inversion;
- spread;
- strum;
- chord velocity modes;
- fallback legacy: chord mancante = Off;
- export/import JSON dedicato;
- user pattern localStorage con mirror legacy.

Valutazione: il formato è già adatto al nuovo sequencer. Il problema non è lo schema, ma il contenuto dei pattern e il randomizer.

Raccomandazione:

1. Prima implementare il Sequencer Randomizer avanzato.
2. Poi rifare la libreria pattern sfruttando chord motion, inversion, spread, strum e velocity/gate.
3. Tenere i pattern separati dal sound preset.

---

## 6. MIDI Learn / Mapping

Stato attuale: **solido ma parziale**.

Target MIDI Learn attuali: **59**.

Copertura attuale:

- Master Volume;
- Master Tuning;
- Oscillator level/fine/pan;
- Noise volume;
- cutoff/Q principali;
- Filter Env base;
- Filter Drive amount/trim;
- Advanced Filter principali;
- Velocity to VCF e key tracking;
- Keyboard Velocity;
- Drive amount;
- Delay mix/time/feedback/damp;
- Reverb mix;
- Mod FX mix/rate;
- LFO rate/depth;
- Mod Matrix amount 1–8;
- ADSR attack/release;
- EQ low/high.

Mancanze importanti:

- non c'è supporto esplicito per toggle/selector/trigger;
- PWM amount/source non mappati;
- Ring Mod amount/sources/enabled non mappati;
- FM amount/carrier/modulator/enabled non mappati;
- Osc Sync amount/master/slave/enabled non mappati;
- Unison detune/spread/voices/layers/enabled non mappati;
- molti LFO selector non mappati;
- FX avanzati incompleti: reverb size/decay/damp, sat tone/mix/asym/hard/bias/gate/oct, EQ middle bands;
- nessun target sequencer/arp;
- nessun trigger per Randomize Sequencer, next pattern, start/stop, panic dedicato con protezione.

Raccomandazione:

- introdurre tipi target: `continuous`, `toggle`, `selector`, `trigger`;
- non mappare ogni singolo step via MIDI Learn classico;
- mappare invece parametri globali e azioni del sequencer: enabled, start/stop, rate, swing/gate, length, transpose se presente, randomize sequencer, next/previous pattern.

---

## 7. Morph / A-B Compare

Stato Morph attuale: **prudente e stabile, ma non completo rispetto alle nuove possibilità**.

Morfabili attuali:

- livelli/tune/pan/pulse/PWM amount oscillatori;
- Ring/FM/Sync amount;
- Noise dB;
- LFO rate/depth;
- amp/filter ADSR numerici;
- cutoff/Q/keytrack/velocity;
- Filter Drive amount/trim;
- Advanced Filter numerici;
- EQ;
- saturation numerici;
- Mod FX numerici;
- Delay numerici;
- Reverb numerici;
- Mod Matrix amount 1–8.

Non morfabili attuali:

- Unison detune/spread/voices/layers;
- toggles e selector;
- sequencer;
- arp;
- MIDI mapping;
- Master Tuning;
- safety;
- preset browser state.

Valutazione: corretto per evitare stati ambigui. Però almeno **Unison detune/spread** sono candidati forti per entrare nel Morph sonoro sicuro. Voices/layers invece possono restare fuori o essere trattati con una modalità speciale.

A/B Compare usa snapshot di preset tramite il sistema preset. Quindi eredita il problema del confine: se il sound preset include anche sequencer/arp, A/B può diventare snapshot più ampio del solo timbro.

---

## 8. Confine preset: problema principale

Attualmente `collectParameters()` raccoglie molti controlli musicali e motion non marcati come runtime/preset-ui. Dopo il filtro runtime restano nel preset export:

- 420 controlli sequencer;
- 10 controlli arpeggiatore;
- 7 performance;
- 9 master/safety/tuning.

Questo significa che il preset è di fatto più vicino a uno snapshot/scene parziale che a un puro sound preset.

Non è necessariamente un bug immediato, ma è una decisione da prendere prima della public alpha.

Opzioni:

### Opzione A — Conservativa immediata

Lasciare il comportamento attuale, ma documentare che il preset salva anche motion state. Rischio: confusione utente.

### Opzione B — Separazione pulita consigliata

Sound Preset salva solo timbro + performance strettamente musicale. Sequencer Pattern e Arp Behavior restano formati separati. Rischio: serve migrazione prudente.

### Opzione C — Scene Preset futuro

Tenere Sound Preset pulito e aggiungere in futuro Scene Preset per salvare tutto. Consigliato dopo public alpha, non ora.

Raccomandazione per v0.26.7i/v0.26.7j: introdurre prima il Sequencer Randomizer e rifare i pattern. La separazione preset va fatta subito dopo, quando i formati motion sono stabili.

---

## 9. Priorità operative emerse dall'audit

### Priorità 1 — Sequencer Randomizer avanzato

Creare un randomizer separato con profili:

- Bassline;
- Acid;
- Berlin School;
- Chord Pulse;
- Ambient Motion;
- Industrial;
- Odd Meter;
- Chiptune;
- Minimal;
- Cinematic;
- Chaos Safe;
- Performance Test.

Deve agire solo su sequencer pattern.

### Priorità 2 — Sequencer Pattern Preset Rebuild

Rifare la libreria pattern dopo il nuovo randomizer, sfruttando:

- chord;
- inversion;
- spread;
- strum;
- custom intervals;
- velocity/gate/accent/tie;
- lunghezze dispari.

### Priorità 3 — MIDI Learn espanso

Aggiungere target continui mancanti e introdurre target type:

- continuous;
- toggle;
- selector;
- trigger.

### Priorità 4 — Preset Boundary Alignment

Decidere cosa salva il sound preset e cosa resta nei formati dedicati.

### Priorità 5 — Morph Alignment

Aggiungere almeno Unison detune/spread al Morph sonoro sicuro, valutando poi altri parametri continui.

---

## 10. Prossimo passo consigliato

Build successiva consigliata:

**v0.26.7i — Sequencer Randomizer Advanced Design / Implementation Prep**

Scopo:

- non toccare il motore audio;
- progettare e implementare un primo Sequencer Randomizer avanzato;
- aggiungere profili musicali;
- mantenere Safety/Panic/Stop invariati;
- non modificare sound preset, factory preset o MIDI mapping in questa build.

Questo ordine è preferibile perché il randomizer del sequencer è la funzione che oggi più chiaramente non sfrutta le nuove potenzialità già presenti nel codice.
