# Sorgiva Synth v0.26.7p — MIDI Learn Coverage Audit / Mapping Target Classification

Data: 2026-07-09
Baseline: v0.26.7o — Arp / Motion Randomizer Alignment

## Scopo

Questa build è un audit/classificazione del MIDI Learn. Non espande ancora i mapping runtime e non cambia il comportamento MIDI già testato con hardware reale.

## Verdetto v0.26.7o

La v0.26.7o risulta sana nei controlli strutturali principali, ma aveva un residuo attivo minore nel filename export dei mapping MIDI Learn: `_v0_26_7n_`. La v0.26.7p lo corregge a `_v0_26_7p_`.

## Copertura attuale MIDI Learn

- Target attuali: 59
- Modalità attuale: 59 continuous, 0 toggle, 0 selector, 0 trigger
- Limite mapping salvati: 32
- Import massimo: 256 entry
- CC riservati/bloccati: 1, 2, 4, 11, 64, 120, 121, 123

## Target attuali per gruppo

| Gruppo | Target continuous attuali |
|---|---:|
| Master/Global | 2 |
| Oscillators/Voice | 11 |
| Filters/Envelope | 22 |
| FX/EQ | 10 |
| LFO | 6 |
| Mod Matrix | 8 |
| Performance Sound | 2 |

## Target continuous prioritari mancanti

Questi sono buoni candidati per una prossima espansione, perché sono range continui naturali:

- Osc/Voice: osc semi, pulse width, PWM amount, ring amount, FM amount, sync amount, unison voices/max layers/detune/spread, polyphony voices.
- Filters/Envelope: HPF/BPF/Notch Q, amp envelope Decay/Sustain.
- FX/EQ: EQ low-mid/mid/high-mid, saturation tone/mix/predb/voicing/DC/asym/hard/bias/gate/oct, modulation depth, reverb size/decay/damp.
- Performance: octave shift, glide time.
- Motion: seq rate, seq global gate, arp rate/gate/swing/octaves.

## Toggle candidati

Da implementare solo quando MIDI Learn supporta esplicitamente mode `toggle` con soglia CC:

- Osc/noise/ring/FM/sync/unison enabled.
- LFO1/2/3 enabled e LFO target oscillatori.
- Filter blocks enabled.
- Filter drive enabled.
- Advanced filter enabled.
- EQ, saturation, modulation FX, delay, reverb enabled.
- Sequencer enabled.
- Arpeggiator enabled.
- Performance hold/glide enabled.

## Selector candidati

Da implementare solo quando MIDI Learn supporta mode `selector` con zone CC 0–127:

- Osc waveform, PWM source.
- Ring source A/B.
- FM carrier/modulator.
- Sync master/slave.
- LFO wave/rate mode/sync/destination/mode.
- Filter slopes, filter envelope target/polarity.
- Filter drive mode.
- Advanced filter mode/vowel.
- Saturation/mod/delay/reverb modes.
- Arp mode/direction/motion shape.
- Sequencer length/pattern preset/randomizer profile/scope/density.

## Trigger candidati

Da implementare solo quando MIDI Learn supporta mode `trigger`, edge-detect e cooldown:

- Panic / All Notes Off.
- Randomize Sound Patch.
- Randomize Sequencer.
- Randomize Arp Behavior.
- Sequencer apply pattern / next pattern / previous pattern eventuali.
- Arp preset apply eventuale.
- Reset FX / EQ / Mod Matrix slot eventuali.

## Target da non mappare per ora

- Import/export file.
- Clear user bank / reset distruttivi.
- Safety off globale.
- LocalStorage reset.
- File picker e textarea JSON.
- Monitor read-only MIDI.
- Ogni singolo step del sequencer via MIDI Learn classico: troppo denso; eventuale futuro `MIDI Step Edit Mode` separato.

## Raccomandazione prossimo step

Procedere con `v0.26.7q — MIDI Learn Coverage Expansion`, ma prima aggiungere nel codice la gestione esplicita delle modalità:

- continuous: comportamento attuale;
- toggle: soglia 64;
- selector: zone quantizzate;
- trigger: edge/cooldown, niente ripetizioni incontrollate.

Solo dopo questi mode handler conviene aumentare realmente i target disponibili nella UI.
