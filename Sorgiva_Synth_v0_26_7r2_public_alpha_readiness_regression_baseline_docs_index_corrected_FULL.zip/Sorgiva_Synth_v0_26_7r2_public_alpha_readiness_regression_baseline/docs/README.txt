Sorgiva Synth v0.26.7r2 — Indice documentazione FULL
======================================================

Indice documentale corrente della linea desktop/core.

Questo pacchetto FULL contiene:

- applicazione completa e sorgente;
- documentazione utente e sviluppatore corrente;
- report QA e manifest della build v0.26.7r2;
- smoke test statici e browser;
- cronologia tecnica completa delle build precedenti;
- release notes, manifest e metriche storiche preservate come archivio.

Build corrente
--------------

Sorgiva Synth v0.26.7r2 — Public Alpha Readiness & Regression Baseline

La build consolida la preparazione alla public alpha senza modificare il comportamento sonoro:

- Preset Morph protetto all'avvio quando gli slot A e B sono vuoti;
- baseline MIDI hardware reale registrata come superata il 9 luglio 2026;
- versioni e filename export riallineati a v0.26.7r2;
- 135 factory preset invariati;
- aggiunta della prima baseline di smoke test statici e browser;
- nessuna modifica alla topologia audio o ai parametri timbrici.

Documenti correnti principali
-----------------------------

- `../README.txt` — panoramica della build e istruzioni di avvio;
- `../CHANGELOG.txt` — modifiche della v0.26.7r2 e cronologia recente;
- `../KNOWN_LIMITS.txt` — limiti noti e stato della regressione hardware MIDI;
- `../ROADMAP_PUBLIC.txt` — passi successivi verso la public alpha;
- `QA_REPORT_v0_26_7r2_PUBLIC_ALPHA_READINESS.txt` — rapporto QA della build;
- `PUBLIC_ALPHA_READINESS_REGRESSION_BASELINE_BUILD_MANIFEST_v0_26_7r2.json` — manifest tecnico corrente;
- `../tests/README.txt` — ambito, uso e limiti degli smoke test;
- `../presets/README.txt` — stato della libreria factory;
- `../presets/factory/CURRENT_FACTORY_PRESETS_README.txt` — riferimento factory corrente.

Archivio storico
----------------

Gli altri documenti presenti in questa cartella e nelle sottocartelle `release-notes` e
`qa-reports` descrivono le build precedenti. Restano preservati per tracciabilità tecnica,
ma non devono essere interpretati come stato corrente del progetto quando riportano una
versione anteriore alla v0.26.7r2.
