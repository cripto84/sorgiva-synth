# Sorgiva Synth v0.26.7q — MIDI Learn Coverage Expansion

## Obiettivo

Espandere MIDI Learn dopo l'audit v0.26.7p, passando da una lista solo continuous a una superficie mappabile più completa e classificata.

Questa build implementa i quattro mode handler previsti:

- `continuous`: CC 0–127 convertito nel range numerico del controllo;
- `toggle`: CC < 64 = OFF, CC >= 64 = ON;
- `selector`: CC 0–127 diviso in zone sulle opzioni della select;
- `trigger`: rising edge sopra soglia, con riarmo quando il CC torna sotto soglia.

## Coverage risultante

- Target totali: 229
- Continuous: 106
- Toggle: 48
- Selector: 71
- Trigger: 4
- Max mapping simultanei: 64

## Target aggiunti o resi mappabili

La v0.26.7q aggiunge target per:

- oscillatori: semitone, pulse width, PWM amount, enable, wave, PWM source;
- Ring/FM/Sync/Unison: amount, enable, sorgenti/selectors, detune/spread/layer;
- LFO: enable, wave, rate mode, sync, destination, routing e target per oscillatore;
- Mod Matrix: enable/source/destination/amount sugli 8 slot;
- filtri/inviluppi: enable, Q mancanti, slope, target/polarity e advanced filter selector;
- FX/EQ: enable, mode, size/decay/damp, parametri saturazione/EQ mancanti;
- performance: hold/glide, mode, octave, glide time, velocity curve;
- sequencer: on/off, rate, gate, length, randomizer selectors e Randomize Sequencer trigger;
- arpeggiatore: on/off, latch/options, mode, rate/gate/swing/octaves e Randomize Arp Behavior trigger;
- utility: Panic / All Notes Off come trigger protetto.

## Guardrail

- CC riservati esclusi: 1, 2, 4, 11, 64, 120, 121, 123.
- I trigger non si ripetono continuamente mentre il CC resta alto.
- Ogni target ha al massimo un CC e ogni CC controlla un solo target.
- Import/export resta JSON semplice separato dai preset sonori.
- Nessun oggetto WebMIDI, evento, timer, funzione o nodo DOM viene esportato.

## Non modificato

- Motore audio / topologia voce.
- Factory sound preset.
- Sequencer pattern preset.
- Sequencer Randomizer.
- Sound Randomizer.
- Arp / Motion Randomizer.
- Gain Guard / Panic / Stop audio.

## Prossimo passo consigliato

`v0.26.7r — MIDI Learn UI Reorganization / Hardware Regression Prep`

Serve a rendere più leggibile la lista target ora molto ampia: filtro per categoria, badge mode, warning collisioni, e poi test hardware MIDI reale.
