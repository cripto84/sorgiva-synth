SynthX Rebuild v0.22.0a — Pulse Width / PWM Audio Hotfix — PATCH README

Applicare sopra SynthX_Rebuild_v0_22_0_pulse_width_pwm_basic_safe_FULL.

Contenuto patch:
- index.html
- src/audio/audio-context.js
- src/ui/controls.js
- src/main.js
- src/state/state.js
- src/presets/presets.js
- README.txt
- CHANGELOG.txt
- VERSION.txt
- QA_REPORT_v0_22_0a_pulse_width_pwm_audio_hotfix.txt
- PATCH_README_v0_22_0a.txt
- docs/101_PULSE_WIDTH_PWM_AUDIO_HOTFIX_v0_22_0a.txt

Nota: la cartella presets/ non viene modificata.
