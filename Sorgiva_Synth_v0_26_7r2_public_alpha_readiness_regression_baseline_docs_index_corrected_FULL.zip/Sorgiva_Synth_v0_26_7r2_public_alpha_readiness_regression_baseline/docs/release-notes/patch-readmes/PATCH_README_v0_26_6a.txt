Sorgiva Synth v0.26.6a — PATCH README

Base richiesta:
- Sorgiva Synth v0.26.6 — Manual Browser Regression / Public Alpha Release Prep

Output atteso:
- Sorgiva Synth v0.26.6a — Public Alpha Text / Release Notes / Index Zero-Warning Cleanup

Scopo patch:
- Pulizia zero-warning dei testi attivi e degli indici prima della prova manuale reale in browser.
- Correzione badge/descrizioni UI, release notes index, roadmap, changelog/notice e metadati runtime/export.
- Nessuna modifica intenzionale a motore audio, preset sonori, UI funzionale, MIDI runtime, Sequencer, Arpeggiator, Mod Matrix, Randomizer, Morph o A/B Compare.

Applicazione:
- Copiare il contenuto della PATCH sopra la root della v0.26.6.
- Dopo l'applicazione, il contenuto deve corrispondere al FULL bundle v0.26.6a.

File patch readme:
- Questo file resta dentro `docs/release-notes/patch-readmes/`, quindi non crea file extra nella root applicativa.
