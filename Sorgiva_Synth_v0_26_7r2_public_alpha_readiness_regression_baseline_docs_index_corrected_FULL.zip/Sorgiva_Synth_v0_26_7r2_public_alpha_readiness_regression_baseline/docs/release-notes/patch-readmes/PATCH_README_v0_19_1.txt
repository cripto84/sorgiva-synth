SynthX Rebuild v0.19.1 — Mod Matrix QA / Hardening PATCH

Base richiesta:
- SynthX_Rebuild_v0_19_0_modulation_matrix_basic_FULL.zip

Contenuto della patch:
- Hardening della Modulation Matrix Basic senza espansione funzionale.
- Source/destination non validi gestiti senza crash e senza attivare modulazioni inattese.
- Scaling più prudente per Pitch, Volume, Pan, filtri, Advanced Filter e Drive.
- Cap cumulativo sulle modulazioni sommate verso lo stesso AudioParam.
- Smoothing leggero dei gain di modulazione.
- Metadata, README, CHANGELOG, VERSION e QA report aggiornati.

File principali nella patch:
- VERSION.txt
- README.txt
- CHANGELOG.txt
- index.html
- styles/main.css
- src/main.js
- src/state/state.js
- src/audio/audio-context.js
- src/modulation/modulation-matrix.js
- src/presets/presets.js
- src/ui/controls.js
- docs/90_MOD_MATRIX_QA_HARDENING_v0_19_1.txt
- QA_REPORT_v0_19_1_mod_matrix_hardening.txt
- PATCH_README_v0_19_1.txt

Nota:
Questa patch non modifica musicalmente i factory preset e non sostituisce i vecchi routing di modulazione.
