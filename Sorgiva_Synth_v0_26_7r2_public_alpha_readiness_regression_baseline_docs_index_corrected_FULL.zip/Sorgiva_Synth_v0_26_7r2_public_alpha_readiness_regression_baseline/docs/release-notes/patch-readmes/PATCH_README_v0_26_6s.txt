Sorgiva Synth v0.26.6s PATCH README

Patch base attesa: v0.26.6r Active Metadata / History Separation Hotfix.

Scopo patch:
- applicare il MIDI USB Input Autodetect Hotfix senza modificare preset sonori o DSP audio.

File principali modificati:
- src/midi/midi.js
- src/core/identity.js
- index.html
- VERSION / VERSION.txt
- README / ROADMAP / CHANGELOG / NOTICE
- docs/README.txt
- docs/release-notes/INDEX.txt
- metadata export/version labels nei moduli che esportano preset, arp, sequencer e MIDI Learn
- README preset/factory

Cosa cambia nel runtime MIDI:
- modalità `Tutti gli input MIDI (auto)` per controller con più input;
- default automatico su tutti gli input quando ce n'è più di uno;
- tracking note port/channel-aware;
- detach sicuro degli handler WebMIDI;
- fallback requestMIDIAccess senza options object;
- status UI più chiaro per tester.

Cosa non cambia:
- DSP audio;
- factory preset data/sound design;
- Mod Matrix FX routing;
- Sequencer/Arpeggiator runtime;
- Randomizer, Morph, A/B Compare;
- layout generale.
