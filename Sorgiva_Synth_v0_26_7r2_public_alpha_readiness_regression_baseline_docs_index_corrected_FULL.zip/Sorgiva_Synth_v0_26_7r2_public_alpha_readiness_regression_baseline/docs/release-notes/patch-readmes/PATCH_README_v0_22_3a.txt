PATCH v0.22.3a — Osc Sync QA / Musical Hardening

Applicare sopra:
SynthX_Rebuild_v0_22_3_osc_sync_feasibility_basic_safe_FULL.zip

Contenuto patch:
- index.html
- README.txt
- CHANGELOG.txt
- VERSION.txt
- PATCH_README_v0_22_3a.txt
- OSC_SYNC_QA_MUSICAL_HARDENING_v0_22_3a.txt
- QA_REPORT_v0_22_3a_osc_sync_qa_musical_hardening.txt
- docs/106_OSC_SYNC_QA_MUSICAL_HARDENING_v0_22_3a.txt
- src/main.js
- src/state/state.js
- src/audio/audio-context.js
- src/ui/controls.js
- src/presets/presets.js
- src/presets/preset-morph.js
- src/presets/randomizer.js

Non incluso/modificato:
- presets/
- src/presets/factory-presets.js
