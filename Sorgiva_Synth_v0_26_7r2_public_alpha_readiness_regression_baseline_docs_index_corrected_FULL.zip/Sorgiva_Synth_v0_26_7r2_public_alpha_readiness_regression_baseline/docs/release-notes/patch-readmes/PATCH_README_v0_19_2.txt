SynthX Rebuild v0.19.2 — PATCH README

Applicazione patch
Copiare i file della patch sopra una build v0.19.1 Mod Matrix Hardening.

Contenuto principale
- index.html
- styles/main.css
- src/modulation/modulation-matrix.js
- src/audio/audio-config.js
- src/audio/audio-context.js
- src/state/state.js
- src/ui/controls.js
- src/midi/midi-learn.js
- src/presets/presets.js
- src/main.js
- README / CHANGELOG / VERSION / docs / QA report

Nota
La patch non modifica la cartella presets/factory e non altera intenzionalmente i suoni factory.
