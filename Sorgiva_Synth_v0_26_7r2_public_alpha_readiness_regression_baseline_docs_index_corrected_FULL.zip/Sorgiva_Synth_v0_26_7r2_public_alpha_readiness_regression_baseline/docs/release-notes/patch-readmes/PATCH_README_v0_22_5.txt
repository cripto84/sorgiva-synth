SynthX Rebuild v0.22.5 — PATCH README
======================================

Patch: Oscillator Character Final QA / Integration
Base attesa: SynthX_Rebuild_v0_22_4b_unison_detune_qa_cpu_musical_hardening_FULL.zip

Contenuto patch
---------------
Questa patch applica una passata conservativa di chiusura della fase oscillatori.
Non aggiunge nuovi moduli sonori e non modifica i factory preset.

File modificati principali:
- VERSION
- VERSION.txt
- index.html
- README.txt
- CHANGELOG.txt
- src/state/state.js
- src/main.js
- src/audio/audio-context.js
- src/presets/preset-morph.js
- src/presets/presets.js
- src/presets/randomizer.js

File aggiunti:
- OSCILLATOR_CHARACTER_FINAL_QA_INTEGRATION_v0_22_5.txt
- QA_REPORT_v0_22_5_oscillator_character_final_qa_integration.txt
- PATCH_README_v0_22_5.txt

Preservato
----------
- presets/ invariata.
- src/presets/factory-presets.js invariato.
- Nessun nuovo factory preset.
- Nessuna modifica musicale intenzionale.

Nota
----
Applicare la patch sopra la v0.22.4b. Per evitare confusione, è comunque consigliato usare direttamente il FULL bundle v0.22.5.
