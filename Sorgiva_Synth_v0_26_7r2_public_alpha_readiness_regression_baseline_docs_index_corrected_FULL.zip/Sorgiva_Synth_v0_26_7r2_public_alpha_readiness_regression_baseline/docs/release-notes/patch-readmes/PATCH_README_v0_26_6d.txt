Sorgiva Synth v0.26.6d PATCH — Runtime Ready Log Alignment Hotfix

Base prevista:
- Sorgiva Synth v0.26.6c — Metadata / Docs / Runtime Label Alignment Hotfix

Scopo patch:
- correggere il residuo attivo in `src/main.js` dove il log finale diceva ancora `Sorgiva Synth v0.26.6 pronto`;
- riallineare package/UI/runtime/export metadata alla v0.26.6d;
- aggiungere QA report, static metrics, build manifest e patch README della v0.26.6d.

File principali modificati:
- VERSION
- VERSION.txt
- README.txt
- CHANGELOG.txt
- NOTICE.txt
- ROADMAP_PUBLIC.txt
- docs/README.txt
- docs/release-notes/INDEX.txt
- docs/release-notes/QA_v0_26_6d_runtime_ready_log_alignment_hotfix.txt
- docs/release-notes/QA_v0_26_6d_static_metrics.json
- docs/release-notes/BUILD_MANIFEST_v0_26_6d_runtime_ready_log_alignment_hotfix.json
- docs/release-notes/patch-readmes/PATCH_README_v0_26_6d.txt
- index.html
- presets/README.txt
- presets/factory/CURRENT_FACTORY_PRESETS_README.txt
- src/core/identity.js
- src/main.js
- src/state/state.js
- src/presets/presets.js
- src/arp/arpeggiator.js
- src/sequencer/step-sequencer.js
- src/midi/midi-learn.js
- src/presets/factory-presets.js
- src/presets/preset-constants.js

Scope:
- nessun cambio intenzionale a motore audio, preset sonori, UI layout, MIDI runtime, Sequencer, Arpeggiator, Randomizer, Morph o A/B Compare.
