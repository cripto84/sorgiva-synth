PATCH README — SynthX Rebuild v0.24.1a Root TXT Cleanup

Questa patch riordina i file .txt storici della root spostandoli in docs/release-notes/.

IMPORTANTE
Un semplice copia/incolla della patch sopra una cartella già esistente non può cancellare automaticamente i vecchi .txt dalla root.
Per ottenere la root pulita, usare preferibilmente il FULL bundle v0.24.1a.

Se si applica la PATCH manualmente a una copia v0.24.1:
1. Copiare i nuovi file e le nuove cartelle contenute nella patch.
2. Rimuovere dalla root i file elencati in docs/release-notes/ROOT_TXT_CLEANUP_MANIFEST_v0_24_1a.json alla chiave moved_files[from].
3. Lasciare in root README.txt, CHANGELOG.txt, VERSION, VERSION.txt.

Nessun file audio, preset, sequencer, arpeggiatore, MIDI o motore audio è modificato da questa patch.
