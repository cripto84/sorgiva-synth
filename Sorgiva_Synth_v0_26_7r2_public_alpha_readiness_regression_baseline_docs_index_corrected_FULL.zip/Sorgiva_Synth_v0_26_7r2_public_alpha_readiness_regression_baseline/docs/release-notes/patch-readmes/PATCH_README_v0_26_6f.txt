Sorgiva Synth v0.26.6f — Sine + Noise Release De-click Hotfix PATCH

Base prevista:
- Sorgiva Synth v0.26.6e — Export Filename Version Suffix Alignment Hotfix

Contenuto della patch:
- correzione release click per sine/triangle + noise in `src/audio/audio-context.js`;
- nuovo profilo `lowHarmonicNoise`;
- fade dedicato del gain noise in release;
- stop/cleanup voce basato sulla coda più lunga tra Amp release e Noise release;
- riallineamento metadata/docs/UI/runtime/export label alla v0.26.6f;
- aggiornamento export filename suffix a `v0_26_6f`;
- aggiunta QA report, static metrics e build manifest v0.26.6f.

Scope:
- hotfix audio mirata;
- nessuna nuova feature;
- nessuna modifica intenzionale ai 135 factory preset;
- nessuna modifica intenzionale a UI layout, MIDI runtime, Sequencer, Arpeggiator, Randomizer, Morph o A/B Compare.

Applicazione:
- sostituire i file inclusi nella patch sopra la v0.26.6e;
- in alternativa usare direttamente il FULL bundle v0.26.6f.
