PATCH README — SynthX Rebuild v0.25.3c Metadata Consistency Hotfix

Base richiesta:
- SynthX_Rebuild_v0_25_3b_console_debug_log_cleanup_FULL

Applicazione:
- Copiare i file della patch sopra la root della v0.25.3b, oppure eseguire `APPLY_PATCH_v0_25_3c.py` dalla root della build base.

Scopo:
- correggere metadata/testi correnti rimasti fuori posto, soprattutto la subtitle `Rebuild Performance Audit` nel topbar.

Nessuna cancellazione file richiesta.
