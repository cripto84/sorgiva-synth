Sorgiva Synth v0.26.7d — PATCH README

Patch da applicare sopra:
Sorgiva_Synth_v0_26_7c_midi_learn_import_html_attribute_cleanup_hotfix_FULL

Contenuto patch:
- Step Chords Engine Foundation per Step Sequencer.
- Controlli chord per 16 step.
- Versioni, README, NOTICE, ROADMAP, docs e release notes aggiornati.

Dopo applicazione:
- Aprire `index.html`.
- Provare Step Sequencer con chord Off, Power 5th, Major, Minor, Maj7.
- Verificare Stop/Panic e import/export pattern.
