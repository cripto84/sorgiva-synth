PATCH v0.18.7a — Factory Presets Lot 1 / Core Synth Library

Questa patch aggiorna una build v0.18.7 sana alla v0.18.7a.

Contenuto principale:
- src/presets/factory-presets.js con 100 nuovi factory preset Lot 1.
- 100 JSON standalone in presets/factory.
- metadata/versioning/documentazione aggiornati.
- nessuna modifica distruttiva ai preset legacy.

Applicazione manuale:
Sovrascrivere i file presenti nella cartella SynthX v0.18.7 con quelli contenuti nella patch, mantenendo il resto della build invariato.
