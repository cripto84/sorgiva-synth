Patch v0.22.2d — FM Range QA / Stability Check

Base prevista:
- SynthX_Rebuild_v0_22_2c_fm_amount_range_extension_FULL.zip

Applicazione:
- Sovrascrivere i file inclusi nella patch sulla base v0.22.2c.

File principali modificati:
- index.html
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- src/main.js
- src/state/state.js
- src/audio/audio-context.js
- src/presets/presets.js
- src/presets/randomizer.js
- src/presets/preset-morph.js

File aggiunti:
- FM_RANGE_QA_STABILITY_CHECK_v0_22_2d.txt
- QA_REPORT_v0_22_2d_fm_range_qa_stability_check.txt
- PATCH_README_v0_22_2d.txt

Note:
- presets/ invariata.
- factory-presets.js invariato.
- Nessuna nuova macro-funzione sonora.
- FM Amount 0..0.50 preservato.
- FM Amount su note tenute aggiorna la profondità con smoothing quando la catena FM esiste già.
