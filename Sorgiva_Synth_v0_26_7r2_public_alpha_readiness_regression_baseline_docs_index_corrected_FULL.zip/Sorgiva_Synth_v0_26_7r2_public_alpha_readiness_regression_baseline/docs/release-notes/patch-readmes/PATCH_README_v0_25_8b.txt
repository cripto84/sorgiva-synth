SynthX Rebuild v0.25.8b — PATCH README

Questa patch aggiorna una build v0.25.8a alla v0.25.8b Bells / Metallic QA / Musical Correction.

Contenuto:
- correzione musicale statica dei 12 preset Lot 5 Bells / Metallic / Digital;
- factory preset count invariato a 63;
- categoria `Bells / Metallic` mantenuta e visibile;
- aggiornamento VERSION, README, CHANGELOG, index metadata, appVersion, export filename e documentazione QA.

Non contiene:
- vecchia factory library da 290 preset;
- JSON storici sotto presets/;
- modifiche ad audio-context.js;
- modifiche a motore audio, MIDI, Mod Matrix runtime, Step Sequencer, Arpeggiator, Randomizer, Morph, A/B Compare o layout UI.

Limiti:
- test audio a orecchio reale pending;
- benchmark browser reale pending;
- test hardware MIDI reale pending.
