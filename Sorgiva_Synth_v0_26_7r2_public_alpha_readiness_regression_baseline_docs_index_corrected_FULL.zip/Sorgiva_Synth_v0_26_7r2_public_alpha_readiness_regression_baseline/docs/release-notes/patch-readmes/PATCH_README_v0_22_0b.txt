PATCH README — SynthX Rebuild v0.22.0b Pulse Width / PWM QA & Musical Polish

Base richiesta:
SynthX_Rebuild_v0_22_0a_pulse_width_pwm_audio_hotfix_FULL.zip

Applicare questa patch sopra la v0.22.0a.

Contenuto della patch:
- src/audio/audio-context.js
- src/audio/audio-dsp.js
- src/state/state.js
- src/presets/presets.js
- index.html
- README.txt
- CHANGELOG.txt
- VERSION.txt
- QA_REPORT_v0_22_0b_pulse_width_pwm_qa_musical_polish.txt
- PULSE_WIDTH_PWM_QA_MUSICAL_POLISH_v0_22_0b.txt
- docs/102_PULSE_WIDTH_PWM_QA_MUSICAL_POLISH_v0_22_0b.txt

Note:
- presets/ non è incluso perché resta invariato.
- factory preset non modificati.
- nessuna nuova funzione pesante: questa è una passata di QA/polish.
