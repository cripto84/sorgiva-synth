Sorgiva Synth v0.26.6l — PATCH README

Base richiesta:
- Sorgiva Synth v0.26.6k Mod Matrix FX Destinations Hotfix.

Scopo patch:
- correggere la metrica Mod Matrix 19 → 20 destinazioni per slot;
- riallineare metadata, README, VERSION, NOTICE, ROADMAP e release index;
- uniformare label Reverb a Room/Hall/Plate/Dark;
- correggere label runtime Preset Morph non coerente;
- preservare il routing Mod Matrix → FX globale introdotto nella v0.26.6k.

File modificati principali:
- index.html
- src/core/identity.js
- src/main.js
- src/presets/preset-morph.js
- src/presets/presets.js
- src/arp/arpeggiator.js
- src/sequencer/step-sequencer.js
- src/midi/midi-learn.js
- docs/release-notes/QA_v0_26_6k_static_metrics.json
- docs/release-notes/QA_v0_26_6l_static_metrics.json
- docs/release-notes/QA_v0_26_6l_mod_matrix_fx_alignment_hotfix.txt
- docs/release-notes/BUILD_MANIFEST_v0_26_6l_mod_matrix_fx_alignment_hotfix.json

Test manuale consigliato:
- controllare tutte le nuove destinazioni FX in Mod Matrix;
- verificare Delay Mono e Ping-Pong;
- verificare Mod FX Chorus/Ensemble/Phaser/Flanger;
- verificare Reverb Room/Hall/Plate/Dark;
- usare Panic/Stop per controllare code e feedback.
