Sorgiva Synth v0.26.6i — PATCH README

Patch base attesa:
- Sorgiva Synth v0.26.6h — Manifest / Static Metrics Alignment Hotfix

Obiettivo:
- Correggere il Preset Morph live sulle note già tenute.

File principali modificati:
- `src/presets/preset-morph.js`
- `index.html`

File metadata/documentazione aggiornati:
- `VERSION`
- `VERSION.txt`
- `README.txt`
- `ROADMAP_PUBLIC.txt`
- `CHANGELOG.txt`
- `NOTICE.txt`
- `docs/README.txt`
- `docs/release-notes/INDEX.txt`
- `presets/README.txt`
- `presets/factory/CURRENT_FACTORY_PRESETS_README.txt`
- runtime/export labels in `src/core/identity.js`, `src/state/state.js`, `src/main.js`, `src/presets/presets.js`, `src/arp/arpeggiator.js`, `src/sequencer/step-sequencer.js`, `src/midi/midi-learn.js`

Note:
- La patch non modifica `src/audio/audio-context.js`.
- La patch non modifica i dati musicali dei 135 factory preset.
- Il Morph ora usa applicazione non distruttiva dei controlli invece di `applyPresetObject()`.
