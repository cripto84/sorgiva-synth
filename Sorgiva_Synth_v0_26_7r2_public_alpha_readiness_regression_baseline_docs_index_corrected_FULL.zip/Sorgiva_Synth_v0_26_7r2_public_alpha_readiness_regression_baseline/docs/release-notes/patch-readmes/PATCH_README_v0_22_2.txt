Patch v0.22.2 — FM Light Basic Safe

Base prevista:
SynthX_Rebuild_v0_22_1a_ring_mod_qa_musical_guardrails_FULL.zip

Output:
- SynthX_Rebuild_v0_22_2_fm_light_basic_safe_FULL.zip
- SynthX_Rebuild_v0_22_2_fm_light_basic_safe_PATCH.zip

Modifiche principali:
- Nuovo blocco UI FM Light.
- Nuovi parametri: fm-enabled, fm-carrier, fm-modulator, fm-amount.
- Motore audio: modulatore interno audio-rate collegato alla frequency del carrier.
- Fallback/sanitizer preset per compatibilità legacy.
- Docs e metadata aggiornati.

Non modificato:
- presets/
- factory-presets.js
- preset browser
- A/B Compare
- Pulse/PWM engine
- Ring Mod engine
- MIDI Learn / Pitch Bend / Sustain / Channel Filter
- Master Tuning
