Sorgiva Synth v0.26.6c PATCH — Metadata / Docs / Runtime Label Alignment Hotfix

Base prevista:
- Sorgiva Synth v0.26.6b — Browser Focus / FX Recovery Hotfix

Contenuto patch:
- VERSION / VERSION.txt;
- README / CHANGELOG / NOTICE / ROADMAP_PUBLIC;
- docs index e nuovi report v0.26.6c;
- presets README e factory README;
- UI badge/footer/testi attivi;
- runtime/export metadata label.

Scope:
- nessuna nuova funzione;
- nessuna modifica intenzionale ai preset factory;
- nessuna modifica intenzionale al comportamento audio già corretto dalla v0.26.6b;
- nessuna modifica intenzionale a MIDI, Sequencer, Arpeggiator, Randomizer, Morph o A/B Compare.

Test consigliato dopo patch:
- aprire index.html in browser;
- verificare che UI/version/export indichino v0.26.6c;
- ripetere il test focus/FX della v0.26.6b con reverb/delay/modulation attivi.
