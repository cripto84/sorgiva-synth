Sorgiva Synth v0.26.6h — PATCH README

Base richiesta: Sorgiva Synth v0.26.6g — Final QA Metadata Alignment Hotfix.

Tipo patch: metadata/package QA alignment.

Cosa cambia:
- aggiorna active runtime identity metadata alla v0.26.6h;
- corregge static metrics e build manifest distinguendo conteggio totale del pacchetto e conteggio dei file tracciati con hash;
- aggiorna VERSION/VERSION.txt, README, CHANGELOG, NOTICE, ROADMAP_PUBLIC, docs index, factory readme, UI badge/footer e export labels;
- aggiunge QA report, static metrics, build manifest e patch README v0.26.6h.

Cosa non cambia:
- nessuna modifica al DSP/audio rispetto alla v0.26.6g;
- nessuna modifica ai preset factory;
- nessuna modifica a UI layout, MIDI runtime, Sequencer, Arpeggiator, Randomizer, Morph o A/B Compare.
