Sorgiva Synth v0.26.6o — PATCH README

Patch purpose:
- Apply the Notice / Release Label Alignment Hotfix on top of v0.26.6n.
- Correct NOTICE historical label: Mod Matrix FX Destinations Hotfix = v0.26.6k.
- Align active runtime/docs/export metadata to v0.26.6o.

No DSP or preset changes.
