Sorgiva Synth v0.26.7r1 — Export Filename Version Alignment Hotfix

Patch da applicare sopra v0.26.7r.

Modifica solo i file necessari per riallineare metadata/versioni e i filename export rimasti con suffissi precedenti:
- src/presets/presets.js
- src/sequencer/step-sequencer.js
- src/midi/midi-learn.js
- src/arp/arpeggiator.js
- src/core/identity.js
- src/main.js
- src/state/state.js
- index.html
- VERSION / VERSION.txt
- README / NOTICE / ROADMAP / CHANGELOG

Applicare anche DELETE_MANIFEST_v0_26_7r1.txt per rimuovere PATCH_README_v0_26_7r.txt e DELETE_MANIFEST_v0_26_7r.txt dalla root se presenti.
