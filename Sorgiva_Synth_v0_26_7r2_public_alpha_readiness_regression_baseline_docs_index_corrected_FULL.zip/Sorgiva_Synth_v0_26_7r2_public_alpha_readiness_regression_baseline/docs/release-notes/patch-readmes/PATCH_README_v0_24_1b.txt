PATCH README — SynthX Rebuild v0.24.1b Randomizer Sound Surface Update

Applicare sopra:
SynthX_Rebuild_v0_24_1a_root_txt_cleanup_FULL

Contenuto patch:
- index.html
- src/main.js
- src/state/state.js
- src/presets/randomizer.js
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- docs/release-notes/release-notes/RANDOMIZER_SOUND_SURFACE_UPDATE_v0_24_1b.txt
- docs/release-notes/qa-reports/QA_REPORT_v0_24_1b_randomizer_sound_surface_update.txt

La patch non contiene preset factory e non modifica la cartella presets/.
