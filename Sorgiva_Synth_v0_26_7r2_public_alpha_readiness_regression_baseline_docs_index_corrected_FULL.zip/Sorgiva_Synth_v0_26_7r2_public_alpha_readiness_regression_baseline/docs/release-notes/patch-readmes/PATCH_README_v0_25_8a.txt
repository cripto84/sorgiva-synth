SynthX Rebuild v0.25.8a — PATCH README
Factory Preset Category Taxonomy Realign

Base richiesta:
- SynthX_Rebuild_v0_25_8_factory_preset_rebuild_lot5_bells_metallic_digital_FULL.zip

Scopo:
- Riallineare tutte le categorie factory alla tassonomia accessibile dal preset browser.
- Correggere il Lot 5, che usava la categoria non registrata Bells / Metallic & Digital.
- Rendere i 12 preset Lot 5 visibili sotto Bells / Metallic.
- Aggiungere una protezione nel browser per mostrare nel menu eventuali categorie factory live non ancora registrate in tassonomia.

Non cambia:
- audio-context.js.
- Motore audio.
- MIDI.
- Step Sequencer.
- Arpeggiator.
- Mod Matrix runtime.
- Randomizer.
- Morph.
- A/B Compare.
- Layout UI.
- Factory preset count: resta 63.

Applicazione:
- Copiare il contenuto della PATCH sopra la build v0.25.8.
- Il risultato deve corrispondere al FULL v0.25.8a.
