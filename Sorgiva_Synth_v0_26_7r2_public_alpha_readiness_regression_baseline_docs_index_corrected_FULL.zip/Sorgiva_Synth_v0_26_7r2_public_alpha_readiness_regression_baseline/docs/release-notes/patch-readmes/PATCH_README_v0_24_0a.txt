SynthX Rebuild v0.24.0a — UI Polish QA / Regression Hardening PATCH

Base richiesta:
- SynthX_Rebuild_v0_24_0_global_ui_polish_layout_clarity_FULL.zip

Contenuto patch:
- index.html
- src/main.js
- src/state/state.js
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- QA_REPORT_v0_24_0a_ui_polish_qa_regression_hardening.txt
- UI_POLISH_QA_REGRESSION_HARDENING_v0_24_0a.txt
- PATCH_README_v0_24_0a.txt

Nota:
La patch aggiorna metadata, micro-testi di build e documentazione. Non modifica audio engine, factory preset, preset folder, sequencer logic, arp logic, MIDI core, Mod Matrix, Randomizer o Morph.
