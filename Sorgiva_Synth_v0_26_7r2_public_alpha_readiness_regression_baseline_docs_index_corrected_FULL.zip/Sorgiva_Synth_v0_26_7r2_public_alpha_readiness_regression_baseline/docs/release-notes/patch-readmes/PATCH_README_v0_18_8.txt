SynthX Rebuild v0.18.8 — PATCH README

Questa patch aggiorna v0.18.7c a v0.18.8 Factory Presets QA / Musical Balance.

Contenuto principale:
- tag factory preset;
- metadata/taxonomy espliciti sui legacy;
- master-tuning-a4 = 440 esplicito sui legacy;
- reviewFlags, qaStatus e balanceNotes;
- micro-normalizzazione prudente di pochi valori hot;
- aggiornamento browser ricerca/tag;
- documentazione e QA report.

La patch non aggiunge nuovi preset, non elimina preset e non modifica il motore audio.
