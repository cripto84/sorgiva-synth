Sorgiva Synth v0.26.7d1 — PATCH README

Patch target:
- v0.26.7d Step Chords Engine Foundation

Patch scope:
- Step Chords preset defaults alignment hotfix.

Changed:
- src/presets/presets.js
- active metadata/version files
- release note / QA documents

Not changed intentionally:
- factory preset sound data
- audio engine
- structural UI layout
