SynthX Rebuild v0.22.2a — FM Light Audible Hotfix PATCH

Base richiesta:
- SynthX_Rebuild_v0_22_2_fm_light_basic_safe_FULL.zip

Scopo patch:
- rendere la FM Light chiaramente udibile;
- correggere lo scaling interno troppo timido della v0.22.2;
- aggiornare versioning e documentazione.

File principali modificati:
- index.html
- src/audio/audio-context.js
- src/main.js
- src/state/state.js
- src/presets/presets.js
- src/presets/randomizer.js
- src/presets/preset-morph.js
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- FM_LIGHT_AUDIBLE_HOTFIX_v0_22_2a.txt
- QA_REPORT_v0_22_2a_fm_light_audible_hotfix.txt

Non modifica:
- presets/
- src/presets/factory-presets.js
