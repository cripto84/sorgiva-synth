Patch v0.23.3d — Audio Release / De-click Regression QA

File modificati principali:
- index.html
- src/main.js
- src/state/state.js
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt

File aggiunti:
- AUDIO_RELEASE_DECLICK_REGRESSION_QA_v0_23_3d.txt
- QA_REPORT_v0_23_3d_audio_release_declick_regression_qa.txt
- PATCH_README_v0_23_3d.txt

Note:
- Nessuna modifica intenzionale al motore audio rispetto a v0.23.3c.
- `presets/` invariata.
- `src/presets/factory-presets.js` invariato.
- Build di consolidamento dopo conferma utente della risoluzione del click al rilascio della sinusoide.
