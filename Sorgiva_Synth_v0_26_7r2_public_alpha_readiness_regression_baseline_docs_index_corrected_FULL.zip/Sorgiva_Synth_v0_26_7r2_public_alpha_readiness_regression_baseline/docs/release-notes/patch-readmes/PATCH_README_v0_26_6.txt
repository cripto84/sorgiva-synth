Sorgiva Synth v0.26.6 — PATCH README

Base richiesta:
- Sorgiva Synth v0.26.5e — Docs / Roadmap / Metadata Alignment Hotfix

Risultato atteso:
- Sorgiva Synth v0.26.6 — Manual Browser Regression / Public Alpha Release Prep

Scopo patch:
- Aggiorna versioni/metadati/export label alla v0.26.6.
- Aggiunge checklist manuale browser/audio/MIDI.
- Aggiunge QA report statico e build manifest.
- Aggiorna README, ROADMAP_PUBLIC, NOTICE, CHANGELOG, docs index e release notes index.

Non modifica intenzionalmente:
- motore audio;
- preset sonori;
- UI operativa/layout;
- MIDI runtime;
- Step Sequencer runtime;
- Arpeggiator runtime;
- Mod Matrix;
- Randomizer;
- Morph;
- A/B Compare.

Applicazione:
- Copiare il contenuto della PATCH sopra la root della v0.26.5e.
- Sovrascrivere i file esistenti quando richiesto.
- Dopo l'applicazione, il contenuto deve corrispondere al FULL bundle v0.26.6.
