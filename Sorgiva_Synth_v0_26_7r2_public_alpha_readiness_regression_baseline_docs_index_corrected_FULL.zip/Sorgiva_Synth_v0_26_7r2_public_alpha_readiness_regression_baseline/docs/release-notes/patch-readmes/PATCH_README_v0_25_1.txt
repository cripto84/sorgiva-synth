PATCH README — SynthX Rebuild v0.25.1 Voice Management Hardening

Applicare sopra:
- SynthX_Rebuild_v0_25_0_audio_engine_performance_audit_FULL

Contenuto patch:
- README/CHANGELOG/VERSION aggiornati;
- index.html aggiornato solo per identificazione versione/testi minimi;
- hardening mirato in audio-context.js;
- percorsi Panic aggiornati in keyboard, MIDI, sequencer e arpeggiatore;
- documentazione tecnica e QA v0.25.1.

Non incluso nella patch:
- cartella presets/;
- factory preset modificati;
- nuove funzioni sonore;
- refactor pesante.

Dopo applicazione:
- eseguire node --check su tutti i JS;
- verificare JSON;
- controllare conteggio factory preset 290;
- provare manualmente panic, sustain, arp latch, sequencer tie/hold e polyphony bassa.
