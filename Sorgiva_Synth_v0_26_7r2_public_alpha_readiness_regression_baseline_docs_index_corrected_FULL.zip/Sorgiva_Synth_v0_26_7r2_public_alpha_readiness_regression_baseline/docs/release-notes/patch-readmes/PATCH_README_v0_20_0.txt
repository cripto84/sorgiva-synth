SynthX Rebuild v0.20.0 — MIDI Performance Polish PATCH

Applicare sopra v0.19.2a — Advanced Filter Mod Matrix Depth Hotfix.

Contenuto patch:
- index.html
- src/audio/audio-context.js
- src/midi/midi.js
- src/midi/midi-learn.js
- src/presets/presets.js
- src/state/state.js
- README.txt
- CHANGELOG.txt
- VERSION.txt
- docs/93_MIDI_PERFORMANCE_POLISH_v0_20_0.txt
- QA_REPORT_v0_20_0_midi_performance_polish.txt

Nota: test hardware MIDI reale pending.
