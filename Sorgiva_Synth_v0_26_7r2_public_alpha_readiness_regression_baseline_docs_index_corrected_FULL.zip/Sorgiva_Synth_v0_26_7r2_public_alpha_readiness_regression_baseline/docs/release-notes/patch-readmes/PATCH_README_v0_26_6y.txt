Sorgiva Synth v0.26.6y — PATCH README

Base richiesta: Sorgiva Synth v0.26.6x — Unison 12 Range Hotfix

Scopo patch:
- Allineare il Randomizer al nuovo range Unison 1–12.
- Correggere metadata attivi rimasti descrittivi della build precedente.
- Aggiornare filename export, README, NOTICE, ROADMAP e release notes alla v0.26.6y.

Note:
- I factory preset non vengono modificati musicalmente.
- I default restano prudenti: Unison Off, Voices 2, CPU Layer Limit 3.
- Il Randomizer può raggiungere Unison 12 negli scope Osc/All con amount alto, ma gli scope parziali restano protetti.
- Test audio reale in browser richiesto per Unison 8..12 con polifonia alta.
