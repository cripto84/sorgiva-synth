SynthX Rebuild v0.21.0b — Preset Browser Safe Polish PATCH

Base richiesta:
SynthX Rebuild v0.20.2b — Aftertouch / Expression Safe Rebuild

Contenuto patch:
- index.html
- src/state/state.js
- src/main.js
- src/presets/presets.js
- src/midi/midi-learn.js
- README.txt
- CHANGELOG.txt
- VERSION.txt
- docs/97_PRESET_BROWSER_SAFE_POLISH_v0_21_0b.txt
- QA_REPORT_v0_21_0b_preset_browser_safe_polish.txt
- PATCH_README_v0_21_0b.txt

Note:
- Non usare la vecchia v0.21.0 sospetta come base.
- Questa patch parte dalla v0.20.2b stabile.
- La cartella presets/ non viene modificata.
- Il motore audio non viene modificato.
- Le nuove funzioni sono UI/browser safe: preferiti prima, doppio click load, pruning riferimenti preferiti obsoleti.
