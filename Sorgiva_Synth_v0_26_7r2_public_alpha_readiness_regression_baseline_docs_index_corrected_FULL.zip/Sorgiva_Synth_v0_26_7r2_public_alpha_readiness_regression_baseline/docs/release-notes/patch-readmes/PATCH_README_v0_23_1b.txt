SynthX Rebuild v0.23.1b — PATCH README

Patch: Arpeggiator Timing / Swing Safe
Base richiesta: v0.23.1a — Arpeggiator QA / Musical Hardening

File modificati/inclusi nella patch:
- index.html
- src/arp/arpeggiator.js
- src/ui/controls.js
- src/state/state.js
- src/presets/presets.js
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- ARPEGGIATOR_TIMING_SWING_SAFE_v0_23_1b.txt
- QA_REPORT_v0_23_1b_arpeggiator_timing_swing_safe.txt
- PATCH_README_v0_23_1b.txt

Funzione aggiunta:
- `Arp Swing`, range 0–40%, default 0%, locale solo all'arpeggiatore.

Garanzie di compatibilità:
- presets/ invariata.
- src/presets/factory-presets.js invariato.
- Swing 0% mantiene timing identico alla v0.23.1a.
- Step Sequencer e Tie/Hold sequencer non toccati.

Test pending:
- Audio a orecchio.
- Hardware MIDI reale.
- MIDI Clock esterno reale.
