SynthX Rebuild v0.23.1a — PATCH README

Patch sopra:
SynthX_Rebuild_v0_23_1_arpeggiator_expansion_basic_FULL.zip

Output:
SynthX_Rebuild_v0_23_1a_arpeggiator_qa_musical_hardening_PATCH.zip

File modificati/aggiunti nella patch:

- VERSION
- README.txt
- CHANGELOG.txt
- index.html
- src/state/state.js
- src/arp/arpeggiator.js
- ARPEGGIATOR_QA_MUSICAL_HARDENING_v0_23_1a.txt
- QA_REPORT_v0_23_1a_arpeggiator_qa_musical_hardening.txt
- PATCH_README_v0_23_1a.txt

Note:
- `presets/` non inclusa nella patch perché invariata.
- `src/presets/factory-presets.js` non incluso nella patch perché invariato.
- Patch conservativa: corregge ordine ottave e rescheduling arp, senza refactor pesante.
