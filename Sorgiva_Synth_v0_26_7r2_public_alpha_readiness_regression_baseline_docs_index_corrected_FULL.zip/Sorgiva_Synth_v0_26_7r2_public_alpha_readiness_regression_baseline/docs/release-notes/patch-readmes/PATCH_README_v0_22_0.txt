SynthX Rebuild v0.22.0 — Pulse Width / PWM Basic Safe — PATCH

Base richiesta:
SynthX_Rebuild_v0_21_3a_preset_morph_qa_smoothing_FULL.zip

Applicare la PATCH sopra la v0.21.3a sana. Non usare le vecchie build sospette v0.20.2, v0.20.3, v0.21.0 o v0.21.0a.

File modificati dalla patch:
- index.html
- README.txt
- CHANGELOG.txt
- VERSION.txt
- src/audio/audio-config.js
- src/audio/audio-context.js
- src/audio/audio-dsp.js
- src/main.js
- src/presets/presets.js
- src/state/state.js
- src/ui/controls.js

File nuovi:
- QA_REPORT_v0_22_0_pulse_width_pwm_basic_safe.txt
- PULSE_WIDTH_PWM_BASIC_SAFE_v0_22_0.txt
- PATCH_README_v0_22_0.txt

Cartella presets/:
- invariata rispetto alla v0.21.3a.

Nota:
Questa patch è volutamente piccola. Aggiunge PW/PWM base senza Ring Mod, FM, Osc Sync, Unison/Detune o refactor pesante.
