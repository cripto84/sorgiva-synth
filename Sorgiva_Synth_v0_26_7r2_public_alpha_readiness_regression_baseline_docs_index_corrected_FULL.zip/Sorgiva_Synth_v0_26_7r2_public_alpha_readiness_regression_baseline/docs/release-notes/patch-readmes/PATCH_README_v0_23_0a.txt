SynthX Rebuild v0.23.0a — PATCH README
=======================================

Patch: Step Sequencer QA / Musical Hardening
Base consigliata: v0.23.0 — Step Sequencer Expansion Basic

File modificati principali:
- index.html
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- src/state/state.js
- src/main.js
- src/presets/presets.js
- src/presets/preset-morph.js
- src/presets/randomizer.js
- src/sequencer/step-sequencer.js
- styles/main.css
- QA_REPORT_v0_23_0a_step_sequencer_qa_musical_hardening.txt
- STEP_SEQUENCER_QA_MUSICAL_HARDENING_v0_23_0a.txt

Cosa corregge/consolida:
- Fallback esplicito dei nuovi campi velocity/gate/accent durante il caricamento di preset legacy.
- Normalizzazione più tollerante del Gate per step.
- Metadata aggiornati a v0.23.0a.
- Documentazione QA aggiornata.

Cosa non fa:
- Non aggiunge Tie/Hold.
- Non aggiunge Slide.
- Non aggiunge modulazione filtro per step.
- Non modifica factory preset.
- Non modifica la cartella presets.
- Non altera MIDI, LFO, Delay Sync, MIDI Clock, Master Tuning o famiglia oscillatori.

Uso consigliato:
Applicare sopra v0.23.0. Per evitare confusione, è comunque consigliato usare direttamente il FULL bundle v0.23.0a.
