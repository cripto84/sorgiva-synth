Patch README — SynthX Rebuild v0.22.0c
Pulse Width / PWM LFO Rate Audio Hotfix

Applicare sopra: v0.22.0b — Pulse Width / PWM QA & Musical Polish.

File principali modificati:
- index.html
- src/audio/audio-context.js
- src/main.js
- src/state/state.js
- README.txt
- CHANGELOG.txt
- VERSION.txt
- QA_REPORT_v0_22_0c_pulse_width_pwm_lfo_rate_audio_hotfix.txt
- PULSE_WIDTH_PWM_LFO_RATE_AUDIO_HOTFIX_v0_22_0c.txt
- docs/103_PULSE_WIDTH_PWM_LFO_RATE_AUDIO_HOTFIX_v0_22_0c.txt

Contenuto:
- Il PWM non usa più setInterval a 30 Hz.
- La velocità PWM segue il rate LFO tramite OscillatorNode audio-rate.
- LFO Rate/Rate Mode/Sync aggiornano le voci attive.
- presets/ e factory preset invariati.
