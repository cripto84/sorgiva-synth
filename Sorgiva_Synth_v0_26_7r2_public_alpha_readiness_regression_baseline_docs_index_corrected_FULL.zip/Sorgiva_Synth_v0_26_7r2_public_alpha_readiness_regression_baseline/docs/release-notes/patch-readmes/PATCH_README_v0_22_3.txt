SynthX Rebuild v0.22.3 — Osc Sync Feasibility / Basic Safe PATCH

Base richiesta:
- SynthX_Rebuild_v0_22_2d_fm_range_qa_stability_check_FULL.zip

Applicazione:
- Copiare i file della PATCH sopra una copia pulita della v0.22.2d.
- Non cancellare la cartella presets/.
- Non sostituire factory-presets.js con versioni più vecchie.

Contenuto della patch:
- VERSION / VERSION.txt aggiornati.
- index.html aggiornato con blocco UI Osc Sync.
- src/audio/audio-config.js aggiornato con default e lista parametri Osc Sync.
- src/audio/audio-context.js aggiornato con Osc Sync WebAudio-safe per-voce.
- src/ui/controls.js aggiornato con formatter/default UI.
- src/presets/presets.js aggiornato con sanitizer/fallback preset.
- src/presets/randomizer.js aggiornato con guardrail Osc Sync.
- src/presets/preset-morph.js aggiornato con oscsync-amount tra i parametri continui sicuri.
- src/state/state.js e src/main.js aggiornati nei metadata.
- README, CHANGELOG, QA report e documento tecnico v0.22.3.

Note:
- Osc Sync è Off di default.
- Off = comportamento legacy v0.22.2d.
- Implementazione WebAudio-safe, non hard sync analogico perfetto.
- presets/ e factory-presets.js non sono inclusi nella patch perché invariati.
