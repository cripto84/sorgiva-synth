Sorgiva Synth v0.26.6g — PATCH README

Base richiesta: Sorgiva Synth v0.26.6f — Sine + Noise Release De-click Hotfix.

Tipo patch: metadata-only final QA alignment.

Cosa cambia:
- aggiorna active runtime identity metadata;
- aggiorna VERSION/VERSION.txt, README, CHANGELOG, NOTICE, ROADMAP_PUBLIC, docs index, factory readme, UI badge/footer e export labels;
- aggiunge QA report, static metrics e build manifest v0.26.6g.

Cosa non cambia:
- nessuna modifica al DSP/audio rispetto alla v0.26.6f;
- nessuna modifica ai preset factory;
- nessuna modifica a UI layout, MIDI runtime, Sequencer, Arpeggiator, Randomizer, Morph o A/B Compare.
