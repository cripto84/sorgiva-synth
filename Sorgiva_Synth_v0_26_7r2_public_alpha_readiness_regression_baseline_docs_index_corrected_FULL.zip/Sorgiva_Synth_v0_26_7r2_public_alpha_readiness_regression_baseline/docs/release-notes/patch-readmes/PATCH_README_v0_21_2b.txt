PATCH v0.21.2b — Controlled Randomizer Safe

Base richiesta:
- SynthX_Rebuild_v0_21_1_ab_compare_safe_FULL

Contenuto patch:
- index.html
- src/main.js
- src/state/state.js
- src/midi/midi-learn.js
- src/presets/preset-constants.js
- src/presets/presets.js
- src/presets/randomizer.js
- README.txt
- CHANGELOG.txt
- VERSION.txt
- QA_REPORT_v0_21_2b_controlled_randomizer_safe.txt
- RANDOMIZER_SAFE_REBUILD_v0_21_2b.txt
- PATCH_README_v0_21_2b.txt

Nota:
- La patch non contiene la cartella presets/ perché i factory preset non sono stati modificati.
