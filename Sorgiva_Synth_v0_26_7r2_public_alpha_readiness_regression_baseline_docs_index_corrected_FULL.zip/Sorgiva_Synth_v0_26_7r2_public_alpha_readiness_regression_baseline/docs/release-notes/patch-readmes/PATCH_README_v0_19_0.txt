SynthX Rebuild v0.19.0 — Modulation Matrix Basic PATCH

Base attesa:
SynthX_Rebuild_v0_18_8_factory_presets_musical_balance_FULL

Questa patch aggiunge la Modulation Matrix Basic a 4 slot e aggiorna codice, UI, documentazione e QA report.

File principali inclusi nella patch:
- VERSION.txt
- README.txt
- CHANGELOG.txt
- index.html
- styles/main.css
- src/main.js
- src/state/state.js
- src/audio/audio-config.js
- src/audio/audio-context.js
- src/ui/controls.js
- src/presets/presets.js
- src/midi/midi-learn.js
- src/modulation/modulation-matrix.js
- docs/89_MODULATION_MATRIX_BASIC_v0_19_0.txt
- QA_REPORT_v0_19_0_modulation_matrix_basic.txt

Nota:
I factory preset non vengono modificati musicalmente. I preset legacy senza matrix caricano tutti gli slot disattivati.
