SynthX Rebuild v0.21.1 — A/B Compare Safe PATCH

Applicare questa patch sopra:
- SynthX_Rebuild_v0_21_0b_preset_browser_safe_polish_FULL

Contenuto patch:
- index.html
- styles/main.css
- src/main.js
- src/state/state.js
- src/presets/presets.js
- README.txt
- CHANGELOG.txt
- VERSION.txt
- QA_REPORT_v0_21_1_ab_compare_safe.txt
- AB_COMPARE_SAFE_REBUILD_v0_21_1.txt
- PATCH_README_v0_21_1.txt

Nota:
La patch non contiene la cartella presets/ perché non è stata modificata.
