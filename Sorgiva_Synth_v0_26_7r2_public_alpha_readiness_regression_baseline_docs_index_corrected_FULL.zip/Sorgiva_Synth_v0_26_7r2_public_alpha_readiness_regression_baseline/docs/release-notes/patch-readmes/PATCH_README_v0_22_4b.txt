SynthX Rebuild v0.22.4b — PATCH README

Patch sopra:
SynthX_Rebuild_v0_22_4a_unison_layer_limit_configurable_FULL.zip

Produce:
SynthX_Rebuild_v0_22_4b_unison_detune_qa_cpu_musical_hardening_FULL.zip

Contenuto patch:
- aggiornamento UI Unison / Detune con Effective Layers e Detune Zone;
- smoothing live per Detune/Spread quando i layer effettivi non cambiano;
- metadata/versioning v0.22.4b;
- README, CHANGELOG, QA report e documento tecnico aggiornati.

Non incluso/modificato:
- nessun nuovo factory preset;
- `presets/` invariata;
- `factory-presets.js` invariato;
- nessun refactor pesante;
- nessun AudioWorklet.

Note:
Dopo applicazione, fare test audio a orecchio nel browser e test CPU reale sopra 3 layer.
