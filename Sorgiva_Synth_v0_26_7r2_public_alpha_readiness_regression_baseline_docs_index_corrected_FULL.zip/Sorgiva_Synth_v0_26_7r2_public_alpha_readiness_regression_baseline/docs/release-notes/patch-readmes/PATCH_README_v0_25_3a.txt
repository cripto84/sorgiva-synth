PATCH README — SynthX Rebuild v0.25.3a Historical Preset JSON Cleanup

Base richiesta:
SynthX_Rebuild_v0_25_3_factory_preset_library_reset_lot0_FULL

Questa patch:
- elimina 341 vecchi JSON standalone sotto `presets/`;
- aggiorna README, CHANGELOG, VERSION, VERSION.txt, index, appVersion e documentazione;
- non modifica il motore audio;
- non modifica Step Sequencer, Arpeggiator, MIDI, Mod Matrix, Randomizer, Morph o A/B Compare;
- lascia invariata la factory library attiva minima da 1 preset.

Nota importante sulle cancellazioni:
La patch include `docs/DELETE_MANIFEST_v0_25_3a_historical_preset_json_cleanup.txt` con l'elenco dei file da eliminare. Applicare la patch significa anche cancellare i percorsi elencati nel manifest, non solo sovrascrivere i file aggiornati.

Output atteso dopo applicazione:
- JSON sotto `presets/`: 0;
- factory preset attivi: 1;
- preset attivo: `Default Init`.
