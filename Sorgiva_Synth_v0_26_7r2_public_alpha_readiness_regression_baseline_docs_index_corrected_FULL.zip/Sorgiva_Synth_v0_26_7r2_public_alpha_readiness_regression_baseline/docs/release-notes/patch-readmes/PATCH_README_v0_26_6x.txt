Sorgiva Synth v0.26.6x — PATCH

Base attesa:
- Sorgiva_Synth_v0_26_6w_docs_readme_label_alignment_hotfix_FULL.zip

Patch:
- Sorgiva_Synth_v0_26_6x_unison_12_range_hotfix_PATCH.zip

Cosa cambia:
- Unison Voices massimo 12.
- CPU Layer Limit massimo 12.
- Allineati UI, motore audio, status UI, preset sanitizer/import, randomizer guardrail, metadata e documentazione attiva.
- Default invariati: Unison Off, Voices 2, CPU Layer Limit 3.
- Factory preset invariati.

Test consigliato:
- Impostare Unison ON, Voices 12, CPU Layer Limit 12, Detune 5..10 ct, Spread 45..75%.
- Provare note singole, accordi brevi e accordi con release lunga.
- Verificare che Effective Layers mostri 12 / CPU limit 12.
- Verificare export Factory JSON e MIDI Learn mappings con suffisso `v0_26_6x`.
