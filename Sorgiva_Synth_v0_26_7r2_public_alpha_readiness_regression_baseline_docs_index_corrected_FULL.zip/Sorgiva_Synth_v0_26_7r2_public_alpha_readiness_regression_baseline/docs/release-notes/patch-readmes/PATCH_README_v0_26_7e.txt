Sorgiva Synth v0.26.7e — PATCH README

Patch da applicare sopra:
- v0.26.7d3 Release Notes Base Version Alignment Hotfix.

Contenuto patch:
- Step Chords UI badge;
- sequencer Chord status pill;
- pattern export/persistence 1.1;
- release notes e metadata attivi v0.26.7e.

Non include modifiche ai factory preset sonori.
