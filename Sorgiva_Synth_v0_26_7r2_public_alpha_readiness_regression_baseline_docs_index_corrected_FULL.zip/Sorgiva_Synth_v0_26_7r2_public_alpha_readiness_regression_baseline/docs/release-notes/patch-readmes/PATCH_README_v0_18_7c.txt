PATCH v0.18.7c — Factory Presets Lot 3 / Cinematic Experimental Library

Applica questa patch sopra v0.18.7b.
Contiene:
- dati runtime factory aggiornati con 70 preset Lot 3;
- JSON standalone dei 70 nuovi preset;
- README, CHANGELOG, VERSION, QA report;
- documentazione step 87;
- metadata index/main/state aggiornati.

Non modifica intenzionalmente il motore audio, il layout o i controlli UI.
