Sorgiva Synth v0.26.6e — Export Filename Version Suffix Alignment Hotfix PATCH

Base prevista:
- Sorgiva Synth v0.26.6d — Runtime Ready Log Alignment Hotfix

Contenuto della patch:
- correzione suffisso filename export factory preset da `v0_26_6` a `v0_26_6e`;
- correzione suffisso filename export MIDI Learn mappings da `v0_26_6` a `v0_26_6e`;
- riallineamento metadata/docs/UI/runtime label alla v0.26.6e;
- aggiunta QA report, static metrics e build manifest v0.26.6e.

Scope:
- nessuna nuova feature;
- nessuna modifica intenzionale a motore audio;
- nessuna modifica intenzionale ai 135 factory preset;
- nessuna modifica intenzionale a UI layout, MIDI runtime, Sequencer, Arpeggiator, Randomizer, Morph o A/B Compare.

Applicazione:
- sostituire i file inclusi nella patch sopra la v0.26.6d;
- in alternativa usare direttamente il FULL bundle v0.26.6e.
