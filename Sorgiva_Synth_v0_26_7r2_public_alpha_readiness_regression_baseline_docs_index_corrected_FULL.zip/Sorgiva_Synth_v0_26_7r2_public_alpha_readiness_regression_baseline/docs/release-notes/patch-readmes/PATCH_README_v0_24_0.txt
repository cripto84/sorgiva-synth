PATCH README — SynthX Rebuild v0.24.0 Global UI Polish / Layout Clarity

Patch conservativa da applicare sopra:
SynthX_Rebuild_v0_23_4_sequencer_arp_integration_polish_FULL

Contenuto patch:
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- index.html
- styles/main.css
- src/main.js
- src/state/state.js
- QA_REPORT_v0_24_0_global_ui_polish_layout_clarity.txt
- GLOBAL_UI_POLISH_LAYOUT_CLARITY_v0_24_0.txt
- docs/120_GLOBAL_UI_POLISH_LAYOUT_CLARITY_v0_24_0.txt
- PATCH_README_v0_24_0.txt

Note:
- `presets/` non incluso perché invariato.
- `src/presets/factory-presets.js` non incluso perché invariato.
- Nessuna modifica intenzionale al motore audio o alla release/de-click logic.
- v0.24.0 è una passata UI/UX leggera, non una passata sonora.
