PATCH README — SynthX Rebuild v0.25.1a Voice / Performance Regression QA

Base richiesta:
- SynthX Rebuild v0.25.1 — Voice Management Hardening

Contenuto patch:
- README.txt aggiornato;
- CHANGELOG.txt aggiornato;
- VERSION e VERSION.txt aggiornati;
- index.html aggiornato solo per identificazione versione/testi minimi;
- src/audio/audio-context.js con micro-fix Panic fast-release;
- documentazione QA v0.25.1a;
- QA report v0.25.1a.

Modifica funzionale minima:
- panicAllNotesOff() ora usa fast: true.

Non inclusi:
- modifiche factory preset;
- modifiche presets/;
- nuove funzioni sonore;
- nuovo voice allocator;
- AudioWorklet;
- refactor pesante.
