SynthX Rebuild v0.25.4a — Bass & Acid QA / Musical Correction PATCH

Apply over v0.25.4 FULL.
This patch updates only preset data, metadata and documentation for the Bass & Acid QA correction pass.
No audio engine, MIDI, sequencer, arpeggiator, Mod Matrix runtime, Randomizer, Morph or A/B Compare files are changed.
