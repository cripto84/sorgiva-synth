Patch v0.23.3b — Sine De-click / Voice Transition Hotfix

Contenuto patch:
- src/audio/audio-context.js
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- QA_REPORT_v0_23_3b_sine_declick_voice_transition_hotfix.txt
- SINE_DECLICK_VOICE_TRANSITION_HOTFIX_v0_23_3b.txt
- PATCH_README_v0_23_3b.txt

Scopo:
Ridurre il click residuo percepibile con sinusoide pura quando si passa da una nota all'altra.

Note:
- Nessuna modifica ai 290 factory preset.
- Nessuna modifica a presets/.
- Nessuna modifica a factory-presets.js.
- I valori UI dell'ADSR non vengono cambiati.
