SynthX Rebuild v0.23.0d — PATCH README
Step Sequencer Tie/Hold QA / Anti-Stuck Notes

Base richiesta
--------------
Applicare sopra:
SynthX_Rebuild_v0_23_0c_step_sequencer_tie_hold_safe_prototype_FULL.zip

Output FULL consigliato
-----------------------
SynthX_Rebuild_v0_23_0d_step_sequencer_tie_hold_qa_anti_stuck_notes_FULL.zip

Contenuto patch
---------------
- Versioning/metadata v0.23.0d.
- `src/sequencer/step-sequencer.js` con guardrail anti-stuck per Tie/Hold.
- README / CHANGELOG / QA report / documento tecnico aggiornati.
- Nessuna modifica a factory preset o cartella `presets/`.

Note operative
--------------
Per evitare confusione, è consigliato usare direttamente il FULL bundle v0.23.0d.
