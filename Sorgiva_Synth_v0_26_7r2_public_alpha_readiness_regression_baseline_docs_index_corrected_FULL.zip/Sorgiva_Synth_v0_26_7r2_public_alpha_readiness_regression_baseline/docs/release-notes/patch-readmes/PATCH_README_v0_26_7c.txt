Sorgiva Synth v0.26.7c — PATCH README

Applicare sopra:
- Sorgiva Synth v0.26.7b — Sequencer Length UI Visibility Hotfix

Scopo:
- Correzione markup HTML dell'input nascosto `midi-learn-import-file`.
- Aggiornamento metadata/versione/documentazione attiva a v0.26.7c.

Nessuna modifica intenzionale a motore audio, factory preset sonori o sequencer runtime.
