SynthX Rebuild v0.18.7 — PATCH
Factory Presets Taxonomy / Browser Preparation

Base richiesta:
- SynthX_Rebuild_v0_18_6a_master_tuning_reference_pitch_FULL.zip

Questa patch contiene solo i file modificati o aggiunti per passare dalla v0.18.6a alla v0.18.7.

File principali modificati:
- index.html
- src/presets/preset-constants.js
- src/presets/presets.js
- src/state/state.js
- src/main.js
- src/midi/midi-learn.js
- presets/factory/CURRENT_FACTORY_PRESETS_README.txt
- README.txt
- CHANGELOG.txt
- VERSION.txt
- docs/README.txt

File aggiunti:
- docs/84_FACTORY_PRESET_TAXONOMY_BROWSER_PREP_v0_18_7.txt
- QA_REPORT_v0_18_7_factory_preset_taxonomy.txt
- PATCH_README_v0_18_7.txt

Nota:
La patch non modifica il contenuto sonoro dei factory preset. Prepara categoria canonica, mappa legacy e browser per i prossimi lotti factory.
