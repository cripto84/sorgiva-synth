Sorgiva Synth v0.26.6k — PATCH README

Base richiesta:
- Sorgiva Synth v0.26.6j Preset Morph Validation / Metadata Alignment Hotfix.

Scopo patch:
- aggiungere destinazioni FX globali alla Mod Matrix;
- evitare hard-code Delay → Reverb;
- usare un resolver per famiglia effetto e modalità attiva;
- mantenere la modulazione FX globale separata dalla matrix per-voice.

File modificati principali:
- index.html
- src/audio/audio-context.js
- src/modulation/modulation-matrix.js
- src/core/identity.js
- src/state/state.js
- src/main.js
- documentazione/release notes/metadata attivi.

Test manuale consigliato:
- controllare tutte le nuove destinazioni FX in Mod Matrix;
- verificare Delay Mono e Ping-Pong;
- verificare Mod FX Chorus/Ensemble/Phaser/Flanger;
- verificare Reverb Room/Hall/Plate/Dark;
- usare Panic/Stop per controllare code e feedback.
