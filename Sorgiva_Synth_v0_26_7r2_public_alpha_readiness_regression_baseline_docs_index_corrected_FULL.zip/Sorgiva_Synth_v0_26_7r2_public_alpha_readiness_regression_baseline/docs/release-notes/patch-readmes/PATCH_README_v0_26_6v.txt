Sorgiva Synth v0.26.6v — PATCH

Base richiesta: v0.26.6u — Export Filename Alignment Hotfix.

Contenuto:
- Allineamento README attivi in presets/ e presets/factory/.
- Metadata/versione e filename export aggiornati a v0.26.6v.
- Nessuna modifica intenzionale a motore audio, MIDI runtime o factory preset data.

Dopo patch:
- Verificare `VERSION`.
- Aprire `index.html`.
- Verificare che export Factory JSON e MIDI Learn usino `v0_26_6v`.
