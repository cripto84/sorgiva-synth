PATCH v0.22.4a — Unison Layer Limit Configurable

Applicare sopra:
- SynthX_Rebuild_v0_22_4_unison_detune_feasibility_cpu_safe_basic_FULL.zip

Contenuto patch:
- UI: nuovo controllo `CPU Layer Limit`.
- Audio engine: limite layer configurabile 1–6.
- Preset import/export: nuovo parametro `unison-max-layers` con default 3.
- Randomizer: guardrail aggiornati.
- README, CHANGELOG, VERSION e QA report aggiornati.

Note:
- Default ancora prudente: Unison Off, Voices 2, CPU Layer Limit 3.
- Valori sopra 3 sono volutamente disponibili ma da testare a orecchio e con profiler CPU.
