Patch v0.21.3 — Preset Morph Basic Safe

Base richiesta: SynthX Rebuild v0.21.2c Randomizer QA / Musical Guardrails.

File modificati:
- index.html
- src/main.js
- src/state/state.js
- src/presets/presets.js
- README.txt
- CHANGELOG.txt
- VERSION.txt

File aggiunti:
- src/presets/preset-morph.js
- PRESET_MORPH_BASIC_SAFE_v0_21_3.txt
- QA_REPORT_v0_21_3_preset_morph_basic_safe.txt

La patch non contiene modifiche alla cartella presets/ e non modifica musicalmente i factory preset.
