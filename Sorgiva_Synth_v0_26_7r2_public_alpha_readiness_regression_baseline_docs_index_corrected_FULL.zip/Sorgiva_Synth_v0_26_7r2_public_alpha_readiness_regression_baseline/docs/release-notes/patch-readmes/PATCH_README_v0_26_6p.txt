Sorgiva Synth v0.26.6p — PATCH README

Apply this patch over v0.26.6o Notice / Release Label Alignment Hotfix.

Purpose:
- Correct final QA JSON `zipIntegrity` alignment.
- Add current v0.26.6p QA, static metrics and BUILD_MANIFEST.
- Align active runtime/docs/export metadata to v0.26.6p.
- Preserve audio DSP, factory presets, Mod Matrix FX routing and LFO refresh behavior.
