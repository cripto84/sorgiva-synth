PATCH v0.22.3b — Osc Sync Neutral State / Metadata Bugfix

Base richiesta:
v0.22.3a — Osc Sync QA / Musical Hardening

Contenuto patch:
- src/audio/audio-context.js
- src/state/state.js
- src/main.js
- index.html
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- QA_REPORT_v0_22_3b_osc_sync_neutral_state_bugfix.txt
- OSC_SYNC_NEUTRAL_STATE_BUGFIX_v0_22_3b.txt
- docs/107_OSC_SYNC_NEUTRAL_STATE_BUGFIX_v0_22_3b.txt

Nota:
La patch non contiene presets/ e non contiene factory-presets.js perché sono invariati.
