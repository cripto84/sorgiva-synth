PATCH_README_v0_25_0

Patch: SynthX Rebuild v0.25.0 — Audio Engine Performance Audit
Base richiesta: SynthX Rebuild v0.24.1c — Randomizer QA / Musical Balance

Contenuto patch:
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- index.html
- docs/AUDIO_ENGINE_PERFORMANCE_AUDIT_v0_25_0.txt
- docs/CPU_RISK_MAP_v0_25_0.txt
- docs/VOICE_MANAGEMENT_HARDENING_PREP_v0_25_1.txt
- docs/PERFORMANCE_AUDIT_STATIC_METRICS_v0_25_0.json
- docs/release-notes/release-notes/AUDIO_ENGINE_PERFORMANCE_AUDIT_v0_25_0.txt
- docs/release-notes/qa-reports/QA_REPORT_v0_25_0_audio_engine_performance_audit.txt
- docs/release-notes/patch-readmes/PATCH_README_v0_25_0.txt
- docs/release-notes/INDEX.txt

Tipo intervento:
Documentazione, metadata e testi identificativi minimi. Nessun intervento sonoro.

File preservati:
- src/audio/audio-context.js invariato.
- src/audio/audio-config.js invariato.
- src/audio/audio-dsp.js invariato.
- src/presets/factory-presets.js invariato.
- presets/ invariata.

Applicazione:
Sovrascrivere i file omonimi e aggiungere i nuovi documenti nelle cartelle indicate. Non rimuovere cartelle o file non presenti nella patch.

Limiti:
Test audio a orecchio, benchmark browser reale e test hardware MIDI reale restano pending.
