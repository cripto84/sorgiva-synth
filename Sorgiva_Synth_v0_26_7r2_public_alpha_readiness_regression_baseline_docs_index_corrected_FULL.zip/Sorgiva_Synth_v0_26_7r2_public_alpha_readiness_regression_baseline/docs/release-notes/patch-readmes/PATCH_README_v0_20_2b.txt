SynthX Rebuild v0.20.2b — PATCH README

Patch: Aftertouch / Expression Safe Rebuild
Base richiesta: SynthX Rebuild v0.20.1a — Stable Baseline / Regression Audit

Contenuto della patch:
- src/audio/audio-context.js
- src/midi/midi.js
- src/midi/midi-learn.js
- src/modulation/modulation-matrix.js
- src/state/state.js
- src/presets/presets.js
- src/main.js
- index.html
- README.txt
- CHANGELOG.txt
- VERSION.txt
- QA_REPORT_v0_20_2b_aftertouch_expression_safe_rebuild.txt
- docs/95_AFTERTOUCH_EXPRESSION_SAFE_REBUILD_v0_20_2b.txt
- docs/96_REGRESSION_NOTE_v0_20_2b.txt

Applicazione consigliata:
1. Applicare solo sopra v0.20.1a stabile.
2. Non applicare sopra v0.20.2, v0.20.3, v0.21.0 o v0.21.0a.
3. Dopo applicazione, aprire index.html in un browser compatibile WebAudio/WebMIDI.
4. Verificare prima il suono base senza Mod Matrix espressiva attiva.
5. Poi testare le nuove source solo tramite slot Mod Matrix esplicitamente abilitati.

Note:
- La cartella presets/ non è inclusa nella patch perché è rimasta invariata.
- Nessun factory preset è stato modificato musicalmente.
- Il test hardware MIDI reale resta pending.
