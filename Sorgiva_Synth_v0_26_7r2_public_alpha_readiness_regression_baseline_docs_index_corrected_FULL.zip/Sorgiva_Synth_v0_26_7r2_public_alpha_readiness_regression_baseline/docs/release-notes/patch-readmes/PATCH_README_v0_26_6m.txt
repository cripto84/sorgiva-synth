Sorgiva Synth v0.26.6m PATCH

Apply this patch on top of v0.26.6l.

Changed runtime file:
- src/audio/audio-context.js

Changed metadata/docs/index files:
- VERSION
- VERSION.txt
- README.txt
- NOTICE.txt
- ROADMAP_PUBLIC.txt
- CHANGELOG.txt
- index.html
- docs/README.txt
- docs/release-notes/INDEX.txt
- docs/release-notes/QA_v0_26_6m_global_fx_mod_matrix_lfo_refresh_hotfix.txt
- docs/release-notes/QA_v0_26_6m_static_metrics.json
- docs/release-notes/BUILD_MANIFEST_v0_26_6m_global_fx_mod_matrix_lfo_refresh_hotfix.json

Factory presets are unchanged.
