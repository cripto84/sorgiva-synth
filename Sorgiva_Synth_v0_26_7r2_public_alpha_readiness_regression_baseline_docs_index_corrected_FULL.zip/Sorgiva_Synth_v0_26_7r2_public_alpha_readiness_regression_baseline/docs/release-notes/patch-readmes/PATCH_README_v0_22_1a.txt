Patch v0.22.1a — Ring Mod QA / Musical Guardrails

Applicare sopra v0.22.1 Ring Mod Basic Safe.

File principali modificati:
- index.html
- src/audio/audio-context.js
- src/main.js
- src/state/state.js
- src/presets/presets.js
- src/presets/preset-morph.js
- src/presets/randomizer.js
- README.txt
- CHANGELOG.txt
- VERSION
- QA_REPORT_v0_22_1a_ring_mod_qa_musical_guardrails.txt
- RING_MOD_QA_MUSICAL_GUARDRAILS_v0_22_1a.txt

Factory preset e presets/ non vengono modificati.
