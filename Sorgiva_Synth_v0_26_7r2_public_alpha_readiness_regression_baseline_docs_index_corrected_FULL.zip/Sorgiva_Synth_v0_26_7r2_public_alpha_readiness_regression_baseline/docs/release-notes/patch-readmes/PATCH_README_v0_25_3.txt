PATCH README — SynthX Rebuild v0.25.3 Factory Preset Library Reset / Lot 0

Base richiesta:
- SynthX_Rebuild_v0_25_2_factory_presets_category_revision_FULL

Applicazione:
- Copiare il contenuto della PATCH sopra la root della v0.25.2.
- Sovrascrivere i file esistenti quando richiesto.

File modificati:
- CHANGELOG.txt
- README.txt
- VERSION
- VERSION.txt
- index.html
- src/state/state.js
- src/presets/factory-presets.js
- docs/release-notes/INDEX.txt

File aggiunti:
- docs/FACTORY_PRESET_REBUILD_GUIDELINES_v0_25_3.txt
- docs/FACTORY_PRESET_REBUILD_ROADMAP_v0_25_3.txt
- docs/FACTORY_PRESET_LIBRARY_RESET_v0_25_3.txt
- docs/FACTORY_PRESET_LIBRARY_RESET_STATIC_METRICS_v0_25_3.json
- docs/release-notes/QA_v0_25_3_factory_preset_library_reset_lot0.txt
- docs/release-notes/qa-reports/QA_REPORT_v0_25_3_factory_preset_library_reset_lot0.txt
- docs/release-notes/release-notes/FACTORY_PRESET_LIBRARY_RESET_v0_25_3.txt
- docs/release-notes/patch-readmes/PATCH_README_v0_25_3.txt

Non toccati:
- presets/
- src/audio/audio-context.js
- audio engine
- Step Sequencer
- Arpeggiator
- MIDI
- Mod Matrix
- Randomizer
- Morph
- A/B Compare

Factory preset count dopo patch: 1.
Test reali audio/browser/MIDI: pending.
