SynthX Rebuild v0.23.2 — PATCH README

Patch da applicare sopra:
SynthX_Rebuild_v0_23_1b_arpeggiator_timing_swing_safe_FULL.zip

Output:
SynthX_Rebuild_v0_23_2_pattern_presets_basic_FULL.zip
SynthX_Rebuild_v0_23_2_pattern_presets_basic_PATCH.zip

File principali modificati:
- index.html
- src/sequencer/step-sequencer.js
- src/main.js
- src/state/state.js
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt

File aggiunti:
- PATTERN_PRESETS_BASIC_v0_23_2.txt
- QA_REPORT_v0_23_2_pattern_presets_basic.txt
- PATCH_README_v0_23_2.txt

Non modificati intenzionalmente:
- presets/
- src/presets/factory-presets.js
