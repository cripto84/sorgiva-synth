Patch v0.20.1a — Stable Baseline / Regression Audit

Applicare sopra v0.20.1 — Mod Wheel Integration.

Contenuto patch:
- metadata/versione/log aggiornati;
- README e CHANGELOG aggiornati;
- QA report v0.20.1a;
- regression audit v0.20.1 → v0.20.2;
- nessuna modifica alla cartella presets/.

Non include Aftertouch/Expression, Preset Browser Polish o altre funzioni sospette.
