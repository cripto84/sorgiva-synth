PATCH v0.25.3b — Console Debug Log Cleanup / Accessibility Minor Warnings

Base prevista:
- SynthX_Rebuild_v0_25_3a_historical_preset_json_cleanup_FULL

Applicazione:
- Copiare i file della patch sopra la v0.25.3a, oppure eseguire `APPLY_PATCH_v0_25_3b.py` dalla root della build base.

Contenuto:
- logger silenzioso di default;
- label ARIA minime;
- metadata aggiornati;
- QA report e metriche.

Non contiene:
- nuovi preset;
- modifiche al motore audio;
- modifiche a sequencer/arp/MIDI/Mod Matrix.
