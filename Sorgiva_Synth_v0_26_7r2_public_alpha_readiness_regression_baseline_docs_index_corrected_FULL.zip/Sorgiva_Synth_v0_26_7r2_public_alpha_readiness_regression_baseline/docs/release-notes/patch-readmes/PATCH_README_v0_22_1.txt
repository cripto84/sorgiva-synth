PATCH v0.22.1 — Ring Mod Basic Safe

Applicare sopra v0.22.0d Pulse/PWM Integration Polish.

File modificati principali:
- index.html
- src/audio/audio-config.js
- src/audio/audio-context.js
- src/ui/controls.js
- src/state/state.js
- src/presets/presets.js
- src/presets/randomizer.js
- src/presets/preset-morph.js
- src/main.js
- README.txt
- CHANGELOG.txt
- VERSION.txt

Nuovi documenti:
- RING_MOD_BASIC_SAFE_v0_22_1.txt
- docs/105_RING_MOD_BASIC_SAFE_v0_22_1.txt
- QA_REPORT_v0_22_1_ring_mod_basic_safe.txt
