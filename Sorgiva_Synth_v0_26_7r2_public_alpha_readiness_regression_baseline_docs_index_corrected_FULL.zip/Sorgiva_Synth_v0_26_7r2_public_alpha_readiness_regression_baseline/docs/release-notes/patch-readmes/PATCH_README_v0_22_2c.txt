Patch v0.22.2c — FM Amount Range Extension

Base richiesta:
- SynthX_Rebuild_v0_22_2b_fm_light_qa_musical_guardrails_FULL.zip

File modificati principali:
- index.html
- src/state/state.js
- src/main.js
- src/audio/audio-context.js
- src/presets/presets.js
- src/presets/randomizer.js
- src/presets/preset-morph.js
- VERSION
- VERSION.txt
- README.txt
- CHANGELOG.txt

File aggiunti:
- FM_AMOUNT_RANGE_EXTENSION_v0_22_2c.txt
- QA_REPORT_v0_22_2c_fm_amount_range_extension.txt
- PATCH_README_v0_22_2c.txt

Nota:
- presets/ invariata.
- factory-presets.js invariato.
- Default FM neutro: Off + Amount 0.
