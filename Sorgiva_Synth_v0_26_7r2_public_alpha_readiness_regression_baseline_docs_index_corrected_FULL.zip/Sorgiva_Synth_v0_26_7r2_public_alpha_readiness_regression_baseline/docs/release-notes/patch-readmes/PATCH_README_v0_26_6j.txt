Sorgiva Synth v0.26.6j — PATCH README

Patch base attesa:
- Sorgiva Synth v0.26.6i — Preset Morph Live Voice Hotfix

Obiettivo:
- Registrare la conferma manuale positiva del Preset Morph live e riallineare metadata/documentazione/runtime label alla v0.26.6j.

File principali modificati:
- metadata/version files
- README/ROADMAP/NOTICE/CHANGELOG
- docs index e QA report
- UI title/badge/footer
- runtime/export labels

Note:
- La patch non modifica `src/audio/audio-context.js`.
- La patch non modifica i dati musicali dei 135 factory preset.
- La patch preserva la correzione Morph live non distruttiva introdotta nella v0.26.6i.
