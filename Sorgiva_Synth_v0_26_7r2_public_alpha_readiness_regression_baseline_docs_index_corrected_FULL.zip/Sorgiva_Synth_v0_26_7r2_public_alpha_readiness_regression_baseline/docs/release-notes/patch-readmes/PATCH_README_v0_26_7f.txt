Sorgiva Synth v0.26.7f — PATCH README

Base richiesta: v0.26.7e — Step Chords UI / Pattern Persistence

La patch v0.26.7f applica solo la regression/safety QA hotfix Step Chords.

Contenuti principali:

- `src/sequencer/step-sequencer.js` con self-test diagnostico e release invariant guard;
- metadata/versioni/export suffix aggiornati a v0.26.7f;
- documentazione, QA report e manifest correnti;
- nessuna modifica intenzionale ai factory preset sonori o al core voice synthesis.

Dopo applicazione patch, controllare in browser reale Stop/Panic su accordi per step e roundtrip export/import pattern.
