Patch README — SynthX Rebuild v0.22.0d Pulse/PWM Integration Polish

Applicare sopra: v0.22.0c — Pulse Width / PWM LFO Rate Audio Hotfix.

Contenuto patch:
- VERSION.txt
- README.txt
- CHANGELOG.txt
- index.html
- src/main.js
- src/state/state.js
- src/presets/presets.js
- src/presets/preset-morph.js
- src/presets/randomizer.js
- QA_REPORT_v0_22_0d_pulse_pwm_integration_polish.txt
- PULSE_PWM_INTEGRATION_POLISH_v0_22_0d.txt
- docs/104_PULSE_PWM_INTEGRATION_POLISH_v0_22_0d.txt

Note:
- presets/ non inclusa perche' invariata.
- factory-presets.js non incluso perche' invariato.
- Nessuna nuova funzione audio pesante.
