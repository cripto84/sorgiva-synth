PATCH v0.18.7b — Factory Presets Lot 2 / Instrument-like Library

Questa patch aggiorna una build v0.18.7a sana alla v0.18.7b.

Contenuto principale:
- src/presets/factory-presets.js aggiornato con 80 preset instrument-like nuovi;
- 80 JSON standalone aggiunti in presets/factory;
- VERSION, README, CHANGELOG, index, state/main/presets metadata aggiornati;
- documentazione step 86 e QA report v0.18.7b.

Applicare sovrascrivendo i file corrispondenti nella build v0.18.7a.
