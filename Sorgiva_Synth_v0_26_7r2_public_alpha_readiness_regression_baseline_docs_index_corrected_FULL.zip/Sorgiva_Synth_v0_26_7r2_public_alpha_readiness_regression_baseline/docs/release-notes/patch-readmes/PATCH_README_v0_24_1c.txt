PATCH README — SynthX Rebuild v0.24.1c Randomizer QA / Musical Balance

Applicare sopra:
- SynthX_Rebuild_v0_24_1b_randomizer_sound_surface_update_FULL

Modifica principale:
- Controlled Randomizer: guardrail più scope-aware e musicalmente rispettosi delle aree non randomizzate.

File modificati/aggiunti principali:
- index.html
- src/presets/randomizer.js
- src/main.js
- src/state/state.js
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- docs/release-notes/release-notes/RANDOMIZER_QA_MUSICAL_BALANCE_v0_24_1c.txt
- docs/release-notes/qa-reports/QA_REPORT_v0_24_1c_randomizer_qa_musical_balance.txt
- docs/release-notes/patch-readmes/PATCH_README_v0_24_1c.txt

Non modificati:
- audio engine
- factory preset
- presets/
- sequencer
- arpeggiatore
- MIDI core
- Mod Matrix logic
- de-click / Gain Guard
