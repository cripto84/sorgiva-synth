SynthX Rebuild v0.23.1 — PATCH README
Arpeggiator Expansion Basic

Base richiesta
--------------
Applicare sopra:
SynthX_Rebuild_v0_23_0d_step_sequencer_tie_hold_qa_anti_stuck_notes_FULL.zip

Output FULL consigliato
-----------------------
SynthX_Rebuild_v0_23_1_arpeggiator_expansion_basic_FULL.zip

Contenuto patch
---------------
- Versioning/metadata v0.23.1.
- `src/arp/arpeggiator.js` aggiornato con As Played, Octaves fino a 4 e rilascio conservativo su Mode/Rate/Gate/Octaves.
- `index.html` aggiornato nella sezione Arpeggiatore.
- `src/ui/controls.js` aggiornato per visualizzare As Played.
- README / CHANGELOG / QA report / documento tecnico aggiornati.
- Nessuna modifica a `src/presets/factory-presets.js`.
- Nessuna modifica alla cartella `presets/`.

Note operative
--------------
Per evitare confusione, è consigliato usare direttamente il FULL bundle v0.23.1.
