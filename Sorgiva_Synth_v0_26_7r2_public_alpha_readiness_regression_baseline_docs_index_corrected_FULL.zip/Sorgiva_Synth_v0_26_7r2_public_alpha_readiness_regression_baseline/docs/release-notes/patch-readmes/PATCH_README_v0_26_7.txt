Sorgiva Synth v0.26.7 — PATCH README

Patch da applicare sopra:
Sorgiva_Synth_v0_26_6z_randomizer_version_label_alignment_hotfix_FULL

Contenuto patch:
- Step Sequencer non-binary lengths 3–16.
- UI seq-length aggiornata.
- Runtime/status/import/export/randomize sequencer allineati.
- 4 pattern preset interni Non-Binary / Polymeter.
- Metadata e documentazione attiva aggiornati a v0.26.7.

Dopo applicazione:
- Aprire index.html.
- Testare Step Sequencer con 5, 7, 11, 12, 13 step.
- Verificare Panic/Stop e export/import pattern.
