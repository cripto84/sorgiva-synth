Sorgiva Synth v0.26.6u PATCH README

Base richiesta:
- Sorgiva Synth v0.26.6t — FM Light 70 Range Hotfix

Contenuto patch:
- Allineamento export filename suffix a v0_26_6u per Factory Preset JSON.
- Allineamento export filename suffix a v0_26_6u per MIDI Learn mappings JSON.
- Metadata e documentazione attiva aggiornati a v0.26.6u.

Nessuna modifica audio intenzionale rispetto alla v0.26.6t. FM Light 70% resta preservato.
