Patch v0.23.3c — Release/Hold De-click + Gain Guard Hotfix

File modificati principali:
- src/audio/audio-context.js
- index.html
- src/state/state.js
- src/main.js
- README.txt
- CHANGELOG.txt
- VERSION

File aggiunti:
- SINE_RELEASE_HOLD_DECLICK_HOTFIX_v0_23_3c.txt
- QA_REPORT_v0_23_3c_release_hold_declick_gain_guard_hotfix.txt
- PATCH_README_v0_23_3c.txt

Note:
- `presets/` invariata.
- `src/presets/factory-presets.js` invariato.
- Hotfix mirata al click al rilascio della sinusoide.
