Sorgiva Synth v0.26.6t PATCH README

Base richiesta:
- Sorgiva Synth v0.26.6s — MIDI USB Input Autodetect Hotfix

Scopo patch:
- estendere FM Light fino al 70% in modo coerente tra UI, audio engine, preset sanitizer/import, Randomizer e metadata attivi.

File principali modificati:
- index.html
- src/audio/audio-context.js
- src/presets/presets.js
- src/presets/randomizer.js
- src/core/identity.js
- documentazione/versioning attivi

Nota:
- I factory preset non sono stati modificati.
- La curva FM 0..50% resta compatibile con la build precedente.
- La nuova zona 50..70% va testata a orecchio in browser reale, soprattutto su note alte e preset aggressivi.
