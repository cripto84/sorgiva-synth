Sorgiva Synth v0.26.7a — PATCH README

Apply this patch on top of:
Sorgiva Synth v0.26.7 — Non-Binary Sequencer Lengths

Purpose:
- Fix full preset roundtrip for non-binary Step Sequencer lengths 3–16.
- Replace stale 8/16-only `seq-length` sanitizer in `src/presets/presets.js`.

Manual smoke test:
- Set sequencer length to 5/7/11/13.
- Save/export a full preset.
- Reload it.
- Confirm the length remains unchanged.
