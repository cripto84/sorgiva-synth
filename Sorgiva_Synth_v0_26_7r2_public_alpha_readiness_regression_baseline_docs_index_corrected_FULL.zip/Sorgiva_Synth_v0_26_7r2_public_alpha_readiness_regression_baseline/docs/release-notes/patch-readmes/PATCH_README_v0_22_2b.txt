Patch v0.22.2b — FM Light QA / Musical Guardrails

Base richiesta: SynthX_Rebuild_v0_22_2a_fm_light_audible_hotfix_FULL.zip

File modificati:
- VERSION
- VERSION.txt
- README.txt
- CHANGELOG.txt
- index.html
- src/state/state.js
- src/main.js
- src/audio/audio-context.js
- src/presets/presets.js
- src/presets/randomizer.js
- src/presets/preset-morph.js

File aggiunti:
- FM_LIGHT_QA_MUSICAL_GUARDRAILS_v0_22_2b.txt
- QA_REPORT_v0_22_2b_fm_light_qa_musical_guardrails.txt
- PATCH_README_v0_22_2b.txt

Nota:
La patch non modifica presets/ né src/presets/factory-presets.js.
