PATCH v0.22.4 — Unison / Detune Feasibility / CPU-Safe Basic

Applicare sulla baseline v0.22.3b.

Contenuto principale:
- UI Unison / Detune.
- Parametri Unison in config/audio/state/preset compatibility.
- Implementazione CPU-safe massimo 3 layer.
- Documentazione e QA report v0.22.4.

Non include modifiche a presets/ o factory-presets.js.
