Patch v0.23.3a — Arpeggiator Presets QA / Import-Export Hardening

Applicare sopra:
- SynthX_Rebuild_v0_23_3_arpeggiator_presets_basic_FULL.zip

Contenuto patch:
- src/arp/arpeggiator.js
- src/audio/audio-config.js
- src/audio/audio-context.js
- README.txt
- CHANGELOG.txt
- VERSION
- QA_REPORT_v0_23_3a_arpeggiator_presets_qa_import_export_hardening.txt
- ARPEGGIATOR_PRESETS_QA_IMPORT_EXPORT_HARDENING_v0_23_3a.txt
- PATCH_README_v0_23_3a.txt

Note:
- presets/ non modificata.
- factory-presets.js non modificato.
- Include micro hardening anti-click per sinusoide pura al cambio nota.
