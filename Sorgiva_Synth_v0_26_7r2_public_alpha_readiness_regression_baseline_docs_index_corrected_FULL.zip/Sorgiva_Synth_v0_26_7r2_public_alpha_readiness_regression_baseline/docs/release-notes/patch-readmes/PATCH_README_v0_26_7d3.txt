Sorgiva Synth v0.26.7d3 — PATCH README

Apply this patch over v0.26.7d2 Export Filename Suffix Alignment Hotfix.

Changed scope:
- README/ROADMAP/manifest baseVersion alignment;
- active metadata/docs/manifest alignment to v0.26.7d3;
- export filename suffixes aligned to v0_26_7d3 to match active build metadata.

No audio engine, factory preset sound data, Step Chords runtime, UI structure or legacy compatibility change is intended.
