Sorgiva Synth v0.26.6z — PATCH README

Base richiesta: Sorgiva Synth v0.26.6y — Unison 12 Randomizer Metadata Alignment Hotfix

Scopo patch:
- Correggere il metadata interno del Randomizer rimasto abbreviato.
- Allineare `preset.randomizer.version` e `randomizerGuardrails.version` alla versione completa corrente.
- Aggiornare filename export, README, NOTICE, ROADMAP, UI labels, metadata runtime/export e release notes alla v0.26.6z.

Note:
- Nessun cambio audio intenzionale rispetto alla v0.26.6y.
- I factory preset non vengono modificati musicalmente.
- I default restano prudenti: Unison Off, Voices 2, CPU Layer Limit 3.
- Il Randomizer resta capace di raggiungere Unison 12 negli scope Osc/All con amount alto.
- Test audio reale in browser ancora richiesto per Unison 8..12 con polifonia alta.
