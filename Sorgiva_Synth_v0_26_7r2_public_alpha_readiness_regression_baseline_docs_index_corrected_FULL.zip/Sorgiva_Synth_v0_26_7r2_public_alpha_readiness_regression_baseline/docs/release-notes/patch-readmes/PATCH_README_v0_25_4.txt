PATCH README — SynthX Rebuild v0.25.4

Da applicare sopra:
SynthX_Rebuild_v0_25_3c_metadata_consistency_hotfix_FULL

Output atteso:
SynthX_Rebuild_v0_25_4_factory_preset_rebuild_lot1_core_bass_acid_FULL

Contenuto della patch:
- src/presets/factory-presets.js aggiornato con 1 Init + 12 nuovi preset Bass/Acid.
- metadata versione aggiornati.
- README/CHANGELOG/VERSION/VERSION.txt aggiornati.
- index/appVersion aggiornati.
- docs e QA report v0.25.4 aggiunti.

Non contiene:
- modifiche a audio-context.js;
- modifiche a Step Sequencer;
- modifiche ad Arpeggiator;
- modifiche a MIDI;
- modifiche a Randomizer/Morph/A-B Compare;
- JSON storici sotto presets/.
