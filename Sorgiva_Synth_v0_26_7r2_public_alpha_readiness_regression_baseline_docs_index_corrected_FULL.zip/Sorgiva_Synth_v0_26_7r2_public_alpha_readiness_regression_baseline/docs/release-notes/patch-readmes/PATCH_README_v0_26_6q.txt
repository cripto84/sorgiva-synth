Sorgiva Synth v0.26.6q — PATCH README

Apply this patch over v0.26.6p Final Alignment Hotfix.

Purpose:
- Correct one stale Mod Matrix informational UI sentence.
- Align active runtime/docs/export metadata to v0.26.6q.
- Add current v0.26.6q QA, static metrics and BUILD_MANIFEST.
- Preserve audio DSP, factory presets, Mod Matrix FX routing and LFO refresh behavior.
