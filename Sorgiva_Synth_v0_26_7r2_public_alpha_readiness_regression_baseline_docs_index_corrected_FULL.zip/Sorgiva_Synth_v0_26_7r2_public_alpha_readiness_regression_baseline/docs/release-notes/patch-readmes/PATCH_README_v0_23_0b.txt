SynthX Rebuild v0.23.0b — PATCH README

Patch: Step Sequencer Import Gate Hardening
Base prevista: v0.23.0a Step Sequencer QA / Musical Hardening

File principali modificati:

- index.html
- src/main.js
- src/presets/presets.js
- src/presets/preset-morph.js
- src/presets/randomizer.js
- src/state/state.js
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt

File/documenti aggiunti:

- STEP_SEQUENCER_IMPORT_GATE_HARDENING_v0_23_0b.txt
- QA_REPORT_v0_23_0b_step_sequencer_import_gate_hardening.txt
- PATCH_README_v0_23_0b.txt

Cambiamento tecnico principale:

- `seq-step-N-gate` nel preset loader ora normalizza anche ratio `0.25/0.5/0.75/1`, oltre al formato percentuale `25/50/75/100`.

Non inclusi:

- Nessun Tie/Hold.
- Nessun pattern randomizer avanzato.
- Nessuna pattern library.
- Nessun refactor audio.
- Nessuna modifica a factory preset o cartella presets.

Applicare sopra v0.23.0a. Per evitare confusione, è consigliato usare direttamente il FULL bundle v0.23.0b.
