Sorgiva Synth v0.26.6b — PATCH README

Base richiesta:
- Sorgiva Synth v0.26.6a — Public Alpha Text / Release Notes / Index Zero-Warning Cleanup

Risultato atteso:
- Sorgiva Synth v0.26.6b — Browser Focus / FX Recovery Hotfix

Scopo patch:
- correggere il possibile problema di perdita effetti/reverb/delay/modulazione dopo cambio finestra o ritorno focus sul synth.

File principali modificati:
- src/audio/audio-context.js
- src/core/identity.js
- src/main.js
- src/arp/arpeggiator.js
- src/midi/midi-learn.js
- src/presets/presets.js
- src/sequencer/step-sequencer.js
- src/state/state.js
- index.html
- VERSION / VERSION.txt / README / CHANGELOG / NOTICE / ROADMAP_PUBLIC
- docs release notes e factory README

Nota:
- La patch non modifica intenzionalmente i factory preset sonori.
- Dopo l'applicazione, il contenuto deve corrispondere al FULL bundle v0.26.6b.
