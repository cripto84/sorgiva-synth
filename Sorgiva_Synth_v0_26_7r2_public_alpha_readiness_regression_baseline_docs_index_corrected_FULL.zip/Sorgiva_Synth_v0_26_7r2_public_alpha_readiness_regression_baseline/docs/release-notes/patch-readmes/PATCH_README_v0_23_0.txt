SynthX Rebuild v0.23.0 — PATCH README
======================================

Patch: Step Sequencer Expansion Basic
Base attesa: SynthX_Rebuild_v0_22_5_oscillator_character_final_qa_integration_FULL.zip

Contenuto patch
---------------
Questa patch applica una prima espansione prudente dello Step Sequencer.
Aggiunge velocity, gate e accent per step con default neutri e compatibilità legacy.

File modificati principali:
- VERSION
- VERSION.txt
- index.html
- README.txt
- CHANGELOG.txt
- styles/main.css
- src/state/state.js
- src/main.js
- src/audio/audio-config.js
- src/sequencer/step-sequencer.js
- src/ui/controls.js
- src/presets/presets.js
- src/presets/randomizer.js
- src/presets/preset-morph.js

File aggiunti:
- STEP_SEQUENCER_EXPANSION_BASIC_v0_23_0.txt
- QA_REPORT_v0_23_0_step_sequencer_expansion_basic.txt
- PATCH_README_v0_23_0.txt

Preservato
----------
- presets/ invariata.
- src/presets/factory-presets.js invariato.
- Factory preset count atteso: 290.
- Nessun nuovo factory preset.
- Nessuna modifica musicale intenzionale ai factory preset.
- Pulse/PWM, Ring Mod, FM Light, Osc Sync e Unison/Detune preservati.
- A/B Compare, Controlled Randomizer, Preset Morph, Mod Matrix, MIDI Learn, Performance MIDI, Master Tuning, LFO, Delay Sync, MIDI Clock e FX non alterati intenzionalmente.

Nota Tie/Hold
-------------
Tie/Hold non è incluso nella patch v0.23.0. È rimandato a una passata successiva dedicata, perché richiede una gestione anti note-appese più specifica.

Nota
----
Applicare la patch sopra la v0.22.5. Per evitare confusione, è comunque consigliato usare direttamente il FULL bundle v0.23.0.
