Sorgiva Synth v0.26.6n — PATCH README

Patch da applicare sopra v0.26.6m Global FX Mod Matrix LFO Refresh Hotfix.

Contenuto:
- Allineamento versioni/metadata a v0.26.6n.
- Correzione suffissi filename export factory preset e MIDI Learn.
- Correzione previousBuild e README preset/factory attivi.
- Nuovi QA report e build manifest.

Nessuna modifica intenzionale a DSP audio o preset factory.
