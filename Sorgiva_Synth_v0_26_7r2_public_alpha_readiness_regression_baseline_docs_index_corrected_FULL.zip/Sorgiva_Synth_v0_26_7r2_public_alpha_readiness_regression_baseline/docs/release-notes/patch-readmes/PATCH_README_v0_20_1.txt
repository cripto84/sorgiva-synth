PATCH v0.20.1 — Mod Wheel Integration

Applicare sopra:
SynthX_Rebuild_v0_20_0a_midi_channel_filter_active_note_hotfix_FULL.zip

Contenuto patch:
- index.html
- src/audio/audio-context.js
- src/midi/midi.js
- src/midi/midi-learn.js
- src/modulation/modulation-matrix.js
- src/presets/presets.js
- src/state/state.js
- README.txt
- CHANGELOG.txt
- VERSION.txt
- DOC_Mod_Wheel_Integration_v0_20_1.txt
- QA_REPORT_v0_20_1_mod_wheel_integration.txt

Nota:
Factory preset non inclusi nella patch e non modificati musicalmente.
