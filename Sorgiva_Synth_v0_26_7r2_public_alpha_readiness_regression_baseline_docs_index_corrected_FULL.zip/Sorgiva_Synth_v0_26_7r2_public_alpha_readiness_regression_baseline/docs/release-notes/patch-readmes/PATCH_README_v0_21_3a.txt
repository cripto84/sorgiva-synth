SynthX Rebuild v0.21.3a — Preset Morph QA / Smoothing — PATCH

Questa patch va applicata sopra la v0.21.3 Preset Morph Basic Safe.

Contenuto della patch:
- index.html
- src/main.js
- src/state/state.js
- src/presets/presets.js
- src/presets/preset-morph.js
- README.txt
- CHANGELOG.txt
- VERSION.txt
- QA_REPORT_v0_21_3a_preset_morph_qa_smoothing.txt
- PRESET_MORPH_QA_SMOOTHING_v0_21_3a.txt
- PATCH_README_v0_21_3a.txt

Scopo:
Rafforzare il morph già introdotto nella v0.21.3, senza cambiare il suono dei preset e senza toccare il motore audio.

La cartella presets/ resta invariata.
