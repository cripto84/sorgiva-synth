SynthX Rebuild v0.21.2c — Randomizer QA / Musical Guardrails PATCH

Base richiesta:
- SynthX_Rebuild_v0_21_2b_controlled_randomizer_safe_FULL

Contenuto della patch:
- src/presets/randomizer.js
- src/main.js
- src/state/state.js
- src/presets/presets.js
- src/midi/midi-learn.js
- index.html
- README.txt
- CHANGELOG.txt
- VERSION.txt
- QA_REPORT_v0_21_2c_randomizer_qa_musical_guardrails.txt
- docs/98_RANDOMIZER_QA_MUSICAL_GUARDRAILS_v0_21_2c.txt
- PATCH_README_v0_21_2c.txt

La patch non contiene la cartella presets/ perché resta invariata rispetto alla v0.21.2b.
