PATCH v0.24.1 — Accessibility Polish

Applicare sopra SynthX Rebuild v0.24.0a.

File attesi nella patch:
- index.html
- styles/main.css
- src/main.js
- src/state/state.js
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- ACCESSIBILITY_POLISH_v0_24_1.txt
- QA_REPORT_v0_24_1_accessibility_polish.txt
- PATCH_README_v0_24_1.txt

La patch non contiene modifiche a:
- presets/
- src/presets/factory-presets.js
- src/audio/audio-context.js
- src/sequencer/step-sequencer.js
- src/arp/arpeggiator.js
