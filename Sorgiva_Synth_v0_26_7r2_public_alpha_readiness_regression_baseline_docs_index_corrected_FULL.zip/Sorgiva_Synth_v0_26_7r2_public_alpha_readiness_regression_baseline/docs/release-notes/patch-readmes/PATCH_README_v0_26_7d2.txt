Sorgiva Synth v0.26.7d2 — PATCH README

Apply this patch over v0.26.7d2 Export Filename Suffix Alignment Hotfix.

Changed scope:
- export filename suffix alignment for MIDI Learn mappings;
- export filename suffix alignment for factory JSON;
- active metadata/docs/manifest alignment to v0.26.7d2.

No audio engine, factory preset sound data, Step Chords runtime, UI structure or legacy compatibility change is intended.
