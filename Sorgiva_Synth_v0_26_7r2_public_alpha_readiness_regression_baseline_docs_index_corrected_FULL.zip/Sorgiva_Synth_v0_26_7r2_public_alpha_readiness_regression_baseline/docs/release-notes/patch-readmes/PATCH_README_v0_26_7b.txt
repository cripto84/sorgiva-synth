Sorgiva Synth v0.26.7b — PATCH README

Base richiesta:
- Sorgiva Synth v0.26.7a — Sequencer Preset Roundtrip Hotfix

Scope patch:
- UI visibility hotfix dello Step Sequencer per lunghezze 3–16.
- Nasconde/disabilita step oltre la lunghezza attiva.
- Sincronizza la UI sequencer dopo preset load senza avviare il transport.

File principali modificati:
- src/sequencer/step-sequencer.js
- src/presets/presets.js
- styles/main.css
- metadati/versioni/docs di build

Dopo applicazione:
- Aprire index.html.
- Provare Seq Length 5, 7, 11, 13.
- Salvare e ricaricare preset completo.
