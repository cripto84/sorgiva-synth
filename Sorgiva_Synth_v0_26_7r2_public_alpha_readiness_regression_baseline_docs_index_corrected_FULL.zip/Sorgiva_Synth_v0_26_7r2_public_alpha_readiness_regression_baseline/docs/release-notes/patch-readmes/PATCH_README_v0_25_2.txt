PATCH v0.25.2 — Factory Presets Category Revision / Musical Balance

Base richiesta:
SynthX_Rebuild_v0_25_1a_voice_performance_regression_qa_FULL

Contenuto patch:
- src/presets/factory-presets.js aggiornato con revisione v0.25.2.
- README.txt / CHANGELOG.txt / VERSION / VERSION.txt aggiornati.
- index.html aggiornato solo per etichetta/versione.
- src/state/state.js aggiornato solo per appVersion.
- Nuovi documenti di audit/revisione in docs/ e docs/release-notes/.

Non contiene:
- presets/ modificata;
- nuove funzioni sonore;
- nuovo motore audio;
- nuove categorie preset;
- modifiche a sequencer/arp;
- modifiche a MIDI;
- modifiche a voice management/de-click.

Dopo applicazione patch eseguire:
- node --check su tutti i JS;
- JSON validation;
- factory preset count;
- test browser e ascolto a orecchio.
