Sorgiva Synth v0.26.6r — PATCH README

Apply this patch over v0.26.6q UI Text Alignment Hotfix.

Purpose:
- Separate active metadata/UI text from historical release references.
- Fix duplicated v0.26.6q CHANGELOG block.
- Correct the Final Alignment Hotfix notice label to v0.26.6p.
- Align active runtime/docs/export metadata to v0.26.6r.
- Add current v0.26.6r QA, static metrics, active alignment audit and BUILD_MANIFEST.
- Preserve audio DSP, factory presets, Mod Matrix FX routing and LFO refresh behavior.
