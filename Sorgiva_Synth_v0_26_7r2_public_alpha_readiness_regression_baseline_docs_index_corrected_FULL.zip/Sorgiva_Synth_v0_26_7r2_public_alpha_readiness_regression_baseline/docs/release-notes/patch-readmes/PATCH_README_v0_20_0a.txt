PATCH v0.20.0a — MIDI Channel Filter Active Note Hotfix

Applicare sopra:
SynthX_Rebuild_v0_20_0_midi_performance_polish_FULL.zip

Contenuto patch:
- src/midi/midi.js
- src/state/state.js
- src/presets/presets.js
- index.html
- README.txt
- CHANGELOG.txt
- VERSION.txt
- QA_REPORT_v0_20_0a_midi_channel_filter_active_note_hotfix.txt

Obiettivo:
Correggere il rischio di note appese quando si cambia MIDI Channel Filter con note MIDI attive.
