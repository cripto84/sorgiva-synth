Sorgiva Synth v0.26.6w — PATCH

Base richiesta: v0.26.6v — Preset README Label Alignment Hotfix.

Contenuto:
- Allineamento di `docs/README.txt` alla versione corrente.
- Metadata/versione e filename export aggiornati a v0.26.6w.
- Nessuna modifica intenzionale al motore audio, MIDI runtime o factory preset data.

Verifica consigliata:
- Aprire `docs/README.txt` e controllare intestazione v0.26.6w.
- Verificare che export Factory JSON e MIDI Learn usino `v0_26_6w`.
- Test audio reale in browser ancora consigliato per FM 50..70%.
