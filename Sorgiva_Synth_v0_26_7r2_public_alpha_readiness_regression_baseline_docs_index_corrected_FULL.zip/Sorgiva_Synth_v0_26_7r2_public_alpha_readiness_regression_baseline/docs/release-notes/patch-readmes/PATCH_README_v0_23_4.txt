PATCH README — SynthX Rebuild v0.23.4 Sequencer / Arp Integration Polish

Patch conservativa da applicare sopra:
SynthX_Rebuild_v0_23_3d_audio_release_declick_regression_qa_FULL

Contenuto patch:
- README.txt
- CHANGELOG.txt
- VERSION
- VERSION.txt
- index.html
- styles/main.css
- src/sequencer/step-sequencer.js
- src/arp/arpeggiator.js
- QA_REPORT_v0_23_4_sequencer_arp_integration_polish.txt
- SEQUENCER_ARP_INTEGRATION_POLISH_v0_23_4.txt
- docs/119_SEQUENCER_ARP_INTEGRATION_POLISH_v0_23_4.txt
- PATCH_README_v0_23_4.txt

Note:
- `presets/` non incluso perché invariato.
- `src/presets/factory-presets.js` non incluso perché invariato.
- Nessuna modifica intenzionale al motore audio o alla release/de-click logic.
