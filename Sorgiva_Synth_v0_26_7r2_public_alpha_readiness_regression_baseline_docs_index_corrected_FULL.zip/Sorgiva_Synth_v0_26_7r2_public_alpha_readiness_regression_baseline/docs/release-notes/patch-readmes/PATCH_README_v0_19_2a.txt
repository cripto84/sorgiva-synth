SynthX Rebuild v0.19.2a — PATCH README

Patch mirata da applicare sopra v0.19.2 Mod Matrix Expansion.

File principali aggiornati:
- src/audio/audio-context.js
- src/main.js
- src/state/state.js
- src/presets/presets.js
- README.txt
- CHANGELOG.txt
- VERSION.txt
- QA_REPORT_v0_19_2a_advanced_filter_mod_matrix_depth_hotfix.txt
- docs/92_ADVANCED_FILTER_MOD_MATRIX_DEPTH_HOTFIX_v0_19_2a.txt

Nota:
La patch corregge Mod Matrix → Advanced Filter Depth. Non aggiunge nuove funzioni e non modifica i factory preset.
