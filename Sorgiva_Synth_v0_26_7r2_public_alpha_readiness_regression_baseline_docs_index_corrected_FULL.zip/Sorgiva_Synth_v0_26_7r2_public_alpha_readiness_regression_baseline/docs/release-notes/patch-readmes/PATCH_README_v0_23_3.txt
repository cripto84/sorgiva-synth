SynthX Rebuild v0.23.3 — Arpeggiator Presets Basic — PATCH README

Base richiesta
--------------
Applicare sopra:
SynthX_Rebuild_v0_23_2_pattern_presets_basic_FULL.zip

File modificati / aggiunti
--------------------------
- VERSION
- index.html
- README.txt
- CHANGELOG.txt
- ARPEGGIATOR_PRESETS_BASIC_v0_23_3.txt
- QA_REPORT_v0_23_3_arpeggiator_presets_basic.txt
- PATCH_README_v0_23_3.txt
- src/main.js
- src/arp/arpeggiator.js
- src/ui/controls.js

Cosa introduce
--------------
- 30 Arpeggiator Presets Basic.
- UI Arp Preset.
- Apply Arp Preset.
- Save User Arp.
- Export JSON.
- Import JSON.
- Clamp/sanitize su import.
- Restart conservativo dell'arp se un preset viene applicato mentre l'arp sta suonando.

Cosa NON modifica
-----------------
- presets/
- src/presets/factory-presets.js
- factory preset sonori
- Step Sequencer e Pattern Presets già presenti
- preset browser
- A/B Compare / Randomizer / Morph
- Mod Matrix
- MIDI / MIDI Clock / MIDI Learn
- Master Tuning
- Pulse/PWM, Ring Mod, FM Light, Osc Sync, Unison

Note
----
Gli Arp Presets sono preset di comportamento, non sequenze melodiche fisse. Non accendono automaticamente l'arpeggiatore e non scrivono note nel sequencer.
