SynthX Rebuild — QA v0.26.3f Metadata README / Category Count Hotfix

Base: v0.26.3e — Metadata / Version Alignment QA Hotfix
Output: v0.26.3f — Metadata README / Category Count Hotfix

Obiettivo:
Correggere due discrepanze residue trovate nel controllo della v0.26.3e:
- `presets/README.txt` era rimasto allo stato storico v0.25.3a e dichiarava ancora 1 preset factory attivo;
- il browser factory mostrava "25 categorie preparate" mentre le categorie factory attive sono 26.

Modifiche:
- Riscritto `presets/README.txt` come stato corrente della cartella presets.
- Aggiornato il count della cartella presets: 135 factory preset attivi, 26 categorie attive.
- Corretto il pill UI del browser factory a "26 categorie preparate".
- Allineati VERSION, VERSION.txt, README, CHANGELOG, ROADMAP_PUBLIC, badge/titoli/footer UI, appVersion runtime e metadata/export generator alla v0.26.3f.
- Aggiornato `presets/factory/CURRENT_FACTORY_PRESETS_README.txt` con la nota v0.26.3f.

Non modificato:
- audio engine;
- factory preset sound-design;
- sequencer;
- arpeggiatore;
- MIDI core;
- Mod Matrix;
- Randomizer;
- Morph;
- A/B Compare;
- struttura funzionale della UI.

Controlli eseguiti:
- ZIP integrity: PASS.
- node --check su tutti i JS: PASS.
- HTML duplicate IDs: 0.
- label for mancanti: 0.
- aria-controls mancanti: 0.
- tab/panel mismatch: 0.
- script/link mancanti: 0.
- document.getElementById statici mancanti: 0.
- factory presets: 135.
- factory preset ID unici: 135/135.
- categorie factory attive: 26.
- browser category option mancanti rispetto alle categorie factory: 0.
- categorie factory non usate ma presenti nel browser: 0.

Conclusione:
v0.26.3f è una micro-hotfix conservativa di pulizia metadata/README/UI-count. La build risulta staticamente coerente e pronta per il successivo pass v0.26.4 Public Alpha QA Candidate.
