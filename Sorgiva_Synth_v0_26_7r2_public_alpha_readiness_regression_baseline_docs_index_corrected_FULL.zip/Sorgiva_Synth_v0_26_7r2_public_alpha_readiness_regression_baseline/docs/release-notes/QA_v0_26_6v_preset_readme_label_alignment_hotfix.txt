Sorgiva Synth v0.26.6v — Preset README Label Alignment Hotfix QA

Scope:
- Allineamento dei README attivi in presets/ e presets/factory/ alla versione corrente.
- Metadata/versione corrente aggiornati.
- Filename export correnti aggiornati a v0_26_6v.
- Nessuna modifica intenzionale al motore audio, MIDI runtime o factory preset data.

Static QA:
- ZIP integrity: PASS
- JS syntax check: PASS
- index.html script references present: PASS
- duplicate HTML IDs: 0
- literal getElementById missing targets: 0
- Factory preset count: 135
- Factory duplicate IDs: 0
- Factory orphan categories: 0
- Factory max FM Amount: 0.24
- Factory presets over FM 0.70: 0
- Factory presets with Arp ON by default: 0
- Factory presets with Step Sequencer ON by default: 0
- UI FM Amount max 0.70: PASS
- Audio FM Amount max 0.70: PASS
- Randomizer FM Amount max 0.70: PASS
- Preset sanitizer FM Amount max 0.70: PASS
- Factory export filename suffix v0_26_6v: PASS
- MIDI Learn export filename suffix v0_26_6v: PASS
- Active presets README label alignment: PASS

Manual QA still required:
- Browser audio test.
- FM 50..70% listening test with Gain Guard active.
- Hardware MIDI test if available.
