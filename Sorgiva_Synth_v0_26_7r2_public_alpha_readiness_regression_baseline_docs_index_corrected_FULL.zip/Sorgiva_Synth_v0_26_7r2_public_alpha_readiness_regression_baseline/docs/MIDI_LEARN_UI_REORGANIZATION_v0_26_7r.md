# Sorgiva Synth v0.26.7r — MIDI Learn UI Reorganization

## Obiettivo

Rendere gestibile la copertura MIDI Learn ampliata nella v0.26.7q senza aggiungere nuovi target e senza cambiare il motore audio.

## Interventi

- Filtro per gruppo target.
- Filtro per modalità: continuous, toggle, selector, trigger.
- Ricerca testuale su ID, label, gruppo e modalità.
- Contatore target visibili rispetto ai target DOM disponibili.
- Help dinamico del target selezionato con descrizione della modalità.
- Badge modalità nella legenda e nella lista mapping.
- Lista mapping con gruppo e dettaglio modalità.
- Audit runtime con stato dei filtri UI.

## Preservato

- 229 target MIDI Learn della v0.26.7q.
- Handler continuous/toggle/selector/trigger.
- Export/import JSON separato.
- Motore audio, preset factory, sequencer pattern, randomizer, arpeggiatore, Gain Guard e Panic/Stop.

## Prossimo passo

`v0.26.7s — MIDI Hardware Regression`: test con controller MIDI reale su continuous, toggle, selector e trigger.
