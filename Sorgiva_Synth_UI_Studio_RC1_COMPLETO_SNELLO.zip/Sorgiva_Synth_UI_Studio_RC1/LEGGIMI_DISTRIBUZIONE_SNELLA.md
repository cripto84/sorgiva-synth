# Sorgiva Synth — distribuzione snella UI Studio RC1

Data: 29 ottobre 2026 — motore 0.27.0-beta1-rc1, interfaccia UI Studio RC1.

## Come usare questo pacchetto
Apri `index.html` in un browser compatibile WebAudio. Per MIDI preferisci
localhost/HTTPS, ad esempio `python3 -m http.server 8000` nella cartella.
Per il programma normale è sufficiente lo ZIP ESSENZIALE: contiene 48 file runtime.

## Come è stata alleggerita la distribuzione
Questo COMPLETO_SNELLO contiene il runtime INTEGRALE e identico byte per byte
all'ESSENZIALE, note tecniche, manuale candidato e un insieme mirato di prove QA.
NON contiene i 24 ZIP dei checkpoint, la vecchia distribuzione annidata,
le 533 evidenze QA di tutte le fasi né i manuali superati. Non sono stati
rimossi oscillatori, funzioni, preset o moduli necessari al funzionamento.

La storia resta nell'originale COMPLETO (archivio storico conservato separatamente)
e nei commit storici di GitHub. Il repository GitHub tiene invece i sorgenti
correnti, la documentazione aggiornata e il pacchetto ESSENZIALE.

## Verifiche
La nuova impacchettatura è stata controllata per integrità ZIP/CRC, parità del
runtime, sintassi JavaScript (34 file), e riferimenti statici agli asset locali.
Non sostituisce il test con browser reale, MIDI hardware o ascolto umano.
Le prove dentro QA/ derivano dal dossier RC1 originale, non da un nuovo collaudo.

Licenza software: GPL-3.0-only. Documentazione: CC BY-SA 4.0 salvo eccezioni.
L'uso della parola RC1 indica una candidata e non una certificazione definitiva.
