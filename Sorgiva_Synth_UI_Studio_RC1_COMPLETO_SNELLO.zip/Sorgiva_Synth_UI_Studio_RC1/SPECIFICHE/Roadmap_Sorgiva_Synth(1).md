# Sorgiva Synth — Piano di riprogettazione progressiva UI/UX

**Versione del piano:** 1.0 — 29 ottobre 2026  
**Baseline del software:** Sorgiva Synth `0.27.0-beta1-rc1`  
**Pacchetti di partenza:** `Sorgiva_Synth_v0_27_0_beta1rc1_ESSENZIALE.zip` e `Sorgiva_Synth_v0_27_0_beta1rc1_COMPLETO.zip`  
**Scopo:** rendere il sintetizzatore più immediato, musicale, leggibile e accessibile, senza perdere profondità di sound design e senza riscrivere il motore audio.

## Principi inderogabili

1. **Una fase alla volta.** Ogni fase si chiude con pacchetto avviabile, resoconto delle modifiche, evidenze di test e decisione *promuovere / correggere / ripristinare*.
2. **Una sola patch, un solo motore.** Le eventuali modalità Performance e Sound Design sono viste diverse dello stesso stato, non due implementazioni sonore.
3. **Compatibilità prima dell'estetica.** Non cambiare i nomi/valori dei parametri serializzati, il formato patch, gli ID HTML referenziati da JS, gli attributi rilevanti per MIDI Learn e i contratti eventi senza compatibilità esplicita e testata.
4. **Zero regressioni sonore intenzionali.** Non modificare DSP, gestione voci, governor, limiti adattivi, ordine catena FX, MIDI clock o timing del motion engine come effetto collaterale della UI.
5. **Progettazione progressiva.** Inserire i nuovi componenti con un percorso di rollback; la vecchia UI rimane una baseline verificabile sino alla release finale.
6. **Accessibilità nativa.** Mouse, tastiera, focus, screen reader dove pertinente, zoom e input touch; nessuna funzione essenziale disponibile soltanto trascinando una manopola grafica.
7. **Valutazione musicale.** Misurare non soltanto la pulizia della grafica, ma le azioni che servono per trovare un preset, suonarlo, modificare un filtro, creare una modulazione e salvarla.
8. **Documentazione sincronizzata.** Aggiornare manuale, schermate, istruzioni e mappa dei controlli solo dopo che l'implementazione della fase è stata verificata.

## Analisi iniziale — evidenze direttamente dal pacchetto

- `index.html` è il punto d'ingresso e contiene nove tab con pannelli ARIA, identificatori e controlli.
- `styles/main.css` contiene il tema, la barra superiore, le tab, i moduli e un dock tastiera fissato al bordo inferiore.
- `src/ui/tabs.js` gestisce l'attivazione dei pannelli e la navigazione via tastiera.
- `src/ui/controls.js` collega molti elementi dell'interfaccia ai valori del sintetizzatore.
- `src/keyboard/keyboard.js` controlla la tastiera su schermo.
- `src/presets/{presets.js,factory-presets.js,preset-morph.js,randomizer.js}` e `src/midi/{midi.js,midi-learn.js,midi-clock.js}` sono parti da proteggere nei test di regressione.
- Il programma contiene moduli audio, modulazione, transport, sequencer, arpeggiatore e Adaptive Performance separati dalla parte presentazionale.
- Il pacchetto completo include documentazione e risultati di test preesistenti: sono prove storiche, non attestazioni di test rieseguiti con questa roadmap.

**Attenzione:** i numeri inventariali riportati nella bozza di manuale (ad es. 643 campi patch, 229 target MIDI Learn, 135 factory preset) vanno riconteggiati e trattati come riferimenti della baseline prima di usarli come invarianti automatiche.

---

## Mappa delle 13 fasi

| Fase | Nome | Risultato verificabile | Codice audio |
|---|---|---|---|
| 0 | Baseline e contratto di compatibilità | Backup verificato, test di riferimento, mappa ID/parametri | Intatto |
| 1 | Progetto UX e wireframe | Mockup desktop, mobile e gerarchia delle due modalità approvati | Intatto |
| 2 | Fondamenta tecniche UI | Design tokens, componenti riusabili e sincronizzazione stato/test | Intatto |
| 3 | Nuovo telaio dell'interfaccia | Barra compatta, navigazione, dock riducibile, Panic sempre raggiungibile | Intatto |
| 4 | Performance e Preset Browser | Suonare/caricare/modificare al volo senza entrare nei dettagli | Intatto |
| 5 | Oscillatori, Noise e LFO | Controlli chiari, forme d'onda, feedback visivo | Intatto |
| 6 | Filtri, ADSR ed EQ | Curve visibili e lettura dello shaping timbrico | Intatto |
| 7 | Mod Matrix | Relazioni sorgente-destinazione chiare, editabili, navigabili | Intatto |
| 8 | Effetti e protezione dinamica | Catena FX e bypass leggibili, safety separata | Intatto |
| 9 | Sequencer e Arpeggiatore | Editing della griglia più efficiente e trasporto leggibile | Intatto |
| 10 | MIDI e strumenti avanzati | MIDI Learn, A/B, Morph, Randomizer, JSON, Adaptive correttamente esposti | Intatto |
| 11 | Responsive, accessibilità e performance UI | Desktop/laptop/touch verificati, test tastiera e carico grafico | Intatto |
| 12 | Collaudo generale e rilascio | Release candidata UI, due ZIP, documentazione allineata | Intatto |

## Schede operative

### Fase 0 — Baseline e compatibilità (PRIMA DI TOCCARE LA UI)

**Lavoro**
- Duplicare la build di partenza senza alterare l'archivio originale.
- Calcolare SHA-256 dei file runtime e registrare la struttura delle cartelle.
- Inventariare tutti gli `id`, i `data-*`, i nomi dei campi patch e le dipendenze JS↔DOM.
- Fotografare tutte le nove schede a larghezze desktop e mobile; misurare l'area visibile e gli overflow.
- Registrare un piccolo set di azioni utente: caricare preset, suonare, modificare VCF, creare Mod Matrix, salvare/esportare, fare MIDI Learn.
- Censire e possibilmente eseguire i test preesistenti, distinguendo risultati effettivamente ripetuti dai risultati allegati al pacchetto.
- Definire una matrice di regressione con test manuali/browser e test statici automatici, compreso rollback.

**Consegna:** `UI_AUDIT_BASELINE.md`, `UI_DOM_CONTRACT.csv`, `UI_TEST_MATRIX.md`, screenshot di riferimento e copia ZIP baseline immutata.  
**Gate:** la compatibilità è definita in modo controllabile; nessuna modifica funzionale.

### Fase 1 — Progetto UX, non implementazione

**Lavoro**
- Disegnare due viste della **stessa patch**: *Performance* (essenziale) e *Sound Design* (completa).
- Definire un unico header con preset, audio, Master, BPM, stato MIDI e Panic.
- Disegnare una tastiera comprimibile e visualizzatori facoltativi; non limitare l'accesso alle quattro ottave.
- Creare wireframe per 1440×900, laptop 1366×768, tablet e smartphone.
- Stabilire le azioni primarie e le informazioni che si possono nascondere progressivamente.
- Preparare palette, tipografia, iconografia, scala spaziature, densità e stati (attivo, bypass, modificato, focus, errore).
- Fare una revisione dell'identità visiva prima di cambiare codice.

**Consegna:** wireframe e guida di navigazione con schermate “prima/dopo”.  
**Gate:** si riesce a individuare rapidamente preset, cutoff, inviluppo, salvataggio e Panic, anche senza conoscere il manuale.

### Fase 2 — Fondamenta tecniche della nuova UI

**Lavoro**
- Estrarre tokens CSS e stili condivisi preservando il tema precedente come fallback.
- Definire primitive riusabili per pannello, manopola/slider, menu, toggle, valore numerico e stato.
- Se serve, introdurre un piccolo adattatore per leggere/scrivere gli stati senza duplicare la fonte di verità; non fare un refactor massivo dei moduli audio.
- Conservare, o mappare esplicitamente, tutti i vecchi ID/attributi su cui insistono listeners e MIDI Learn.
- Eseguire test di modifica parametro → stato → preset → restore → UI.

**Consegna:** shell di componenti e suite di sincronizzazione dati, visivamente ancora simile alla UI precedente.  
**Gate:** nessuna variazione audio o serializzazione, nessun controllo disaccoppiato.

### Fase 3 — Telaio e spazio utile

**Lavoro**
- Introdurre header compatto e navigazione gerarchica.
- Rendere dock tastiera espandibile/comprimibile con preferenza persistente di sola UI.
- Rendere Scope e Spectrum apribili/spostabili senza disconnettere l'audio.
- Tenere **Panic** sempre disponibile e assegnare un indicatore visibile al preset corrente e allo stato audio.
- Sistemare sticky header, focus e padding del contenuto in tutte le larghezze.

**Consegna:** prima build con differenze visibili e piena continuità funzionale.  
**Gate:** non ci sono controlli irraggiungibili, la tastiera resta utilizzabile, il Panic funziona.

### Fase 4 — Modalità Performance e Preset Browser

**Lavoro**
- Organizzare un browser preset con ricerca, categorie, favoriti, nome e metadati.
- Presentare pochi macrocontrolli *già esistenti* (ad esempio Cutoff, Resonance, ADSR e FX Mix dove disponibili), senza inventare nuovi parametri sonori.
- Gestire l'indicatore di patch modificata solo se affidabile e serializzazione coerente.
- Consentire il passaggio a Sound Design senza cambiare suono o perdere impostazioni.
- Preservare export/import e la distinzione tra factory e user bank.

**Consegna:** prima esperienza semplice e musicale.  
**Gate:** un utente può caricare un preset, suonare, modificarlo e salvarne una copia senza accedere ai pannelli avanzati.

### Fase 5 — Oscillatori, Noise e LFO

**Lavoro**
- Ridisegnare blocchi Osc 1–3 con forma d'onda illustrata, on/off, tuning e volume ordinati.
- Mostrare PWM, FM, Sync, Ring, Unison come sezioni aggiuntive progressive.
- Raffigurare movimento LFO e destinazione senza ricreare il motore di modulazione.
- Mantenere le modalità di qualità Pulse/PWM e FM introdotte in 0.27.0.

**Consegna:** pannello sorgenti e modulazione primaria.  
**Gate:** suono e parametri coincidono con la UI precedente anche dopo salvataggio/ricaricamento.

### Fase 6 — Filtri, inviluppi ed EQ

**Lavoro**
- Visualizzare la risposta di filtro come rappresentazione dei parametri, distinguendola da una misura audio reale.
- Rendere chiari HPF, BPF, Notch, VCF, Advanced Filter e Filter Drive.
- Mostrare un grafico ADSR interattivo con controlli accessibili da tastiera.
- Separare EQ globale e filtri per-voce; conservare ordine della catena.

**Consegna:** strumenti di shaping leggibili a colpo d'occhio.  
**Gate:** i grafici sono coerenti con i valori e non introducono latenza o carico audio anomalo.

### Fase 7 — Mod Matrix

**Lavoro**
- Presentare ogni slot con Source, Destination, Amount bipolare e stato.
- Aggiungere un riepilogo visivo dei percorsi attivi e, se utile, attività di modulazione.
- Lasciare i controlli tabellari come modalità alternativa per utenti esperti e accessibilità.
- Conservare copy/paste/reset e tutte le destinazioni incluse quelle FX.

**Consegna:** matrice facile da leggere e da controllare.  
**Gate:** otto slot riproducibili esattamente, mapping e preset invariati.

### Fase 8 — Effetti, EQ globale e Dynamics Safety

**Lavoro**
- Rappresentare chiaramente la catena FX e la modalità attiva per famiglia.
- Separare bypass delle elaborazioni creative da Dynamics Safety.
- Evidenziare intensità di Mix, feedback e gli avvisi pertinenti senza messaggi allarmistici.
- Conservare i pannelli avanzati e il comportamento All FX Off / Reset FX defaults.

**Consegna:** sezione FX facilmente confrontabile on/off.  
**Gate:** nessun cambio involontario di algoritmi, ordine FX o protezioni.

### Fase 9 — Sequencer e Arpeggiatore

**Lavoro**
- Ridisegnare gli step con focus su note, accordi, velocity, gate, accent e tie.
- Mantenere lunghezze 3–32, pattern non binari e import/export pattern.
- Evidenziare l'esclusività tra Sequencer e Arpeggiatore e lo stato del Motion Engine.
- Fare spazio a Arp mode, swing, latch, macro e randomizer senza sovraffollare.

**Consegna:** editing rapido e trasporto chiaramente leggibile.  
**Gate:** durata, trigger e note ascoltate sono invariati rispetto alla baseline per i pattern di prova.

### Fase 10 — MIDI, patch avanzate e strumenti di supporto

**Lavoro**
- Migliorare ingressi MIDI, eventi ricevuti, MIDI Learn e clock esterno senza modificare il protocollo.
- Organizzare Preset Morph, A/B, Randomizer, user bank e JSON tecnico in ordine di frequenza d'uso.
- Rendere più comprensibili i profili Adaptive Performance e i relativi indicatori.
- Inserire conferme per azioni realmente distruttive senza ostacolare l'esecuzione musicale.

**Consegna:** strumenti avanzati coerenti col nuovo linguaggio UI.  
**Gate:** gli export/import, i mapping MIDI e i dati locali restano compatibili.

### Fase 11 — Responsive, accessibilità e performance visiva

**Lavoro**
- Validare viewport piccoli, touch, zoom 200%, navigazione completa tastiera, contrasti e focus.
- Verificare presenza di tutti i controlli anche nei layout compressi.
- Limitare le animazioni e i canvas quando nascosti; rispettare `prefers-reduced-motion`.
- Verificare che il carico grafico non penalizzi la gestione audio rispetto alla baseline.

**Consegna:** matrice dispositivi e bugfix UI.  
**Gate:** nessun blocco critico; eventuali limitazioni mobili esplicite e documentate.

### Fase 12 — Collaudo e rilascio

**Lavoro**
- Ripetere i test statici, browser e ascolto/MIDI hardware quando disponibili, dichiarando le prove non eseguite.
- Testare caricamento dei factory preset, patch legacy, user bank, MIDI Learn, Morph, A/B, Randomizer, sequencer, Arp, Panic, funzioni avanzate e salvataggi.
- Confrontare runtime, inventario ID/target e parametri serializzati col gate iniziale.
- Aggiornare manuale, screenshot, README, note di rilascio e problemi noti.
- Preparare **ZIP ESSENZIALE** e **ZIP COMPLETO**, con manifest e hash riproducibili.
- Prima della release pubblica: sessione di usabilità con nuovi utenti e confronto della versione precedente.

**Consegna:** pacchetti finali, changelog, dossier QA, documentazione aggiornata.  
**Gate:** tutti i blocchi critici chiusi o esplicitamente documentati; approvazione finale.

---

## Test obbligatori alla chiusura di OGNI fase implementativa

1. Apertura `index.html`, sblocco audio, nota da tastiera virtuale e PC, Panic.
2. Caricamento di `Default Init` e di preset di categorie differenti.
3. Modifica di almeno un parametro interessato dalla fase, verifica del valore e del risultato sonoro.
4. Serializzazione patch → ripristino → confronto dei parametri originali.
5. Verifica sequencer/Arp non disturbati e assenza di note bloccate.
6. Controllo di ID duplicati, listeners, target MIDI Learn, focus e tab order.
7. Verifica dei layout target, assenza di overflow che nasconde controlli e comprensibilità dei messaggi.
8. Diff rispetto alla baseline; nessuna modifica ai file DSP salvo autorizzazione separata e giustificata.

Dove l'ambiente non consente audio hardware, MIDI fisico o browser, segnare il test come **NON ESEGUITO**; non convertire risultati statici in dichiarazioni di funzionamento reale.

## Protocollo di consegna per singola fase

Ogni fase che modifica software produce:

- `Sorgiva_Synth_UI_<NN>_ESSENZIALE.zip`
- `Sorgiva_Synth_UI_<NN>_COMPLETO.zip`
- `UI_PHASE_<NN>_CHANGELOG.md` (file realmente modificati e ragioni)
- `UI_PHASE_<NN>_QA.md` (test PASS/FAIL/NON ESEGUITO e problemi aperti)
- `UI_PHASE_<NN>_SCREENSHOTS/` (se render browser disponibile)
- Decisione di gate: **APPROVATO**, **DA CORREGGERE**, **RIPRISTINARE**.

Le fasi 0 e 1, puramente analitiche/progettuali, non richiedono ZIP alterati: devono invece consegnare inventario e wireframe.

## Primo comando operativo per iniziare

> **Esegui esclusivamente la Fase 0** della Roadmap UI/UX Sorgiva Synth, usando come baseline `Sorgiva_Synth_v0_27_0_beta1rc1_COMPLETO.zip` e confrontando il runtime con il pacchetto ESSENZIALE. Non riscrivere alcun file del sintetizzatore. Produci audit della struttura DOM/CSS/JS, inventario ID e contratti di binding, dipendenze critiche di MIDI Learn/preset, matrici di regressione, screenshot delle nove schede se l'ambiente lo consente, e un rapporto dei rischi per la futura riprogettazione. Distingui accuratamente test rieseguiti, test storici e test non eseguiti. Fermati dopo i deliverable della Fase 0: nessuna Fase 1 o successiva senza approvazione esplicita.

## Cosa non fare

- Non rifare tutte le pagine in una sola modifica.
- Non cambiare framework per moda: valutare il costo di migrazione e il rischio di regressioni.
- Non usare manopole grafiche che non funzionano con tastiera o touch.
- Non nascondere definitivamente controlli esistenti in modalità Performance: devono restare raggiungibili nella vista completa.
- Non confondere miglioramenti visivi con miglioramenti DSP misurati.
- Non considerare la sola approvazione estetica equivalente al superamento di test funzionali.
