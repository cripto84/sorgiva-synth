# Sorgiva Synth — supplemento UI Studio RC1

29 ottobre 2026. Si affianca al manuale v3.0 per il motore 0.27.0-beta1-rc1; non lo sostituisce. I nomi dei parametri, le patch e il comportamento sonoro rimangono quelli del motore di partenza.

## Primo utilizzo
Aprire `index.html`, oppure servire la cartella con `python3 -m http.server 8080` e aprire `http://localhost:8080`. Premere **Sblocca Audio**, scegliere un suono nel browser factory e premere **Carica preset factory**. Un nome evidenziato nella lista indica la selezione, non necessariamente il suono già caricato: leggere **Patch:** nell'header.

## Mappa
| Zona | Cosa contiene |
|---|---|
| Header | Modalità UI, nome patch, ingressi MIDI, stato audio, velocity/sustain, Master e Panic |
| Performance | Browser factory con ricerca/categorie/preferiti; VCF; ADSR amp; mix e attivazione FX; salvataggio locale/export |
| Sound Design | Tutte le nove schede originali, con accesso agli strumenti avanzati |
| Dock tastiera | Quattro ottave, Riduci/Apri tastiera, Scope/Spectrum facoltativi |

Le modalità spostano gli stessi controlli: non creano una seconda patch. Cambiare modalità non richiama un preset né riavvia l'audio. Il modo e lo stato aperto/chiuso della tastiera sono preferenze UI separate, nelle chiavi `sorgiva-ui-mode` e `sorgiva-ui-dock`.

## Performance
1. Cerca un preset per nome o filtra per categoria; i preferiti originali sono conservati.
2. Regola VCF e ADSR direttamente. Le stesse impostazioni compaiono in Sound Design.
3. In Spazio & movimento attiva la famiglia desiderata e regola il relativo mix. Algoritmi, tempo e feedback sono disponibili nella scheda Effetti.
4. Salva locale conserva una patch nel browser; Carica locale la ripristina. Per più suoni usa **User Bank · A/B · Morph →**. Export JSON crea il file portabile.
5. Il messaggio di esito delle operazioni patch è visibile anche in Performance.

## Sound Design
- **Oscillatori & LFO:** forme ideali accanto ai selettori. Pulse/PWM e qualità sono in un dettaglio apribile per oscillatore. Noise, FM, Ring, Sync e Unison rimangono disponibili.
- **Filtri & Inviluppo:** curve teoriche, cutoff/Q e ADSR. Il sostegno dell'ADSR è disegnato con durata illustrativa fissa: nella musica dura quanto la nota. La curva esponenziale è schematica. I grafici si aggiornano usando gli slider nativi; non introducono gesti di trascinamento sul grafico.
- **Equalizzazione:** guadagni delle cinque bande; la linea non è la risposta combinata del DSP.
- **Mod Matrix:** otto slot, riepilogo sorgente → destinazione e barre bipolari. Verde acqua = quantità positiva, ambra = negativa; il segno numerico resta leggibile. Copy/Paste/Reset originali restano disponibili.
- **Effetti:** sequenza globale Drive → EQ → Modulazione → Delay → Riverbero → Dynamics Safety. I pulsanti della catena portano ai controlli; non sono bypass aggiuntivi. I toggle originali controllano l'attivazione. Safety ha un riquadro distinto.
- **Sequencer & Arpeggiatore:** step in griglia. Nota, ottava, accordo, velocity, gate, accent e tie restano esposti. Aprire Voicing accordo per custom, inversione, spread, strum e velocity dell'accordo. Lunghezze e timing sono invariati.
- **Preset & Patch:** scorciatoie a Factory, User Bank, A/B, Randomizer, Morph e JSON. Aprire i dettagli JSON per importare un file. Conferme originali di sovrascrittura/cancellazione conservate.
- **Performance (scheda):** comportamento esecutivo originale, accordatura e Adaptive Performance. Non confonderla con la modalità UI Performance, che è la vista semplificata del synth.
- **MIDI:** ingresso, MIDI Learn e Clock con scorciatoie. Il numero nell'header indica gli ingressi rilevati, non certifica il funzionamento di un controller.

## Tastiera e accessibilità
Tab raggiunge i controlli; frecce modificano slider e selezioni. Le schede seguono il comportamento originale: frecce spostano il focus, Invio/Spazio aprono la scheda. Sui tasti virtuali, Invio/Spazio tengono una nota fino al rilascio; anche la perdita del focus la rilascia. Panic resta visibile, sui telefoni in basso a destra. Riduci tastiera libera spazio senza cambiare patch.

Su desktop il dock è fisso; su tablet e telefono scorre nella pagina. La tastiera conserva tutte le quattro ottave e può scorrere orizzontalmente. Le spiegazioni estese sono in Guida alla sezione o Guida e dettagli. La preferenza di sistema per movimento ridotto è rispettata.

## Limiti delle verifiche
Chromium headless: test reali del runtime e layout; touch e larghezza equivalente al 200% sono emulati. Nessun ascolto umano, MIDI hardware, Safari/iOS o Android fisico in questa sessione. WebMIDI dipende da supporto browser, permessi e origine; un test simulato non certifica un dispositivo. Il sorgente audio non è stato modificato. Scope/Spectrum evitano il disegno quando il canvas non è visibile; il loro scheduler originale rimane attivo.
