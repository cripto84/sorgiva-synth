# Sorgiva Synth — UI Studio RC1: rapporto finale QA

**Data:** 29 ottobre 2026  
**Motore di riferimento:** 0.27.0-beta1-rc1  
**Esito:** candidata UI implementata; controlli applicabili completati, limiti sotto dichiarati. Nessun deploy o pubblicazione effettuati.

## Risultato

L'interfaccia dispone di due viste della stessa patch. Performance raccoglie browser factory, VCF, ADSR amp, attivazione/mix FX e salvataggio. Sound Design conserva le nove schede e tutti i controlli originali. I nodi DOM vengono spostati, non duplicati: ID, listener e valori rimangono gli stessi.

Sono aggiunti header con Master/Panic/stato MIDI, dock richiudibile, grafici teorici delle sorgenti e del timbro, lettura dei percorsi di modulazione, catena effetti, griglia step con voicing apribile, scorciatoie agli strumenti e guide progressive. La nuova UI funziona senza build, framework o risorse remote.

## Prima e dopo

| Baseline | UI Studio RC1 |
|---|---|
| Nove schede come ingresso unico | Performance per suonare; Sound Design per tutti i moduli |
| Master nella scheda oscillatori | Master sempre nell'header |
| Panic nel dock | Panic nell'header; fisso in basso su mobile |
| Dock fisso ingombrante, clic bloccati su mobile | Dock riducibile; su mobile scorre nella pagina |
| Parametri prevalentemente testuali | Onde, ADSR, filtri ed EQ illustrativi, più valori originali |
| Matrix da leggere slot per slot | Riepilogo percorsi e barre bipolari, otto slot originali |
| Molti controlli accordo simultanei | Voicing progressivo per ogni step |
| Informazioni estese sempre esposte | Guide apribili e scorciatoie |

## Integrità e compatibilità

- **1.140 ID statici originali** senza duplicati; **1.172 ID runtime originali** conservati (inclusi quelli generati all'avvio).
- **643 campi patch**, **135 preset factory**, **229 target MIDI Learn**.
- Nessuna modifica ai sorgenti audio/DSP, configurazione audio, allocator/lifecycle, Adaptive Performance, modulazione, stato, motion/transport, sequencer, arpeggiatore, preset, MIDI o keyboard.js. `final-integrity.json` e SHA-256 verificano questo vincolo.
- Modificati nell'originale soltanto `index.html` e i due visualizzatori: questi ultimi saltano il disegno quando il canvas non è visibile. I timer originali restano attivi; non è stata aggiunta una nuova animazione continua.
- Aggiunti `styles/ui-studio.css`, `src/ui/studio.js`, istruzioni e identificatore UI. `styles/main.css` rimane intatto come base.
- Nomi/versione del motore e formato serializzato restano originali. La variante si identifica separatamente come **UI Studio RC1**.
- Gli archivi sorgente sono conservati immutati nel COMPLETO, insieme al manuale originale.

## Le 13 fasi

| Fase | Esito e contenuto |
|---|---|
| 00 | Baseline, confronto ZIP, hash, inventario DOM, sintassi e test di riferimento |
| 01 | Progetto UX e quattro wireframe; mockup verificati nelle build incrementali |
| 02 | Tokens CSS, controlli nativi e focus |
| 03 | Header, navigazione, Master/Panic, dock riducibile |
| 04 | Performance, browser e salvataggi con gli stessi nodi DOM |
| 05 | Onde oscillator/LFO e Pulse/PWM progressivo |
| 06 | Grafici teorici filtro, ADSR ed EQ |
| 07 | Riepilogo Matrix e quantità bipolari |
| 08 | Ordine FX, bypass e Dynamics Safety distinta |
| 09 | Griglia step e voicing apribile; transport invariato |
| 10 | MIDI e scorciatoie a User Bank/A-B/Morph/Randomizer/JSON/Adaptive |
| 11 | Responsive, focus, etichette, Invio/Spazio sui tasti, riduzione del lavoro grafico |
| 12 | Collaudo, correzioni, documentazione, checkpoint e pacchetti |

I gate sono approvati per le verifiche applicabili qui eseguite, non come certificazione di release pubblica. Ogni fase implementativa dispone di risultati, screenshot, changelog e checkpoint. In fase 02 rimaneva il difetto mobile della baseline, corretto nella fase 03; non è stato occultato come test superato. Le ultime rifiniture sono comprese nel checkpoint 12.

## Test PASS

### Runtime e suono automatico

- Suite storica rieseguita: **32 controlli runtime sulla baseline e 32 sulla nuova build**. Copre modifica di modulazioni su note tenute, otto slot, FX modulation, polifonia, release/Panic, tempo globale, delay/LFO sync, input MIDI simulato per gli step e stop di Sequencer/Arp.
- **135/135 factory preset** in 27 pagine isolate: caricamento, nota, controllo della voce, Panic e pulizia delle code; nessuna mutazione dei preset sorgente e nessun pageerror.
- **Due scenari OfflineAudioContext per build**, quattro render: campioni finiti, ampiezza non nulla e limitata, coda a zero. Peak e discontinuità risultano identici o con differenze numeriche minime nei casi testati. Non è un confronto bit-a-bit di ogni campione né una prova di ascolto.
- Per ogni fase: quattro preset rappresentativi, modifica cutoff, roundtrip, unlock, nota API, Panic e assenza di pageerror.

### Interazione e dati

- native preset search/load
- PC keyboard note
- virtual key Enter accessible
- virtual key pointer note
- local patch save/load via buttons
- JSON export 643 parameters
- user bank save
- A/B reload
- Morph interpolation
- Randomizer undo exact patch
- all MIDI Learn targets exist
- JSON reimport via native file input
- user bank survives reload
- no horizontal document overflow at four widths
- visible form controls labelled
- tab arrow navigation
- tab Enter activation
- synthetic MIDI CC mapping controls cutoff
- dock preference survives reload
- interface mode survives reload
- skip link follows active mode
- emulated touch keyboard input
- 200 percent zoom equivalent layout (720 CSS px)
- no JavaScript page errors

I test di touch e del layout equivalente a zoom 200% sono emulati in Chromium. Il test di mapping CC usa dati sintetici, senza controller fisico. Il controllo delle etichette è una verifica DOM, non una prova con screen reader.

### Controllo del pacchetto estratto

PASS: avvio diretto di index.html dall’ESSENZIALE estratto, unlock e nota; patch di prova con tipo legacy synthx_user_patch ripristinata; lunghezze sequencer 3, 5, 7, 16, 31 e 32 coerenti fra configurazione e step visibili; 643 campi e 229 target. La prova legacy è una verifica sintetica, non una raccolta completa di archivi storici.

### Layout e immagini

Nove schede a 1440, 1366, 768 e 390 px, con screenshot. Nella verifica finale nessun overflow orizzontale dell'intero documento e nessun clic di navigazione bloccato. La tastiera mantiene intenzionalmente lo scorrimento orizzontale sulle quattro ottave. Ispezionate schermate rappresentative, inclusi Performance, oscillatori, filtri, Matrix, FX, sequencer e voicing aperto. Le immagini sono catture reali del browser.

## FAIL individuati e risolti

| Problema | Intervento / verifica |
|---|---|
| Dock baseline copriva le schede su mobile | Dock in flusso mobile, collasso desktop; clic tab finali PASS |
| Ordine iniziale Performance esponeva FX/salvataggio prima del timbro | Riordinamento delle carte e nuova cattura |
| Mix rapidi avevano etichette tutte uguali e mancavano i toggle vicini | Nomi famiglia e spostamento dei toggle originali |
| Pulsante Panic mobile era confinato dal backdrop-filter dell'header | Rimosso backdrop-filter mobile; posizione fissa viewport |
| Collegamento rapido Morph usava un ID inesistente | Corretto in morph-ratio |
| Select degli step mostravano testo tagliato | Padding e colonne resi più compatti; ispezione sequencer |
| Skip-link puntava al main nascosto in Performance | Destinazione sincronizzata con la vista attiva |
| Test import non apriva il dettaglio JSON | Runner corretto per aprirlo come un utente |
| Test import verificava il valore prima della fine di FileReader | Attesa della condizione di ripristino; riesecuzione PASS |

Gli ultimi due erano difetti del test, non del prodotto. I risultati dei tentativi precedenti sono conservati e distinti dalla riesecuzione finale. **Nessun FAIL critico aperto nei test completati.**

## NON ESEGUITI e limiti

- Ascolto umano e confronto musicale soggettivo, dispositivi audio e latenza reale.
- Controller MIDI/USB fisico, MIDI Clock da hardware reale e hot-plug reale.
- Safari, Firefox, iOS/Android fisici; touch verificato solo in emulazione Chromium.
- Screen reader reale, audit WCAG completo, usabilità con principianti, durata prolungata di sessioni dal vivo.
- Sweep di tutti i parametri DSP, combinazioni preset×modulazioni e analisi statistica di carico/CPU/dropout.

Il codice sonoro identico è una forte evidenza di conservazione, ma non sostituisce tutte le prove possibili. I grafici sono teorici/schematici: non misurano il segnale e non rappresentano esattamente l'intero motore (forme band-limited, LFO sync effettivo, risposta combinata EQ e durata del sustain). Non sono state aggiunte macro sonore. La modalità semplificata richiede scrolling per i controlli meno frequenti; nessun controllo è stato eliminato.

## Consegna e rollback

- **ESSENZIALE:** runtime, risorse locali, istruzioni di avvio e licenze. Nessuna dipendenza di test o storico.
- **COMPLETO:** medesima applicazione, QA, screenshot, test riproducibili, checkpoint, specifiche, supplemento e archivi storici originali.
- Rapporto e supplemento separati per lettura immediata; file SHA256SUMS per i due ZIP.
- Gli ZIP sono verificati con controllo CRC e struttura; l'ESSENZIALE viene estratto e avviato separatamente. I risultati dell'ultimo controllo sono in `package-smoke-results.json`, consegnato nel dossier tecnico.

Per rollback estrarre l'ESSENZIALE originale o un checkpoint in una cartella distinta. Non sovrascrivere i dati del browser per confrontare build: usare un'origine/profilo di prova separato. Il sorgente distribuito non include gli hook QA.

Prima di pubblicare: ascolto A/B con la baseline, sessione MIDI fisica, prova mobile reale e breve sessione con nuovi utenti. La build non è stata pubblicata né inviata a terzi.
