# Sorgiva — progetto UI 1, 29 ottobre 2026

Identità: laboratorio musicale scuro, verde acqua per i parametri, ambra per gli stati musicali. Fondo #0c1215, pannelli #151f24, testo #edf5f3, secondario #b0c4c6. Font di sistema; niente risorse remote.

## Gerarchia
Header: marchio, scelta Performance / Sound Design, audio, Master, Panic.
Performance: browser factory originale + filtro VCF + ADSR amp + mix FX + salvataggio patch. Tastiera e visualizzatori sotto.
Sound Design: nove schede originali; sezioni sorgenti, modulazione, timbro, effetti, movimento e strumenti. Tutte le funzioni restano disponibili.

## Architettura
Spostare nodi DOM esistenti con segnaposti per il ritorno: nessuna copia di input sonori, ID e listener conservati. I controlli di sola UI sono button, o marcati data-preset-ui. Nessuna nuova macro DSP. Stato del modo e dock in chiavi sorgiva-ui-* separate dalle patch. Nessuna scrittura ai parametri durante il cambio vista.

## Breakpoint e wireframe
- 1440×900: header orizzontale, browser a sinistra, timbro al centro, inviluppo e mix a destra. Dock contenuto.
- 1366×768: medesima gerarchia; dock richiudibile e scrolling del corpo.
- 768×1024: header su due righe; pannelli a due colonne.
- 390×844: header compatto, controlli a colonna singola; tastiera scorrevole con quattro ottave conservate.

## Grafici
Forme d'onda illustrative statiche, aggiornate al cambio parametro. Inviluppi parametrici, non misure audio. Curve filtro schematiche esplicitamente etichettate. Scope e Spectrum rimangono le misure reali originali. Nessun loop animato aggiuntivo.

## Revisione di fattibilità
Browser, categorie e preferiti già presenti: riuso. Audio, preset, MIDI, timing e serializzazione rimangono nei moduli originali. Rischio principale: selettori che dipendono dagli antenati DOM. Verificare insieme degli ID e parametri, MIDI Learn e roundtrip dopo ogni spostamento. Il confronto dei parametri deve ignorare l'ordine delle chiavi JSON, che può cambiare con l'ordine DOM.
