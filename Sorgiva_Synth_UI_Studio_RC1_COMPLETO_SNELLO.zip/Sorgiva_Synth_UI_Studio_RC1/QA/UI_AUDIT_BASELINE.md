# Audit baseline — 29 ottobre 2026

Baseline 0.27.0-beta1-rc1. Archivi originali preservati in project_sources; copia runtime in baseline. Hash di ogni file in BASELINE_SHA256.json. Runtime ESSENZIALE e COMPLETO identici byte per byte. 1.140 ID HTML, nessun duplicato; 814 elementi input/select/textarea/button; 33 script JS sintatticamente validi. Nove tab originali.

## Contratti
UI_DOM_CONTRACT.csv elenca ID, tipo, range, attributi data-* e riferimenti letterali JS (non equivale a prova di tutti i binding dinamici). controls.js collega input/change a SynthXState e aggiorna etichette. presets.js legge input/select per ID escludendo data-preset-ui, data-midi-ui e data-adaptive-ui. Spostare un nodo cambia solo ordine delle chiavi: confrontare per chiave/valore, non stringhe JSON. MIDI Learn mantiene una lista esplicita di target. L'adattatore UI deve partire dopo init originale.

## Rischi
- Dock fisso troppo alto su smartphone: test clic tab bloccato da keyboard-dock. Difetto preesistente, non regressione.
- Input sonori duplicati altererebbero patch e MIDI Learn: vietati.
- Scope/Spectrum sono visualizzatori reali; grafici nuovi devono dichiarare la natura parametrica.
- Test storici nel COMPLETO non sono risultati di questa esecuzione.
- Ascolto umano, MIDI hardware, Safari/iOS e Android fisici non disponibili.

## Piano regressione
Test browser: quattro preset rappresentativi per fase, unlock, note API, Panic, edit cutoff e roundtrip, inventario ID/target, nove tab a quattro larghezze. Aggiungere modalità, persistenza, tastiera PC/virtuale, A/B, Morph, randomizer, movimento e OfflineAudioContext nella verifica finale. I risultati parziali/interrotti non costituiscono PASS.
