# Matrice dei gate

| Controllo | Baseline | Ogni fase | Finale |
|---|---|---|---|
| Hash runtime, ID, attributi | sì | confronto | sì |
| Parsing JavaScript | 33 file | nuovi file | tutti |
| Preset init/bass/pad/keys | 4 | 4 | 135 |
| Unlock, nota, Panic | sì | sì | sì |
| Edit e roundtrip 643 campi | sì | sì | sì |
| Target MIDI Learn | inventario | confronto | mapping sintetici |
| 9 tab × 4 viewport | sì | sì | sì |
| Due viste stessa patch | non applicabile | dalla 04 | sì |
| Sequencer/Arp, A/B/Morph | riferimento storico | integrità sorgenti | runtime |
| Audio offline | da eseguire | hash DSP | confronto |
| Ascolto/MIDI hardware | NON ESEGUITO | NON ESEGUITO | NON ESEGUITO |

Le immagini sono screenshot reali, senza simulare un ascolto. I test API di note non sostituiscono test di input PC/touch. Il fallback Enter durante screenshot registra il blocco clic; non è un PASS di interazione mouse. I difetti preesistenti di layout vengono mantenuti nel rapporto fino alla loro correzione.
