from pathlib import Path
import zipfile,sys,json,hashlib
root=Path(__file__).resolve().parents[2];phase=sys.argv[1];out=root/'checkpoints';out.mkdir(exist_ok=True)
with zipfile.ZipFile(out/f'UI_{phase}_ESSENZIALE.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in (root/'work/app').rglob('*'):
  if p.is_file():z.write(p,'Sorgiva_Synth/'+str(p.relative_to(root/'work/app')))
with zipfile.ZipFile(out/f'UI_{phase}_COMPLETO.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(out/f'UI_{phase}_ESSENZIALE.zip',f'UI_{phase}_ESSENZIALE.zip')
 for p in (root/'evidence').rglob('*'):
  if p.is_file() and p.name!='package-integrity.json' and p.suffix in ['.md','.json','.py','.cjs','.svg']:z.write(p,'evidence/'+str(p.relative_to(root/'evidence')))
print('Checkpoint',phase)
