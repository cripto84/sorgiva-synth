from pathlib import Path
out=Path('evidence/wireframes');out.mkdir(exist_ok=True)
for w,h in [(1440,900),(1366,768),(768,1024),(390,844)]:
 rows=[]
 def box(x,y,ww,hh,label):rows.append(f'<rect x="{x}" y="{y}" width="{ww}" height="{hh}" rx="8" fill="#151f24" stroke="#4d7779"/><text x="{x+12}" y="{y+28}" fill="#edf5f3" font-family="sans-serif" font-size="14">{label}</text>')
 box(16,16,w-32,64,'SORGIVA · Performance / Sound Design' if w>500 else 'SORGIVA · P / SD')
 box(16,92,w-32,52,'Audio · Master · Panic')
 if w>1000:
  cw=(w-64)/3
  for i,t in enumerate(['01 · Preset / ricerca / preferiti','02 · Filtro / cutoff / resonance','03 · ADSR / FX Mix / salva']):box(16+i*(cw+16),160,cw,h-340,t)
 elif w>500:
  box(16,160,w-32,250,'01 · Preset / ricerca / preferiti');box(16,426,(w-48)/2,h-610,'02 · Filtro');box(w/2+8,426,(w-48)/2,h-610,'03 · ADSR / FX / salva')
 else:
  for i,t in enumerate(['01 · Preset / ricerca / preferiti','02 · Filtro','03 · ADSR / FX / salva']):box(16,160+i*160,w-32,144,t)
 box(16,h-160,w-32,144,'Tastiera 4 ottave · Scope / Spectrum · Riduci')
 (out/f'wireframe-{w}.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><rect width="100%" height="100%" fill="#0c1215"/>'+''.join(rows)+'</svg>')
