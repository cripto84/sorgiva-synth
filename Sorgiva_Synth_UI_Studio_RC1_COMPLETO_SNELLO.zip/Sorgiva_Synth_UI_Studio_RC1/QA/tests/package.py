from pathlib import Path
import zipfile,shutil,hashlib,json
root=Path(__file__).resolve().parents[2];app=root/'work/app';out=root/'deliverables';out.mkdir(exist_ok=True)
name='Sorgiva_Synth_UI_Studio_RC1'
with zipfile.ZipFile(out/(name+'_ESSENZIALE.zip'),'w',zipfile.ZIP_DEFLATED,9) as z:
 for p in app.rglob('*'):
  rel=p.relative_to(app)
  if p.is_file() and (str(rel).startswith(('src/','styles/','LICENSES/')) or rel.name in ['index.html','LICENSE','NOTICE.txt','TRADEMARK_NOTICE.txt','DOCUMENTATION_LICENSE.txt','VERSION','VERSION.txt','UI_VERSION.txt','LEGGIMI_UI_STUDIO.txt']):z.write(p,str(Path(name)/rel))
with zipfile.ZipFile(out/(name+'_COMPLETO.zip'),'w',zipfile.ZIP_DEFLATED,9) as z:
 for p in app.rglob('*'):
  if p.is_file():z.write(p,str(Path(name)/p.relative_to(app)))
 for p in (root/'evidence').rglob('*'):
  if p.is_file() and p.suffix not in ['.log','.pyc'] and p.name!='package-integrity.json':z.write(p,str(Path(name)/'QA'/p.relative_to(root/'evidence')))
 for p in (root/'checkpoints').glob('*.zip'):z.write(p,str(Path(name)/'CHECKPOINT'/p.name))
 for p in (root/'project_sources').glob('*.zip'):z.write(p,str(Path(name)/'STORICO_ORIGINALE'/p.name))
 for p in (root/'project_sources').glob('*.pdf'):z.write(p,str(Path(name)/'DOCUMENTAZIONE'/p.name))
 for p in (root/'upload').glob('*'):
  if p.is_file():z.write(p,str(Path(name)/'SPECIFICHE'/p.name))
 for p in out.glob('*.png'):z.write(p,str(Path(name)/'IMMAGINI'/p.name))
 for filename in ['Sorgiva_Synth_UI_Studio_Rapporto_QA.md','Sorgiva_Synth_UI_Studio_Supplemento_Manuale.md']:
  p=out/filename
  if p.exists():z.write(p,str(Path(name)/'DOCUMENTAZIONE'/filename))
checks=[]
for p in out.glob('*.zip'):
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  assert f'{name}/index.html' in z.namelist()
  checks.append({'name':p.name,'bytes':p.stat().st_size,'files':len(z.namelist()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'SHA256SUMS.txt').write_text('\n'.join(x['sha256']+'  '+x['name'] for x in checks)+'\n')
(root/'evidence/package-integrity.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
with zipfile.ZipFile(out/(name+'_ESSENZIALE.zip')) as z:z.extractall(root/'package-smoke')
