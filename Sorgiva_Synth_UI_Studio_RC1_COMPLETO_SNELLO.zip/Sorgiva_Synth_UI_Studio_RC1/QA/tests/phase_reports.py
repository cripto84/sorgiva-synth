from pathlib import Path
import json,zipfile,hashlib
root=Path(__file__).resolve().parents[2];out=root/'evidence'
names={2:'Fondamenta tecniche',3:'Telaio principale',4:'Performance e preset',5:'Oscillatori e LFO',6:'Filtri, ADSR ed EQ',7:'Mod Matrix',8:'Effetti e Dynamics Safety',9:'Sequencer e Arpeggiatore',10:'MIDI e strumenti avanzati',11:'Responsive e accessibilità',12:'Collaudo finale e packaging'}
notes={2:'Tokens CSS, controlli nativi e focus. Nessun nuovo stato sonoro.',3:'Header, Master e Panic globali; tastiera riducibile. Corretto dock che intercettava clic sul mobile.',4:'Nodi originali spostati tra due viste; browser originale, FX mix, salvataggi. Corretti ordine dei pannelli e nomi dei mix dopo ispezione.',5:'Onde illustrative e sezioni Pulse/PWM apribili; nome patch corrente.',6:'Grafici parametrici di filtro/ADSR/EQ, esplicitamente distinti da misure.',7:'Otto percorsi e quantità bipolari; controlli originali invariati.',8:'Ordine FX verificato sul sorgente; protezione dinamica separata visivamente.',9:'Griglia step e voicing progressivo; ID e attributi degli step conservati.',10:'Stato ingressi MIDI, scorciatoie e guide apribili. Corretto riferimento del pulsante Morph nel passaggio successivo.',11:'Layout fluidi, Panic fisso mobile, grafici nascosti senza ridisegno, tasti virtuali Invio/Spazio, etichette e preferenze. Raffinamenti finali registrati in fase 12.',12:'Corretti padding dei select step, skip-link attivo e test import asincrono. Verifica runtime, offline, 135 preset, interazioni e archivi.'}
prev=root/'checkpoints/UI_00_ESSENZIALE.zip'
for n,title in names.items():
 phase=f'{n:02d}';z=root/f'checkpoints/UI_{phase}_ESSENZIALE.zip';res=json.load(open(out/f'phase-{phase}/results.json'))
 def hashes(p):
  with zipfile.ZipFile(p) as a:return {i:hashlib.sha256(a.read(i)).hexdigest() for i in a.namelist()}
 old,new=hashes(prev),hashes(z);changed=[k for k,v in new.items() if old.get(k)!=v];prev=z
 text=f'# Fase {phase} — {title}\n\n**Esito: APPROVATA nei limiti di verifica dichiarati.**\n\n{notes[n]}\n\n## File modificati rispetto al checkpoint precedente\n\n'+''.join('- '+k+'\n' for k in changed)
 text+='\n## QA\n\nPASS: apertura, quattro preset rappresentativi, 643 parametri, edit cutoff, roundtrip, unlock WebAudio, nota API, Panic; nessun ID duplicato né pageerror. Screenshot delle nove schede a 1440, 1366, 768 e 390 px; ispezione visiva di schermate rappresentative.\n'
 if n>=4:text+='PASS: cambio modalità conserva parametri e nota tenuta.\n'
 if res.get('layoutIssues'):text+='FAIL preesistente ancora aperto: dock intercetta clic mobile; corretto in fase 03. Screenshot ottenuti con fallback Enter, registrato nel JSON.\n'
 else:text+='PASS: clic di navigazione senza fallback alle quattro larghezze.\n'
 text+='\nNON ESEGUITI: ascolto umano, MIDI hardware, dispositivi mobili fisici, screen reader reale. Nessun test non eseguito è conteggiato come PASS.\n\nEvidenze: `phase-'+phase+'/results.json`, screenshot nella stessa cartella. Checkpoint rollback: `UI_'+phase+'_ESSENZIALE.zip`. La baseline originale resta il riferimento sicuro; nessuna pubblicazione.\n'
 (out/f'UI_PHASE_{phase}_QA.md').write_text(text);(out/f'UI_PHASE_{phase}_CHANGELOG.md').write_text(f'# Fase {phase} — {title}\n\n{notes[n]}\n\n'+''.join('- '+k+'\n' for k in changed))
