# Riprodurre le verifiche UI Studio

Questi test sono nuovi o adattati dai test storici della baseline. `legacy-regression.json` contiene HOOK/RUNTIME/FACTORY_BATCH/OFFLINE estratti senza modifica da `tests/regression_r3.py` originale. Il solo HOOK viene iniettato in memoria durante il test: non è nel runtime distribuito.

Requisiti: Node.js, Python 3, Playwright con Chromium; BeautifulSoup4 solo per audit.py. Impostare `CHROMIUM_PATH` se Chromium non è quello installato da Playwright. Nessuna di queste dipendenze è necessaria per usare il sintetizzatore.

I percorsi dei runner assumono una cartella di lavoro con:
- `work/app/`: applicazione UI Studio;
- `baseline/Sorgiva_Synth_v0_27_0_beta1rc1/`: ESSENZIALE originale estratto;
- `full/Sorgiva_Synth_v0_27_0_beta1rc1/`: COMPLETO originale estratto (audit);
- `evidence/tests/`: questa cartella.

Dalla cartella di lavoro:
```
node evidence/tests/browser.cjs 00
node evidence/tests/browser.cjs 12
node evidence/tests/deep.cjs runtime
node evidence/tests/deep.cjs offline
node evidence/tests/deep.cjs factory
node evidence/tests/final.cjs
python3 evidence/tests/integrity.py
```

I runner browser/final servono solo localhost (porte 8123/8124), con contesti browser temporanei e dati di test separati. Non eseguirli contro un profilo personale. Il test factory carica 135 preset in 27 contesti di pagina isolati. Le due configurazioni offline non coprono tutte le combinazioni DSP.

`audit.py` genera il contratto statico e verifica i 33 JS originali. `integrity.py` controlla i sorgenti protetti, la sintassi finale e gli inventari runtime. Il confronto parametri deve essere per chiave/valore, non per ordine delle chiavi.

I risultati `final-interaction-attempt1/2.json` sono errori del test (dettaglio import chiuso; mancata attesa FileReader), conservati per trasparenza; `final-interaction-results.json` è la riesecuzione finale corretta. I risultati storici presenti nell'archivio baseline non sono prove di questa build.
