from pathlib import Path
from bs4 import BeautifulSoup
import json,hashlib,csv,re,subprocess,collections
root=Path(__file__).resolve().parents[2]; base=root/'baseline/Sorgiva_Synth_v0_27_0_beta1rc1'; full=root/'full/Sorgiva_Synth_v0_27_0_beta1rc1'; out=root/'evidence'
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={str(p.relative_to(base)):hashfile(p) for p in base.rglob('*') if p.is_file()}
(out/'BASELINE_SHA256.json').write_text(json.dumps(files,indent=2))
soup=BeautifulSoup((base/'index.html').read_text(),'html.parser'); ids=[e['id'] for e in soup.select('[id]')]
with (out/'UI_DOM_CONTRACT.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['id','tag','type','min','max','step','value','data_attributes','referenced_by'])
 for e in soup.select('[id]'):
  refs=[str(p.relative_to(base)) for p in base.glob('src/**/*.js') if e['id'] in p.read_text()]
  w.writerow([e['id'],e.name,*[e.get(k,'') for k in ['type','min','max','step','value']],json.dumps({k:v for k,v in e.attrs.items() if k.startswith('data-')}),' | '.join(refs)])
checks=[]
for p in base.glob('src/**/*.js'):
 r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True);checks.append({'file':str(p.relative_to(base)),'pass':r.returncode==0,'error':r.stderr})
summary={'runtime_comparison':{k:'identical' if (full/k).exists() and hashfile(full/k)==v else 'DIFFERENT_OR_MISSING' for k,v in files.items() if k=='index.html' or k.startswith(('src/','styles/'))},'id_count':len(ids),'duplicate_ids':[k for k,v in collections.Counter(ids).items() if v>1],'controls':len(soup.select('input,select,textarea,button')),'tabs':[e.get_text(strip=True) for e in soup.select('[role=tab]')],'js_syntax':checks,'historical_test_scripts':[str(p.relative_to(full)) for p in full.glob('tests/*.py')]}
(out/'baseline_static_results.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k not in ['runtime_comparison','js_syntax','historical_test_scripts']},indent=2));print('JS',len(checks),'failures',sum(not c['pass'] for c in checks));print('runtime mismatches',sum(v!='identical' for v in summary['runtime_comparison'].values()))
