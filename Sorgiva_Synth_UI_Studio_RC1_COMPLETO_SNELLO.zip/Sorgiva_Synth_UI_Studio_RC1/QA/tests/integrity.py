from pathlib import Path
import json,hashlib,subprocess
root=Path(__file__).resolve().parents[2];base=root/'baseline/Sorgiva_Synth_v0_27_0_beta1rc1';app=root/'work/app';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changes=[str(p.relative_to(base)) for p in base.rglob('*') if p.is_file() and ((not (app/p.relative_to(base)).exists()) or sha(p)!=sha(app/p.relative_to(base)))]
protected=['src/audio/','src/arp/','src/sequencer/','src/motion/','src/midi/','src/presets/','src/performance/','src/modulation/','src/state/','src/keyboard/','src/ui/controls.js','src/ui/tabs.js','src/main.js']
assert not any(any(c.startswith(k) for k in protected) for c in changes),changes
results=[]
for p in app.glob('src/**/*.js'):
 r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True);assert not r.returncode,r.stderr;results.append(str(p.relative_to(app)))
b=json.load(open(root/'evidence/phase-00/results.json'));f=json.load(open(root/'evidence/phase-12/results.json'))
assert set(b['ids'])<=set(f['ids']);assert set(b['midiTargets'])==set(f['midiTargets']);assert not f['duplicates'];assert f['parameterCount']==643
out={'changed_original_runtime_files':changes,'new_files':[str(p.relative_to(app)) for p in app.rglob('*') if p.is_file() and not (base/p.relative_to(app)).exists()],'protected_source_unchanged':True,'syntax_checked':results,'original_ids_preserved':len(b['ids']),'midi_targets_preserved':len(b['midiTargets']),'patch_fields':643,'manifest':{str(p.relative_to(app)):sha(p) for p in app.rglob('*') if p.is_file()}}
(root/'evidence/final-integrity.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['manifest','syntax_checked']},indent=2))
